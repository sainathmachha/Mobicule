package com.eventmngtsys.dao;

import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Feedback;

public interface AttendeeDAO {

    boolean generateQR(Booking booking);

    boolean createBooking(Booking booking);

    boolean updateSeatsLeft(int eventId, int seatsBooked);

    boolean userExists(int userId);

    void viewBookedEvents(int userId);

    boolean cancelBookedEvent(int bookingId, int userId);

    boolean createFeedback(Feedback feedback);

    boolean userVerifyEventId(int eventId);
}
