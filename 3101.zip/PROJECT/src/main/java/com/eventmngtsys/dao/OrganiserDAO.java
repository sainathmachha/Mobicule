package com.eventmngtsys.dao;

import com.eventmngtsys.entity.BookedEvents;
import com.eventmngtsys.entity.Event;
import com.eventmngtsys.entity.Feedback;

import java.util.List;

public interface OrganiserDAO {

    boolean createEventInDB(Event event);
    List<Event> listAllMyEvents(int userId);
    boolean checkIfAnOrgOrNot(int orgId);
    boolean updateEvent(Event event);
    Event getCurrentValues(int eventId);
    boolean deleteEventFromDB(int eventId);
    List<BookedEvents> viewBookedEvents(int userId);
    List<Feedback> viewFeedBackForEvents(int orgId);
    List<Event> viewAllEvents();
    boolean checkSeatCapacity(int eventId, int seatsBooked);

    boolean userVerifyEventId(int eventId);
}
