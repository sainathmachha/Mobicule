package com.eventmngtsys.dao;

import com.eventmngtsys.entity.Event;
import com.eventmngtsys.entity.User;

import java.util.List;

public interface AdminDAO {

    boolean addUserInDB(User user);
    List<User> viewAllUsers();
    boolean deleteUserFromDB(int userId);
    boolean manageRoles(User user);
    List<Event> viewAllEventFromDB();
    boolean validateUserCredentials(String username, String password);
    String getUserRole(String username);
    int getUserId(String username);
}
