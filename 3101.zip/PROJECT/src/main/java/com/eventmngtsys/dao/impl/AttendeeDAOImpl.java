package com.eventmngtsys.dao.impl;

import com.eventmngtsys.dao.AttendeeDAO;
import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Feedback;
import net.glxn.qrgen.QRCode;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AttendeeDAOImpl implements AttendeeDAO {
    private final Connection connection;

    public AttendeeDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public boolean generateQR(Booking booking){
        String qrData = "EVENT_ID"+booking.getEventId()+"USER_ID"+booking.getUserId()+"SEATS_BOOKED"+booking.getSeatsBooked();
        try {
            File qrFile = Paths.get("home\\sainathmachha\\"+qrData+".png").toFile();
            QRCode.from(qrData).withSize(250,250).writeTo(Files.newOutputStream(qrFile.toPath()));
            if(qrFile.exists()){
                return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    @Override
    public boolean createBooking(Booking booking) {
        if (!userExists(booking.getUserId())) {
            System.out.println("User does not exist.");
            return false;
        }
        String query = "INSERT INTO BOOKINGSI1436(eventId, userId, seatsBooked, bookingStatus) VALUES (?, ?, ?, ?);";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, booking.getEventId());
            preparedStatement.setInt(2, booking.getUserId());
            preparedStatement.setInt(3, booking.getSeatsBooked());
            preparedStatement.setString(4, "PAYMENT PENDING");
            if (preparedStatement.executeUpdate() > 0) {

                //generating qr code
                generateQR(booking);

                //Updating Capacity in events table
                updateSeatsLeft(booking.getEventId(), booking.getSeatsBooked());
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateSeatsLeft(int eventId, int seatsBooked) {
        String query = "UPDATE EVENTSI1436 SET capacity = capacity - ? WHERE eventId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, seatsBooked);
            preparedStatement.setInt(2, eventId);

            if (preparedStatement.executeUpdate() > 0) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    @Override
    public void viewBookedEvents(int userId) {

        String query = "SELECT E.eventName, E.description, E.eventDate, E.eventTime, E.status, "
                + "B.bookingId, B.eventId, B.seatsBooked, B.bookingStatus "
                + "FROM EVENTSI1436 E "
                + "JOIN BOOKINGSI1436 B ON E.eventId = B.eventId "
                + "WHERE B.userId = ?;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {

                System.out.printf("%-10s %-7s %-25s %-40s %-12s %-15s %-15s %-8s %n",
                        "BOOKINGID", "EVENTID", "EVENT NAME", "DESCRIPTION", "DATE", "TIME", "SEATS BOOKED", "STATUS");
                System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

                // Iterate and print results
                while (resultSet.next()) {
                    System.out.printf("%-10d %-7d %-25s %-40s %-12s %-15s %-15d %-8s%n",
                            resultSet.getInt("bookingId"),
                            resultSet.getInt("eventId"),
                            resultSet.getString("eventName"),
                            resultSet.getString("description"),
                            resultSet.getDate("eventDate"),
                            resultSet.getTime("eventTime"),
                            resultSet.getInt("seatsBooked"),
                            resultSet.getString("bookingStatus"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public boolean userExists(int userId) {
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE userId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next() && resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean cancelBookedEvent(int bookingId, int userId) {
        String fetchQuery = "SELECT eventId, seatsBooked FROM BOOKINGSI1436 WHERE bookingId = ? AND userId = ?";
        String cancelQuery = "UPDATE BOOKINGSI1436 SET bookingStatus = 'CANCELLED', seatsBooked = 0 WHERE bookingId = ? AND userId = ?";
        String updateSeatsQuery = "UPDATE EVENTSI1436 SET capacity = capacity + ? WHERE eventId = ?";

        int eventId = 0;
        int seatsBooked = 0;

        try (PreparedStatement fetchStmt = connection.prepareStatement(fetchQuery)) {
            fetchStmt.setInt(1, bookingId);
            fetchStmt.setInt(2, userId);
            try (ResultSet rs = fetchStmt.executeQuery()) {
                if (rs.next()) {
                    eventId = rs.getInt("eventId");
                    seatsBooked = rs.getInt("seatsBooked");
                } else {
                    return false; // Booking not found
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        try (PreparedStatement cancelStmt = connection.prepareStatement(cancelQuery);
             PreparedStatement updateSeatsStmt = connection.prepareStatement(updateSeatsQuery)) {

            cancelStmt.setInt(1, bookingId);
            cancelStmt.setInt(2, userId);

            if (cancelStmt.executeUpdate() > 0) {
                updateSeatsStmt.setInt(1, seatsBooked);
                updateSeatsStmt.setInt(2, eventId);
                return updateSeatsStmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean createFeedback(Feedback feedback) {
        if (!userVerifyEventId(feedback.getEventId())) {
            System.out.println("Event ID does not exist.");
            return false;
        }

        String query = "INSERT INTO FEEDBACKSI1436(eventId, userId, rating, comments) VALUES (?, ?, ?, ?);";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, feedback.getEventId());
            preparedStatement.setInt(2, feedback.getUserId());
            preparedStatement.setInt(3, feedback.getRating());
            preparedStatement.setString(4, feedback.getComments());
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean userVerifyEventId(int eventId) {
        String query = "SELECT COUNT(*) FROM EVENTSI1436 WHERE eventId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next() && resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}