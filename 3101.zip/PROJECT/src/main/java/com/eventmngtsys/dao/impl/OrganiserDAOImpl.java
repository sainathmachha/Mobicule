package com.eventmngtsys.dao.impl;

import com.eventmngtsys.dao.AdminDAO;
import com.eventmngtsys.dao.OrganiserDAO;
import com.eventmngtsys.entity.BookedEvents;
import com.eventmngtsys.entity.Event;
import com.eventmngtsys.entity.Feedback;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrganiserDAOImpl implements OrganiserDAO {

    Connection connection = null;
    private int capacity;

    public OrganiserDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public boolean createEventInDB(Event event) {
        String query = "INSERT INTO EVENTSI1436(eventName, description, organiserId, eventDate, eventTime, venue, capacity, status, price) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, event.getEventName());
            preparedStatement.setString(2, event.getDescription());
            preparedStatement.setInt(3, event.getOrganiserId());
            preparedStatement.setDate(4, event.getEventDate());
            preparedStatement.setTime(5, event.getEventTime());
            preparedStatement.setString(6, event.getVenue());
            preparedStatement.setInt(7, event.getCapacity());
            preparedStatement.setString(8, event.getStatus());
            preparedStatement.setLong(9, event.getPrice());
            int i = preparedStatement.executeUpdate();
            if (i >= 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    @Override
    public List<Event> listAllMyEvents(int orgId) {
        List<Event> myLists = new ArrayList<>();
        String query = "SELECT eventId, eventName, description, organiserId, eventdate, eventTime, venue, capacity, status, price FROM EVENTSI1436 WHERE organiserId = ? ;";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, orgId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                myLists.add(new Event(
                        resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getInt(4),
                        resultSet.getDate(5),
                        resultSet.getTime(6),
                        resultSet.getString(7),
                        resultSet.getInt(8),
                        resultSet.getString(9),
                        resultSet.getLong(10)));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return myLists;
    }

    @Override
    public boolean checkIfAnOrgOrNot(int orgId) {
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE role = 'ORGANISER' AND userId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, orgId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateEvent(Event event) {
        int newEventId = event.getEventId(), newOrganiserId = event.getOrganiserId(), newCapacity = event.getCapacity();
        long newPrice = event.getPrice();
        String newEventName = event.getEventName(),newDescription = event.getDescription(),newVenue = event.getVenue(),newStatus = event.getStatus();
        Date newEventDate = event.getEventDate();
        Time newEventTime = event.getEventTime();

        Event current = getCurrentValues(event.getEventId());

        if (newEventName.isEmpty()) newEventName = current.getEventName();
        if (newDescription.isEmpty()) newDescription = current.getDescription();
        int newOrganizerId = String.valueOf(newOrganiserId).isEmpty() ? current.getOrganiserId(): newOrganiserId;
        Date newDate = String.valueOf(newEventDate).isEmpty() ? current.getEventDate() : newEventDate;
        Time newTime = String.valueOf(newEventTime).isEmpty() ? current.getEventTime() : newEventTime;
        if (newVenue.isEmpty()) newVenue = current.getVenue();
        int newCapacityInput = String.valueOf(newCapacity).isEmpty() ? current.getCapacity() : newCapacity;
        if (newStatus.isEmpty()) newStatus = current.getStatus();
        if (newPrice == 0) newPrice = current.getPrice();

        try {
            String updateQuery = "UPDATE EVENTSI1436 SET eventName = ?, description = ?, organiserId = ?, eventDate = ?, eventTime = ?, venue = ?, capacity = ?, status = ? price = ? WHERE eventId = ?";
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setString(1, newEventName);
            updateStatement.setString(2, newDescription);
            updateStatement.setInt(3, newOrganizerId);
            updateStatement.setDate(4, newDate);
            updateStatement.setTime(5, newTime);
            updateStatement.setString(6, newVenue);
            updateStatement.setInt(7, newCapacity);
            updateStatement.setString(8, newStatus);
            updateStatement.setLong(9,newPrice);
            updateStatement.setInt(10, event.getEventId());

            int rowsAffected = updateStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    @Override
    public Event getCurrentValues(int eventId) {
        String currentEventName = "", currentDescription = "",currentVenue = "", currentStatus = "";
        int currentOrganizerId = 0,currentCapacity = 0;
        Date currentDate = null;
        Time currentTime = null;
        long currentPrice = 0;

        String selectQuery = "SELECT eventName, description, organiserId, eventDate, eventTime, venue, capacity, status, price FROM EVENTSI1436 WHERE eventId = ?";
        try(PreparedStatement selectStatement = connection.prepareStatement(selectQuery);
        ResultSet rs = selectStatement.executeQuery();)
        {
            selectStatement.setInt(1, eventId);
            while (rs.next()) {
                currentEventName = rs.getString("eventName");
                currentDescription = rs.getString("description");
                currentOrganizerId = rs.getInt("organiserId");
                currentDate = rs.getDate("eventDate");
                currentTime = rs.getTime("eventTime");
                currentVenue = rs.getString("venue");
                currentCapacity = rs.getInt("capacity");
                currentStatus = rs.getString("status");
                currentPrice = rs.getLong("price");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return new Event(currentOrganizerId,currentCapacity,currentPrice,currentEventName,currentDescription,currentVenue,currentStatus,currentDate,currentTime);
    }

    @Override
    public boolean deleteEventFromDB(int eventId){
        String deleteBookingsQuery = "DELETE FROM BOOKINGSI1436 WHERE eventId = ?";
        String deleteEventQuery = "DELETE FROM EVENTSI1436 WHERE eventId = ?";

        try (PreparedStatement deleteBookingsStmt = connection.prepareStatement(deleteBookingsQuery);
             PreparedStatement deleteEventStmt = connection.prepareStatement(deleteEventQuery)) {

            deleteBookingsStmt.setInt(1, eventId);
            deleteBookingsStmt.executeUpdate();

            deleteEventStmt.setInt(1, eventId);

            int success = deleteEventStmt.executeUpdate();
            if (success >= 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    @Override
    public List<BookedEvents> viewBookedEvents(int userId) {
        List<BookedEvents> bookedEvents = new ArrayList<>();

        // SQL Query
        String query = "SELECT E.eventName, E.description, E.eventDate, E.eventTime, E.status, " +
                "B.bookingId, B.eventId, B.seatsBooked, B.bookingStatus " +
                "FROM EVENTSI1436 E " +
                "JOIN BOOKINGSI1436 B ON E.eventId = B.eventId " +
                "WHERE B.userId = ?;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    // Create a BookedEvent object from result set
                    BookedEvents bookedEvent = new BookedEvents(
                            resultSet.getInt("bookingId"),
                            resultSet.getInt("eventId"),
                            resultSet.getString("eventName"),
                            resultSet.getString("description"),
                            resultSet.getDate("eventDate"),
                            resultSet.getTime("eventTime"),
                            resultSet.getInt("seatsBooked"),
                            resultSet.getString("bookingStatus"));
                    bookedEvents.add(bookedEvent);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bookedEvents;
    }

    @Override
    public List<Feedback> viewFeedBackForEvents(int orgId) {

        List<Feedback> allFeedbacks = new ArrayList<>();

            String query = "SELECT f.eventId, f.userId, f.rating, f.comments FROM FEEDBACKSI1436 f " + "JOIN EVENTSI1436 e ON f.eventId = e.eventId " + "WHERE e.organiserId = ?;";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, orgId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        allFeedbacks.add(new Feedback(resultSet.getInt("eventId"),
                                resultSet.getInt("userId"),
                                resultSet.getInt("rating"),
                                resultSet.getString("comments")));
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        return allFeedbacks;
    }

    @Override
    public List<Event> viewAllEvents() {
        AdminDAO adminDAO = new AdminDAOImpl();
        return adminDAO.viewAllEventFromDB();
    }

    @Override
    public boolean checkSeatCapacity(int eventId, int seatsBooked) {
        if (connection == null) {
            System.out.println("Connection is null");
            return false;
        }

        String query = "SELECT capacity FROM EVENTSI1436 WHERE eventId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && seatsBooked <= resultSet.getInt(1)) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }

    @Override
    public boolean userVerifyEventId(int eventId) {
        String query = "SELECT COUNT(*) FROM EVENTSI1436 WHERE eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }

}
