package com.eventmngtsys.entity;

public class Feedback {

    int feedbackId, eventId,userId, rating;
    String comments;

    public int getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Feedback(int eventId, int userId, int rating, String comments) {
        this.eventId = eventId;
        this.userId = userId;
        this.rating = rating;
        this.comments = comments;
    }

    @Override
    public String toString() {
        return String.format("| %-10d | %-10d | %-7d | %-50s |%n",eventId, userId,rating,comments);
    }
}
