package com.eventmngtsys.entity;

import java.time.format.DateTimeFormatter;

public class Payment {

    int paymentId,userId,eventId;
    double amount;
    DateTimeFormatter paymentDate;
    String paymentStatus;
    String paymentMethod;

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public DateTimeFormatter getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(DateTimeFormatter paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Payment(int userId, int eventId, double amount, DateTimeFormatter paymentDate, String paymentStatus, String paymentMethod) {
        this.userId = userId;
        this.eventId = eventId;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.paymentStatus = paymentStatus;
        this.paymentMethod = paymentMethod;
    }
}
