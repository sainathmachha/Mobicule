package com.eventmngtsys.entity;

import java.sql.Date;
import java.sql.Time;

    public class BookedEvents {
        private int bookingId;
        private int eventId;
        private String eventName;
        private String description;
        private Date eventDate;
        private Time eventTime;
        private int seatsBooked;
        private String bookingStatus;

        // Constructor
        public BookedEvents(int bookingId, int eventId, String eventName, String description,
                           Date eventDate, Time eventTime, int seatsBooked, String bookingStatus) {
            this.bookingId = bookingId;
            this.eventId = eventId;
            this.eventName = eventName;
            this.description = description;
            this.eventDate = eventDate;
            this.eventTime = eventTime;
            this.seatsBooked = seatsBooked;
            this.bookingStatus = bookingStatus;
        }

        // Getters and Setters
        public int getBookingId() { return bookingId; }
        public int getEventId() { return eventId; }
        public String getEventName() { return eventName; }
        public String getDescription() { return description; }
        public Date getEventDate() { return eventDate; }
        public Time getEventTime() { return eventTime; }
        public int getSeatsBooked() { return seatsBooked; }
        public String getBookingStatus() { return bookingStatus; }

        @Override
        public String toString() {
            return String.format("BookedEvent{bookingId=%d, eventId=%d, eventName='%s', description='%s', " +
                            "eventDate=%s, eventTime=%s, seatsBooked=%d, bookingStatus='%s'}",
                    bookingId, eventId, eventName, description, eventDate, eventTime, seatsBooked, bookingStatus);
        }

}
