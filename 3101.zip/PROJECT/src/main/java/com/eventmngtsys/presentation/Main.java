
package com.eventmngtsys.presentation;

//import com.eventmngtsys.JDBCConnection.TestConnection;
//import com.eventmngtsys.entity.*;
//import com.eventmngtsys.service.AdminService;
//import com.eventmngtsys.service.AttendeeService;
//import com.eventmngtsys.service.OrganiserService;
//import com.eventmngtsys.service.impl.AdminServiceImpl;
//import com.eventmngtsys.service.impl.AttendeeServiceImpl;
//import com.eventmngtsys.service.impl.OrganiserServiceImpl;
//import com.eventmngtsys.validators.InputValidator;
//
//import java.sql.*;
//import java.util.Scanner;
//
//public class Main {
//
//    public static Connection connection = TestConnection.test();
//    public static Scanner sc = new Scanner(System.in);
//    public static String userRole;
//    public static int id;
//
//    public static void main(String[] args) {
//        AdminService adminService = new AdminServiceImpl();
//        try {
//            System.out.println("1. LOGIN");
//            System.out.println("2. SIGNUP");
//            String ls = sc.nextLine().trim();
//            switch(Integer.parseInt(ls)){
//                case 1:
//                    Login login = InputValidator.getValidUsersLoginDetails(sc);
//                    if (adminService.validateUserCredentials(login.getUsername(), login.getPassword())) {
//                        userRole = adminService.getUserRole(login.getUsername());
//                        id = adminService.getUserId(login.getUsername());
//                    } else {
//                        System.out.println("FAILED TO LOGIN");
//                        return;
//                    }
//                    break;
//                case 2:
//                    adminService.addUser(InputValidator.getUserDetails(sc));
//                    break;
//                default:
//                    System.out.println("INVALID");
//            }
//
//            boolean running = true;
//            while (running) {
//                //displayMainMenu();
//                String roleInput = userRole;
//
//                switch (roleInput) {
//                    case "ADMIN":
//                        handleAdmin(id);
//                        break;
//                    case "ORGANISER":
//                        handleOrganiser(id);
//                        break;
//                    case "USER":
//                        handleUser(id);
//                        break;
//                    case "":
//                        System.out.println("Exiting the program.");
//                        running = false;
//                        break;
//                    default:
//                        System.out.println("Invalid choice. Please enter again.");
//                }
//            }
//        } catch (Exception e) {
//            System.out.println("An unexpected error occurred: " + e.getMessage());
//        }
//    }
//
////    private static void displayMainMenu() {
////        System.out.println("_____________________");
////        System.out.println("| SELECT            |");
////        System.out.println("|___________________|");
////        System.out.println("| 1. ADMIN          |");
////        System.out.println("| 2. ORGANISER      |");
////        System.out.println("| 3. USER           |");
////        System.out.println("| 4. QUIT           |");
////        System.out.print("|___________________|\n-->");
////    }
//
//    private static void handleAdmin(int id) {
//        AdminService adminService = new AdminServiceImpl();
//        System.out.println("____________________________");
//        System.out.println("|        ADMIN ACTIONS     |");
//        System.out.println("|__________________________|");
//        System.out.println("| 1. Add User              |");
//        System.out.println("| 2. View All Users        |");
//        System.out.println("| 3. Delete User           |");
//        System.out.println("| 4. Manage Roles          |");
//        System.out.println("| 5. View All Events       |");
//        System.out.println("|__________________________|");
//        System.out.print("-->");
//
//        int choice = getChoiceFromUser();
//        try {
//            switch (choice) {
//                case 1: addUser(adminService); break;
//                case 2: viewAllUsers(adminService); break;
//                case 3: deleteUser(adminService); break;
//                case 4: manageRoles(adminService); break;
//                case 5: viewAllEvents(adminService); break;
//                default: System.out.println("Invalid choice."); break;
//            }
//        } catch (Exception e) {
//            System.out.println("Error handling admin actions: " + e.getMessage());
//        }
//    }
//
//    private static int getChoiceFromUser() {
//        int choice = -1;
//        try {
//            choice = Integer.parseInt(sc.nextLine().trim());
//        } catch (NumberFormatException e) {
//            System.out.println("Invalid input. Please enter a valid number.");
//        }
//        return choice;
//    }
//
//    private static void addUser(AdminService adminService) {
//        User user = InputValidator.getUserDetails(sc);
//        if (adminService.addUser(user)) {
//            System.out.println("____________________________");
//            System.out.println("| User Added Successfully   |");
//            System.out.println("|___________________________|");
//        } else {
//            System.out.println("____________________________");
//            System.out.println("| ! Failed To Add User      |");
//            System.out.println("|___________________________|");
//        }
//    }
//
//    private static void viewAllUsers(AdminService adminService) {
//        System.out.println(" ___________________");
//        System.out.println("| LIST OF ALL USERS |");
//        System.out.println("|___________________|");
//        System.out.println("______________________________________________________________________________");
//        System.out.printf("| %-8s | %-17s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL", "ROLE");
//        System.out.println("------------------------------------------------------------------------------");
//        adminService.viewAllUsers();
//        System.out.println("------------------------------------------------------------------------------");
//    }
//
//    private static void deleteUser(AdminService adminService) {
//        viewAllUsers(adminService);
//        int userIdToDelete = InputValidator.getValidUserId(sc);
//        if (adminService.deleteUser(userIdToDelete)) {
//            System.out.println("____________________________");
//            System.out.println("| User Deleted Successfully |");
//            System.out.println("|___________________________|");
//        } else {
//            System.out.println("____________________________");
//            System.out.println("| ! Failed To Delete User   |");
//            System.out.println("|___________________________|");
//        }
//    }
//
//    private static void manageRoles(AdminService adminService) {
//        viewAllUsers(adminService);
//        String role = InputValidator.getValidRole(sc);
//        if (adminService.manageRoles(new User(role, id))) {
//            System.out.println("_____________________________");
//            System.out.println("| Role Updated Successfully |");
//            System.out.println("|___________________________|");
//        } else {
//            System.out.println("_____________________________");
//            System.out.println("| ! Failed To Update Role   |");
//            System.out.println("|___________________________|");
//        }
//    }
//
//    private static void viewAllEvents(AdminService adminService) {
//        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
//        System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
//        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
//        adminService.viewAllEvents();
//        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
//    }
//
//    private static void handleOrganiser(int id) {
//        OrganiserService organiserService = new OrganiserServiceImpl();
//        System.out.println("________________________________");
//        System.out.println("|        ORGANISER ACTIONS     |");
//        System.out.println("|______________________________|");
//        System.out.println("| 1. Add Event                 |");
//        System.out.println("| 2. List My Events            |");
//        System.out.println("| 3. View Event Details        |");
//        System.out.println("| 4. Update Event              |");
//        System.out.println("| 5. Delete Event              |");
//        System.out.println("| 6. View Bookings for Event   |");
//        System.out.println("| 7. View Feedback for Events  |");
//        System.out.println("|______________________________|");
//        System.out.print("-->");
//
//        int choice = getChoiceFromUser();
//        try {
//            switch (choice) {
//                case 1: addEvent(organiserService); break;
//                case 2: listMyEvents(organiserService); break;
//                case 3: viewEventDetails(organiserService); break;
//                case 4: updateEvent(organiserService); break;
//                case 5: deleteEvent(organiserService); break;
//                case 6: viewBookingsForEvent(organiserService); break;
//                case 7: viewFeedbackForEvents(organiserService); break;
//                default: System.out.println("Invalid choice."); break;
//            }
//        } catch (Exception e) {
//            System.out.println("Error handling organiser actions: " + e.getMessage());
//        }
//    }
//
//    private static void addEvent(OrganiserService organiserService) {
//        Event event = InputValidator.getEventDetails(sc);
//        if (organiserService.addEvent(event)) {
//            System.out.println("____________________________");
//            System.out.println("| Event Added Successfully   |");
//            System.out.println("|___________________________|");
//        } else {
//            System.out.println("____________________________");
//            System.out.println("| ! Failed To Add Event      |");
//            System.out.println("|___________________________|");
//        }
//    }
//
//    private static void listMyEvents(OrganiserService organiserService) {
//        organiserService.listMyEvents(id);
//    }
//
//    private static void viewEventDetails(OrganiserService organiserService) {
//        organiserService.viewEventDetails();
//    }
//
//    private static void updateEvent(OrganiserService organiserService) {
//        Event event = InputValidator.getEventDetails(sc);
//        if (organiserService.updateEvent(event)) {
//            System.out.println("____________________________");
//            System.out.println("| Event Updated Successfully |");
//            System.out.println("|____________________________|");
//        } else {
//            System.out.println("____________________________");
//            System.out.println("| ! Failed To Update Event   |");
//            System.out.println("|____________________________|");
//        }
//    }
//
//    private static void deleteEvent(OrganiserService organiserService) {
//        int eventId = InputValidator.getValidEventId(sc);
//        if (organiserService.deleteEvent(eventId)) {
//            System.out.println("____________________________");
//            System.out.println("| Event Deleted Successfully |");
//            System.out.println("|____________________________|");
//        } else {
//            System.out.println("____________________________");
//            System.out.println("| ! Failed To Delete Event   |");
//            System.out.println("|____________________________|");
//        }
//    }
//
//    private static void viewBookingsForEvent(OrganiserService organiserService) {
//        organiserService.viewBookingsForEvent(id);
//    }
//
//    private static void viewFeedbackForEvents(OrganiserService organiserService) {
//        organiserService.viewFeedBackForEvents(id);
//    }
//
//    private static void handleUser(int id) {
//        AttendeeService attendeeService = new AttendeeServiceImpl();
//        System.out.println("____________________________");
//        System.out.println("|     ATTENDEE ACTIONS      |");
//        System.out.println("|___________________________|");
//        System.out.println("| 1. Book Event             |");
//        System.out.println("| 2. View Booked Events     |");
//        System.out.println("| 3. Cancel Booking         |");
//        System.out.println("| 4. Provide Feedback       |");
//        System.out.println("| 5. View Event Details     |");
//        System.out.println("|___________________________|");
//        System.out.print("-->");
//
//        int choice = getChoiceFromUser();
//        try {
//            switch (choice) {
//                case 1: bookEvent(attendeeService); break;
//                case 2: viewBookedEvents(attendeeService); break;
//                case 3: cancelBooking(attendeeService); break;
//                case 4: provideFeedback(attendeeService); break;
//                case 5: viewEventDetails(attendeeService); break;
//                default: System.out.println("Invalid choice."); break;
//            }
//        } catch (Exception e) {
//            System.out.println("Error handling attendee actions: " + e.getMessage());
//        }
//    }
//
//    private static void bookEvent(AttendeeService attendeeService) {
//        int eventId = InputValidator.getValidEventId(sc);
//        int seatsBooked = InputValidator.getValidSeats(sc, eventId);
//        if (attendeeService.bookEvent(new Booking(eventId, id, seatsBooked))) {
//            System.out.println("____________________________");
//            System.out.println("| Event Booked Successfully |");
//            System.out.println("|___________________________|");
//        } else {
//            System.out.println("____________________________");
//            System.out.println("| ! Failed To Book Event    |");
//            System.out.println("|___________________________|");
//        }
//    }
//
//    private static void viewBookedEvents(AttendeeService attendeeService) {
//        attendeeService.viewBookedEvents(id);
//    }
//
//    private static void cancelBooking(AttendeeService attendeeService) {
//        int bookingId = InputValidator.getValidBookingId(sc);
//        if (attendeeService.cancelBooking(bookingId, id)) {
//            System.out.println("____________________");
//            System.out.println("| BOOKING CANCELLED |");
//            System.out.println("|___________________|");
//        } else {
//            System.out.println("______________________");
//            System.out.println("| ! Failed To CANCEL  |");
//            System.out.println("|_____________________|");
//        }
//    }
//
//    private static void provideFeedback(AttendeeService attendeeService) {
//        Feedback feedback = InputValidator.getValidFeedbackDetails(sc);
//        if (attendeeService.provideFeedback(feedback)) {
//            System.out.println("__________________________________");
//            System.out.println("| Feedback Submitted Successfully |");
//            System.out.println("|_________________________________|");
//        } else {
//            System.out.println("_______________________________");
//            System.out.println("| ! Failed To Submit Feedback  |");
//            System.out.println("|______________________________|");
//        }
//    }
//
//    private static void viewEventDetails(AttendeeService attendeeService) {
//        attendeeService.viewEventDetails();
//    }
//}



//package com.eventmngtsys.presentation;
//
import com.eventmngtsys.JDBCConnection.TestConnection;
import com.eventmngtsys.entity.*;
import com.eventmngtsys.service.AdminService;
import com.eventmngtsys.service.AttendeeService;
import com.eventmngtsys.service.OrganiserService;
import com.eventmngtsys.service.impl.AdminServiceImpl;
import com.eventmngtsys.service.impl.AttendeeServiceImpl;
import com.eventmngtsys.service.impl.OrganiserServiceImpl;
import com.eventmngtsys.validators.InputValidator;

import java.sql.*;
import java.util.Scanner;


public class Main {

    public static Connection connection = TestConnection.test();
    public static Scanner sc = new Scanner(System.in);
    private static int choice;
    private static String eventName;
    private static String description;
    private static int organiserId;
    private static Date eventDate;
    private static Time eventTime;
    private static String venue;
    private static int capacity;
    private static String status;
    private static long price;
    private static int bookingId;
    private static int eventId;
    private static int seatsBooked;
    private static int userId;
    private static int id;
    private static String role;
    private static String userRole;

    public static void main(String[] args) {

        Login login = InputValidator.getValidUsersLoginDetails(sc);
        AdminService adminService = new AdminServiceImpl();
        if(adminService.validateUserCredentials(login.getUsername(), login.getPassword())){
            userRole = adminService.getUserRole(login.getUsername());
            id = adminService.getUserId(login.getUsername());
        }else{
            System.out.println("FAILED TO LOGIN");
        }

        try {
            boolean running = true;
            while (running) {
                System.out.println("_____________________");
                System.out.println("| SELECT            |"+ "\n|___________________|"+"\n| 1.ADMIN           |" + "\n| 2.ORGANISER       |" +"\n| 3.USER            |"+"\n| 4.QUIT            |");
                System.out.print("|___________________|\n-->");
                if (!sc.hasNextLine()) {
                    System.out.println("No input detected. Exiting...");
                    running = false;
                    continue;
                }
                String roleInput = sc.nextLine().trim();

                int role;
                try {
                    role = Integer.parseInt(roleInput);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                    continue;
                }

                switch (userRole) {
                    case "ADMIN": // Admin

                        handleAdmin(id);

                        break;
                    case "ORGANISER": // Organiser

                        handleOrganiser(id,userRole);

                        break;
                    case "USER": // User

                        handleUser(id);

                        break;
                    case "": // Quit
                        System.out.println("Exiting the program.");
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid role. Please enter again.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sc.close(); // Close scanner ONLY here
            try {
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void handleUser(int id) {
        AttendeeService attendeeService = new AttendeeServiceImpl();
        System.out.println("____________________________");
        System.out.println("|     ATTENDEE ACTIONS      |");
        System.out.println("|___________________________|");
        System.out.println("| 1. Book Event             |");
        System.out.println("| 2. View Booked Events     |");
        System.out.println("| 3. Cancel Booking         |");
        System.out.println("| 4. Provide Feedback       |");
        System.out.println("| 5. View Event Details     |");
        System.out.println("|___________________________|");
        System.out.print("-->");
        int choice = 0;
        try {
            choice = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }

        try{
            switch (choice) {
                case 1:
                    try {
                        // Validating Event Id
                        eventId = InputValidator.getValidEventId(sc);
                        OrganiserService organiserService = new OrganiserServiceImpl();

                        if (organiserService.userVerifyEventId(eventId)) break;
                        else System.out.println("Event ID does not exist. Please enter a valid EVENT ID.");

                        userId = id;
                        seatsBooked = InputValidator.getValidSeats(sc,eventId);

                        if (organiserService.checkSeatCapacity(eventId, seatsBooked)) break;
                        else System.out.println("CAPACITY EXCEEDED: \n-->");

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if(attendeeService.bookEvent(new Booking(eventId, userId, seatsBooked))){
                        System.out.println("____________________________");
                        System.out.println("| Event Booked Successfully |");
                        System.out.println("|___________________________|");
                    }else{
                        System.out.println("____________________________");
                        System.out.println("| ! Failed To Book Event    |");
                        System.out.println("|___________________________|");
                    }
                    break;
                case 2:
                    attendeeService.viewBookedEvents(id);
                    break;
                case 3:
                    bookingId = InputValidator.getValidBookingId(sc);
                    if(attendeeService.cancelBooking(bookingId, id)){
                        System.out.println("____________________");
                        System.out.println("| BOOKING CANCELLED |");
                        System.out.println("|___________________|");
                    }else{
                        System.out.println("______________________");
                        System.out.println("| ! Failed To CANCEL  |");
                        System.out.println("|_____________________|");
                    }
                    break;
                case 4:
                    Feedback feedback = InputValidator.getValidFeedbackDetails(sc);
                    if(attendeeService.provideFeedback(feedback)){
                        System.out.println("__________________________________");
                        System.out.println("| Feedback Submitted Successfully |");
                        System.out.println("|_________________________________|");
                    }else{
                        System.out.println("_______________________________");
                        System.out.println("| ! Failed To Submit Feedback  |");
                        System.out.println("|______________________________|");
                    }
                    break;
                case 5:
                    attendeeService.viewEventDetails();
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void handleOrganiser(int id, String userRole){
        OrganiserService organiserService = new OrganiserServiceImpl();
        System.out.println("________________________________");
        System.out.println("|        ORGANISER ACTIONS     |");
        System.out.println("|______________________________|");
        System.out.println("| 1. Add Event                 |");
        System.out.println("| 2. List My Events            |");
        System.out.println("| 3. View Event Details        |");
        System.out.println("| 4. Update Event              |");
        System.out.println("| 5. Delete Event              |");
        System.out.println("| 6. View Bookings for Event   |");
        System.out.println("| 7. View Feedback for Events  |");
        System.out.println("|______________________________|");
        System.out.print("-->");

        choice = 0;
        try {
            choice = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }

        try {
            switch (choice) {
                case 1:
                    Event event = InputValidator.getEventDetails(sc);
                    System.out.println("_________________");
                    System.out.println("| ADD NEW EVENT |");
                    System.out.println("|_______________|");
                    System.out.println();
                    if(organiserService.addEvent(new Event(organiserId,capacity,price,eventName,description,venue,status,eventDate,eventTime))){
                        System.out.println("____________________________");
                        System.out.println("| Event Added Successfully  |");
                        System.out.println("|___________________________|");
                    }else{
                        System.out.println("____________________________");
                        System.out.println("| ! Failed To Add Event     |");
                        System.out.println("|___________________________|");
                    }
                    break;
                case 2:
                    organiserId = id;
                    System.out.println("_________________________");
                    System.out.println("| LIST OF ALL MY EVENTS |");
                    System.out.println("|_______________________|");
                    System.out.println();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    organiserService.listMyEvents(organiserId);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("_____________________");
                    System.out.println("| LIST OF ALL EVENTS |");
                    System.out.println("|____________________|");
                    System.out.println();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    organiserService.viewEventDetails();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;
                case 4:
                    event = InputValidator.getEventDetails(sc);
                    /*
                    Update Event Details
                     */
                    if(organiserService.updateEvent(event)){
                        System.out.println("______________________________");
                        System.out.println("| Event UPDATED Successfully  |");
                        System.out.println("|_____________________________|");
                    }else{
                        System.out.println("__________________________");
                        System.out.println("| FAILED To UPDATE Event  |");
                        System.out.println("|_________________________|");
                    }
                    break;
                case 5:
                    eventId = InputValidator.getValidEventId(sc);
                    if(organiserService.deleteEvent(eventId)){
                        System.out.println("_____________________________");
                        System.out.println("| Event Deleted Successfully |");
                        System.out.println("|____________________________|");
                    }else{
                        System.out.println("____________________________");
                        System.out.println("| ! Failed To Delete Event  |");
                        System.out.println("|___________________________|");
                    }
                    break;
                case 6:
                    organiserId = id;
                    organiserService.viewBookingsForEvent(organiserId);
                    break;
                case 7:
                    organiserId = id;
                    System.out.println("----------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-10s | %-7s | %-50s |%n", "EVENTID", "USERID", "RATING", "COMMENTS");
                    System.out.println("----------------------------------------------------------------------");
                    organiserService.viewFeedBackForEvents(organiserId);
                    System.out.println("----------------------------------------------------------------------");
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void handleAdmin(int id){
        AdminService adminService = new AdminServiceImpl();

        System.out.println("____________________________");
        System.out.println("|        ADMIN ACTIONS     |");
        System.out.println("|__________________________|");
        System.out.println("| 1. Add User              |");
        System.out.println("| 2. View All Users        |");
        System.out.println("| 3. Delete User           |");
        System.out.println("| 4. Manage Roles          |");
        System.out.println("| 5. View All Events       |");
        System.out.println("|__________________________|");
        System.out.print("-->");

        choice = 0;
        try {
            choice = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }

        try{

            switch (choice) {
                case 1:
                    User user = InputValidator.getUserDetails(sc);

                    System.out.println("_______________");
                    System.out.println("| ADD NEW USER |");
                    System.out.println("|______________|");
                    System.out.println();
                    if(adminService.addUser(user)){
                        System.out.println("____________________________");
                        System.out.println("| User Added Successfully   |");
                        System.out.println("|___________________________|");
                    }else{
                        System.out.println("____________________________");
                        System.out.println("| ! Failed To Add User      |");
                        System.out.println("|___________________________|");
                    }
                    break;
                case 2:
                    System.out.println(" ___________________");
                    System.out.println("| LIST OF ALL USERS |");
                    System.out.println("|___________________|");
                    System.out.println();
                    System.out.println("______________________________________________________________________________");
                    System.out.printf("| %-8s | %-17s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL", "ROLE");
                    System.out.println("------------------------------------------------------------------------------");
                    adminService.viewAllUsers();
                    System.out.println("------------------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("____________________");
                    System.out.println("| LIST OF ALL USERS |");
                    System.out.println("|___________________|");
                    System.out.println();
                    System.out.println("______________________________________________________________________________");
                    System.out.printf("| %-8s | %-17s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL", "ROLE");
                    System.out.println("------------------------------------------------------------------------------");
                    adminService.viewAllUsers();
                    System.out.println("------------------------------------------------------------------------------");
                    /*
                    Get User ID to Delete User
                     */
                    userId = id;

                    if(adminService.deleteUser(userId)){
                        System.out.println("____________________________");
                        System.out.println("| User Deleted Successfully |");
                        System.out.println("|___________________________|");
                    }else{
                        System.out.println("____________________________");
                        System.out.println("| ! Failed To Delete User   |");
                        System.out.println("|___________________________|");
                    }
                    break;
                case 4:
                    System.out.println("____________________");
                    System.out.println("| LIST OF ALL USERS |");
                    System.out.println("|___________________|");
                    System.out.println();
                    System.out.println("______________________________________________________________________________");
                    System.out.printf("| %-8s | %-17s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL", "ROLE");
                    System.out.println("------------------------------------------------------------------------------");
                    adminService.viewAllUsers();
                    System.out.println("------------------------------------------------------------------------------");
                    /*
                    Getting userId and role to update
                     */
                    userId = id;
                    String role = InputValidator.getValidRole(sc);

                    if(adminService.manageRoles(new User(role,userId))){
                        System.out.println("_____________________________");
                        System.out.println("| Role Updated Successfully |");
                        System.out.println("|___________________________|");
                    }else{
                        System.out.println("_____________________________");
                        System.out.println("| ! Failed To Update Role   |");
                        System.out.println("|___________________________|");
                    }

                    break;
                case 5:
                    System.out.println("______________________");
                    System.out.println("| LIST OF ALL EVENTS |");
                    System.out.println("|____________________|");
                    System.out.println();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    adminService.viewAllEvents();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}