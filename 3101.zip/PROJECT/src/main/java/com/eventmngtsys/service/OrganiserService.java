package com.eventmngtsys.service;

import com.eventmngtsys.entity.Event;

public interface OrganiserService {

    boolean addEvent(Event event);
    void listMyEvents(int orgId);
    void viewEventDetails();
    boolean updateEvent(Event event);
    boolean deleteEvent(int eventId);
    void viewBookingsForEvent(int orgId);
    void viewFeedBackForEvents(int orgId);
    boolean checkSeatCapacity(int eventId, int seatsBooked);

    boolean userVerifyEventId(int eventId);
}
