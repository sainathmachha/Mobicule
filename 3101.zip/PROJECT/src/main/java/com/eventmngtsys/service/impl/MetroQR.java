package com.eventmngtsys.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import net.glxn.qrgen.QRCode;

import static sun.java2d.cmm.ColorTransform.Out;

public class MetroQR {

    public static void main(String[] args) throws IOException {
        generateTicket(1,2,"2025-02-05","05:30:00",10,2500);
    }

    public static void generateTicket(int eventId, int userId, String eventDate, String eventTime,int seatsBooked, int price) throws IOException {

    }

}
