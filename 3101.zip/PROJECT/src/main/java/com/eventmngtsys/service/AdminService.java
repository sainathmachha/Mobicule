package com.eventmngtsys.service;

import com.eventmngtsys.entity.User;

public interface AdminService{
        //User table
        boolean addUser(User user);
        void viewAllUsers();
        boolean deleteUser(int userId);
        boolean manageRoles(User user);

        //Events
        void viewAllEvents();
        boolean validateUserCredentials(String username, String password);

        String getUserRole(String username);

        int getUserId(String username);
}
