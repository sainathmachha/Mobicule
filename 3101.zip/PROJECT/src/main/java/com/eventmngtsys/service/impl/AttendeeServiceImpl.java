package com.eventmngtsys.service.impl;

import com.eventmngtsys.dao.AttendeeDAO;
import com.eventmngtsys.dao.impl.AttendeeDAOImpl;
import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Feedback;
import com.eventmngtsys.service.AttendeeService;

import static com.eventmngtsys.presentation.Main.connection;

public class AttendeeServiceImpl implements AttendeeService {

    AttendeeDAO attendeeDAO = new AttendeeDAOImpl(connection);

    @Override
    public boolean bookEvent(Booking booking) {
        return attendeeDAO.createBooking(booking);
    }

    @Override
    public void viewBookedEvents(int userId) {
        attendeeDAO.viewBookedEvents(userId);
    }

    @Override
    public boolean cancelBooking(int bookingId, int userId) {
        return attendeeDAO.cancelBookedEvent(bookingId,userId);
    }

    @Override
    public boolean provideFeedback(Feedback feedback) {
        return attendeeDAO.createFeedback(feedback);
    }

    @Override
    public void viewEventDetails() {
        new OrganiserServiceImpl().viewEventDetails();
    }

}
