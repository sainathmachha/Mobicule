package com.eventmngtsys.service.impl;

import com.eventmngtsys.dao.AdminDAO;
import com.eventmngtsys.dao.impl.AdminDAOImpl;
import com.eventmngtsys.entity.Event;
import com.eventmngtsys.entity.User;
import com.eventmngtsys.service.AdminService;

import java.sql.Connection;

import java.sql.*;
import java.util.List;
import java.util.Scanner;

public class AdminServiceImpl implements AdminService {

    String query = "";
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet resultSet;
    Scanner sc = new Scanner(System.in);
    String email, password, role;

    private String username;
    private Connection connection = null;

    AdminDAO adminDAO = new AdminDAOImpl();
    @Override
    public void viewAllUsers() {
        for(User u : adminDAO.viewAllUsers()){
            System.out.print(u);
        }
    }

    @Override
    public boolean deleteUser(int userId) {
        return adminDAO.deleteUserFromDB(userId);
    }

    @Override
    public boolean manageRoles(User user) {
        return adminDAO.manageRoles(user);
    }

    @Override
    public void viewAllEvents() {
        for(Event event: adminDAO.viewAllEventFromDB()){
            System.out.print(event);
        }
    }

    @Override
    public boolean validateUserCredentials(String username, String password) {
        return adminDAO.validateUserCredentials(username,password);
    }

    @Override
    public String getUserRole(String username) {
        return adminDAO.getUserRole(username);
    }

    @Override
    public int getUserId(String username) {
        return adminDAO.getUserId(username);
    }

    @Override
    public boolean addUser(User user) {
        return adminDAO.addUserInDB(user);
    }
}
