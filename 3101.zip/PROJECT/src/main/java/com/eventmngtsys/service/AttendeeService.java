package com.eventmngtsys.service;

import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Event;
import com.eventmngtsys.entity.Feedback;

public interface AttendeeService {

    boolean bookEvent(Booking booking);
    void viewBookedEvents(int userId);
    boolean cancelBooking(int bookingId, int userId);
    boolean provideFeedback(Feedback feedback);

    void viewEventDetails();
}
