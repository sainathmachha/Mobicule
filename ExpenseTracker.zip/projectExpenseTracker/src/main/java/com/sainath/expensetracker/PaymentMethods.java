package com.sainath.expensetracker;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum PaymentMethods implements EnumClass<String> {

    UPI("Upi"),
    CREDIT_CARD("Credit Card"),
    DEBIT_CARD("Debit Card"),
    CASH("Cash");

    private final String id;

    PaymentMethods(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static PaymentMethods fromId(String id) {
        for (PaymentMethods at : PaymentMethods.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
