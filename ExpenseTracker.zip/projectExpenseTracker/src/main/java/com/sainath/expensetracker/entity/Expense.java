package com.sainath.expensetracker.entity;

import com.sainath.expensetracker.Category;
import com.sainath.expensetracker.PaymentMethods;
import io.jmix.core.DeletePolicy;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.UUID;

@JmixEntity
@Table(name = "EXPENSE", indexes = {
        @Index(name = "IDX_EXPENSE_USER", columnList = "USER_ID")
})
@Entity
public class Expense {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;
    @Column(name = "DATE")
    private LocalDate date;
    @Column(name = "AMOUNT", nullable = false)
    @NotNull
    private Long amount;
    @Column(name = "CATEGORY")
    private String category;
    @Column(name = "PAYMENT_METHOD")
    private String paymentMethod;
    @InstanceName
    @Column(name = "DESCRIPTION")
    @Lob
    private String description;
    @OnDeleteInverse(DeletePolicy.CASCADE)
    @JoinColumn(name = "USER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public PaymentMethods getPaymentMethod() {
        return paymentMethod == null ? null : PaymentMethods.fromId(paymentMethod);
    }

    public void setPaymentMethod(PaymentMethods paymentMethod) {
        this.paymentMethod = paymentMethod == null ? null : paymentMethod.getId();
    }

    public Category getCategory() {
        return category == null ? null : Category.fromId(category);
    }

    public void setCategory(Category category) {
        this.category = category == null ? null : category.getId();
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}
