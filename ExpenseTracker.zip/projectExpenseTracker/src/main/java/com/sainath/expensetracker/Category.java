package com.sainath.expensetracker;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum Category implements EnumClass<String> {

    FOOD("Food"),
    SHOPPING("Shopping"),
    TRAVEL("Travel"),
    BILLS("Bills");

    private final String id;

    Category(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static Category fromId(String id) {
        for (Category at : Category.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
