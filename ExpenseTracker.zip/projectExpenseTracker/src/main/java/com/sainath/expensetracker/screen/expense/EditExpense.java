package com.sainath.expensetracker.screen.expense;

import com.sainath.expensetracker.entity.Expense;
import io.jmix.core.DataManager;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.Screens;
import io.jmix.ui.builder.ScreenBuilder;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import liquibase.pro.packaged.S;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.PostPersist;
import javax.persistence.PrePersist;

@UiController("Edit.expense")
@UiDescriptor("edit-expense.xml")
@EditedEntityContainer("expenseDc")
public class EditExpense extends StandardEditor<Expense> {
}
