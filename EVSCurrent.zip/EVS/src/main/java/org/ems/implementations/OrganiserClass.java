package org.ems.implementations;

import org.ems.interfaces.Organiser;

import java.sql.*;
import java.util.Scanner;

public class OrganiserClass implements Organiser {
    String query = "";
    Connection connection;
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet resultSet;
    Scanner sc = new Scanner(System.in);
    private String eventName;
    private String description;
    private int organizerId;
    private Date date;
    private Time time;
    private String eventVenue;
    private int capacity;
    private String status;
    private int eventId;

    public void getOrgList(Connection connection){
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++ LIST OF ORGANISERS +++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        query = "SELECT userId, name FROM USERI1436 WHERE role = 'ORGANISER'";
        try {
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                System.out.println("USER ID : "+resultSet.getInt(1)+"\n"+"NAME : " + resultSet.getString(2)+"\n");
                System.out.println();
            }
        } catch (SQLException e) {
            e.getMessage();
        }
    }

    public boolean checkIfAnOrgOrNot(Connection connection, int organizerId) {
        int count = 0;
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE role = 'ORGANISER' AND userId = ?";
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            if (connection == null) {
                System.out.println("Connection is null");
                return false;
            }

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, organizerId);
            resultSet = preparedStatement.executeQuery();

            if (resultSet == null) {
                System.out.println("ResultSet is null");
                return false;
            }

            while (resultSet.next()) {
                count = resultSet.getInt(1);
                if (count == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return false;
    }


    @Override
    public void addEvent(Connection connection, int userId) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        AdminClass admin = new AdminClass();
        Scanner sc = new Scanner(System.in); // Make sure you have this Scanner instance

        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++ ADD EVENT +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "INSERT INTO EVENTSI1436(eventName, description, organiserId, date, time, venue, capacity, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = null;

        try {
            preparedStatement = connection.prepareStatement(query);

            // Validating Event Name
            System.out.print("Enter Event Name: \n-->");
            String eventName = sc.nextLine().trim();
            while (!eventName.matches("^[A-Za-z\\s]+$")) {
                System.out.println("! Invalid Event Name");
                System.out.print("-->");
                eventName = sc.nextLine().trim();
            }
            preparedStatement.setString(1, eventName);
            System.out.println();

            // Description
            System.out.print("Enter Description: \n-->");
            String description = sc.nextLine().trim();
            preparedStatement.setString(2, description);
            System.out.println();

            getOrgList(connection);

            // Validating Organiser ID
            System.out.print("Enter Organiser ID: \n-->");
            int organiserId = userId; // Assuming userId is the organiser ID
            if (checkIfAnOrgOrNot(connection, organiserId)) {
                preparedStatement.setInt(3, organiserId);
            } else {
                System.out.println("_____________________________________     ___________________");
                System.out.println("| The ID You Entered Doesn't Exist   | OR | Not An ORGANISER |");
                System.out.println("|____________________________________|    |__________________");
                System.out.println();
                System.out.println("_______________________________     _________________________");
                System.out.println("| Do you want to ADD ORGANISER | OR | UPDATE ROLE (yes/no)?  |");
                System.out.println("|______________________________|    |________________________|");
                String output = sc.next().trim().toLowerCase();
                if (output.equals("yes") || output.equals("y")) {
                    System.out.println("1. Add Organiser");
                    System.out.println("2. Update Role");
                    System.out.print("Select An Option: ");
                    int choice = sc.nextInt();
                    sc.nextLine();
                    switch (choice) {
                        case 1:
                            admin.addUser(connection);
                            break;
                        case 2:
                            admin.manageRoles(connection);
                            break;
                    }
                }
                return; // Exit the function if the organiser ID is invalid
            }
            System.out.println();

            // Validating Date
            System.out.print("Enter Date (YYYY-MM-DD): \n-->");
            Date date = Date.valueOf(sc.nextLine().trim());
            while (!date.toString().matches("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")) {
                System.out.println("! INVALID DATE");
                System.out.print("-->");
                date = Date.valueOf(sc.nextLine().trim());
            }
            preparedStatement.setDate(4, date);
            System.out.println();

            // Validating Time
            System.out.print("Enter Time (HH:MM:SS): \n-->");
            Time time = Time.valueOf(sc.nextLine().trim());
            while (!time.toString().matches("^[0-9]{2}:[0-9]{2}:[0-9]{2}$")) {
                System.out.println("! INVALID TIME");
                System.out.print("-->");
                time = Time.valueOf(sc.nextLine().trim());
            }
            preparedStatement.setTime(5, time);
            System.out.println();

            // Validating Venue
            System.out.print("Enter Venue: \n-->");
            String venue = sc.nextLine().trim();
            while (!venue.matches("^[A-Za-z0-9\\-,.:'{}()\\s]+$")) {
                System.out.println("! Invalid Venue Name");
                System.out.print("-->");
                venue = sc.nextLine().trim();
            }
            preparedStatement.setString(6, venue);
            System.out.println();

            // Validating Capacity
            System.out.print("Enter Capacity: \n-->");
            int capacity = sc.nextInt();
            while (!String.valueOf(capacity).matches("^[0-9]+$")) {
                System.out.println("! INVALID CAPACITY");
                System.out.print("-->");
                capacity = sc.nextInt();
            }
            preparedStatement.setInt(7, capacity);
            sc.nextLine();
            System.out.println();

            // Validating Status
            System.out.print("Enter Status (SCHEDULED, RESCHEDULED, ON HOLD, IN PROGRESS, COMPLETED, DELAYED, CANCELLED): \n-->");
            String status = sc.nextLine().trim().toUpperCase();
            while (!status.matches("^(SCHEDULED|RESCHEDULED|ON HOLD|IN PROGRESS|COMPLETED|DELAYED|CANCELLED)$")) {
                System.out.println("! INVALID STATUS");
                System.out.print("-->");
                status = sc.nextLine().trim().toUpperCase();
            }
            preparedStatement.setString(8, status);
            System.out.println();

            int i = preparedStatement.executeUpdate();
            if (i >= 1) {
                System.out.println("____________________________");
                System.out.println("| Event Added Successfully  |");
                System.out.println("|___________________________|");
                System.out.println();
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Add Event     |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void listMyEvents(Connection connection, int userId) {
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ LIST OF MY EVENTS ++++++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        query = "SELECT eventId, eventName, description,capacity,status FROM EVENTSI1436 WHERE organiserId = ? ;";

        try {
            System.out.println();
            preparedStatement = connection.prepareStatement(query);
            int orgId = userId;
            while(!checkIfAnOrgOrNot(connection, orgId)) {
                sc.nextLine();
                System.out.print("! USER IS NOT AN ORGANISER");
                orgId = sc.nextInt();
            }
            preparedStatement.setInt(1, orgId);
            resultSet = preparedStatement.executeQuery();
            System.out.println();
            // Print the header
            System.out.printf("%-10s %-20s %-40s %-10s %-15s%n",
                    "EVENTID",
                    "EVENTNAME",
                    "DESCRIPTION",
                    "CAPACITY",
                    "STATUS");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.println();
            // Iterate through the result set and print the data
            while (resultSet.next()) {
                System.out.printf("%-10s %-20s %-40s %-10s %-15s",
                        resultSet.getInt(1),//eventId
                        resultSet.getString(2),     // eventName
                        resultSet.getString(3),     // description
                        resultSet.getInt(4),
                        resultSet.getString(5));    // status'
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewEventDetails(Connection connection) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ VIEW EVENT DETAILS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "SELECT eventId, eventName, description, organiserId, date, time, venue, capacity, status FROM EVENTSI1436;";
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            // Print the header
            System.out.printf("%-10s %-20s %-40s %-15s %-12s %-12s %-20s %-10s %-10s%n",
                    "EVENTID",
                    "EVENTNAME",
                    "DESCRIPTION",
                    "ORGANISERID",
                    "DATE",
                    "TIME",
                    "VENUE",
                    "CAPACITY",
                    "STATUS");
            System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            // Iterate through the result set and print the data
            while (resultSet.next()) {
                System.out.printf("%-10d %-20s %-40s %-15d %-12s %-12s %-20s %-10d %-10s%n",
                        resultSet.getInt(1),         // eventId
                        resultSet.getString(2),     // eventName
                        resultSet.getString(3),     // description
                        resultSet.getInt(4),        // organizerId
                        resultSet.getDate(5),       // date
                        resultSet.getTime(6),       // time
                        resultSet.getString(7),     // venue
                        resultSet.getInt(8),        // capacity
                        resultSet.getString(9));    // status
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void updateEvent(Connection connection, int userId) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ UPDATE EVENT ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        try {
            // Query to get current values of the event
            String selectQuery = "SELECT eventName, description, organiserId, date, time, venue, capacity, status FROM EVENTSI1436 WHERE eventId = ?";
            PreparedStatement selectStatement = connection.prepareStatement(selectQuery);

            System.out.print("Enter ORGANISER ID : ");
            int orgId = userId;

            System.out.print("Enter Event ID to update: ");
            int eventId = Integer.parseInt(scanner.nextLine());
            selectStatement.setInt(1, eventId);

            ResultSet rs = selectStatement.executeQuery();
            if (rs.next()) {
                String currentEventName = rs.getString("eventName");
                String currentDescription = rs.getString("description");
                int currentOrganizerId = rs.getInt("organiserId");
                Date currentDate = rs.getDate("date");
                Time currentTime = rs.getTime("time");
                String currentVenue = rs.getString("venue");
                int currentCapacity = rs.getInt("capacity");
                String currentStatus = rs.getString("status");

                // Get new values or keep existing
                System.out.print("Enter new Event Name (current: " + currentEventName + "): ");
                String newEventName = scanner.nextLine();
                if (newEventName.isEmpty()) newEventName = currentEventName;

                System.out.print("Enter new Description (current: " + currentDescription + "): ");
                String newDescription = scanner.nextLine();
                if (newDescription.isEmpty()) newDescription = currentDescription;

                System.out.print("Enter new Organizer ID (current: " + currentOrganizerId + "): ");
                String newOrganizerIdInput = scanner.nextLine();
                int newOrganizerId = newOrganizerIdInput.isEmpty() ? currentOrganizerId : Integer.parseInt(newOrganizerIdInput);

                System.out.print("Enter new Date (YYYY-MM-DD) (current: " + currentDate + "): ");
                String newDateInput = scanner.nextLine();
                Date newDate = newDateInput.isEmpty() ? currentDate : Date.valueOf(newDateInput);

                System.out.print("Enter new Time (HH:MM:SS) (current: " + currentTime + "): ");
                String newTimeInput = scanner.nextLine();
                Time newTime = newTimeInput.isEmpty() ? currentTime : Time.valueOf(newTimeInput);

                System.out.print("Enter new Venue (current: " + currentVenue + "): ");
                String newVenue = scanner.nextLine();
                if (newVenue.isEmpty()) newVenue = currentVenue;

                System.out.print("Enter new Capacity (current: " + currentCapacity + "): ");
                String newCapacityInput = scanner.nextLine();
                int newCapacity = newCapacityInput.isEmpty() ? currentCapacity : Integer.parseInt(newCapacityInput);

                System.out.print("Enter new Status (current: " + currentStatus + "): ");
                String newStatus = scanner.nextLine();
                if (newStatus.isEmpty()) newStatus = currentStatus;

                // Update the event
                String updateQuery = "UPDATE EVENTSI1436 SET eventName = ?, description = ?, organiserId = ?, date = ?, time = ?, venue = ?, capacity = ?, status = ? WHERE eventId = ? and organiserId = ? ";
                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);

                updateStatement.setString(1, newEventName);
                updateStatement.setString(2, newDescription);
                updateStatement.setInt(3, newOrganizerId);
                updateStatement.setDate(4, newDate);
                updateStatement.setTime(5, newTime);
                updateStatement.setString(6, newVenue);
                updateStatement.setInt(7, newCapacity);
                updateStatement.setString(8, newStatus);
                updateStatement.setInt(9, eventId);
                updateStatement.setInt(10, orgId);

                int rowsAffected = updateStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("______________________________");
                    System.out.println("| Event UPDATED Successfully  |");
                    System.out.println("|_____________________________|");
                    System.out.println();
                } else {
                    System.out.println("________________________________________");
                    System.out.println("| No event found with the specified ID  |");
                    System.out.println("|_______________________________________|");
                    System.out.println();
                    System.out.println("No event found with the specified ID.");
                }
            } else {
                System.out.println("No event found with the specified ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("An error occurred while updating the event.");
        }
    }





//    @Override
//    public void updateEvent(Connection connection) {
//        System.out.println("++++++++++++++++++++++++++++++++++++++");
//        System.out.println("++++++++++++ UPDATE EVENT ++++++++++++");
//        System.out.println("++++++++++++++++++++++++++++++++++++++");
//        System.out.println();
//
//        query = "SELECT eventId, eventName, description, organizerId, date, time, venue, capacity, status FROM EVENTSI1436;";
//
//        try {
//            statement = connection.createStatement();
//            resultSet = statement.executeQuery(query);
//
//            // Print the header
//            System.out.printf("%-10s %-20s %-40s %-15s %-12s %-12s %-20s %-10s %-10s%n",
//                    "EVENTID",
//                    "EVENTNAME",
//                    "DESCRIPTION",
//                    "ORGANISERID",
//                    "DATE",
//                    "TIME",
//                    "VENUE",
//                    "CAPACITY",
//                    "STATUS");
//
//            System.out.println();
//
//            // Iterate through the result set and print the data
//            while (resultSet.next()) {
//                System.out.printf("%-10d %-20s %-40s %-15d %-12s %-12s %-20s %-10d %-10s%n",
//                        resultSet.getInt(1),         // eventId
//                        resultSet.getString(2),     // eventName
//                        resultSet.getString(3),     // description
//                        resultSet.getInt(4),        // organizerId
//                        resultSet.getDate(5),       // date
//                        resultSet.getTime(6),       // time
//                        resultSet.getString(7),     // venue
//                        resultSet.getInt(8),        // capacity
//                        resultSet.getString(9));    // status
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }

    @Override
    public void deleteEvent(Connection connection, int userId) {
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ DELETE EVENT ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        listMyEvents(connection, userId);

        query = "DELETE FROM EVENTSI1436 WHERE eventId = ? and organiserId = ?;";
        try {
            System.out.println();
            preparedStatement = connection.prepareStatement(query);
            System.out.print("Enter EVENT ID : \n-->");
            eventId = sc.nextInt();
            System.out.println();
            preparedStatement.setInt(1,eventId);

            System.out.print("Enter Organiser ID : \n-->");
            organizerId = userId;
            System.out.println();
            preparedStatement.setInt(2, organizerId);

            int success = preparedStatement.executeUpdate();
            if(success>=1){
                System.out.println("_____________________________");
                System.out.println("| Event Deleted Successfully |");
                System.out.println("|____________________________|");
            }else{
                System.out.println("____________________________");
                System.out.println("| ! Failed To Delete Event  |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean orgVerifyEventId(Connection connection,int eventId) {
        int count = 0;
        String query = "SELECT COUNT(*) FROM EVENTSI1436 WHERE eventId = ? ";

        try {
            if (connection == null) {
                System.out.println("Connection is null");
                return false;
            }
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, eventId);
            resultSet = preparedStatement.executeQuery();

            if (resultSet == null) {
                System.out.println("ResultSet is null");
                return false;
            }

            while (resultSet.next()) {
                count = resultSet.getInt(1);
                if (count == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: " + e.getMessage());
        }

        return false;
    }


    @Override
    public void viewBookingsForEvent(Connection connection, int uid) {
        Scanner sc = new Scanner(System.in);

        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ MY EVENTS ++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String firstQuery = "SELECT eventName, description, organiserId, date, time, status FROM EVENTSI1436 WHERE eventId = ? AND organiserId = ?";
        String secondQuery = "SELECT bookingId, eventId, userId, seatsBooked, bookingStatus, seatsLeft FROM BOOKINGSI1436 WHERE bookingStatus = 'BOOKED' AND eventId = ?";

        try {
            System.out.print("Enter Organiser ID: \n-->");
            int organiserId = uid;

            while(true){
                System.out.print("Enter EVENT ID: \n-->");
                eventId = Integer.parseInt(sc.nextLine());
                if(String.valueOf(eventId).matches("^[0-9]+$")){
                    break;
                }
                System.out.println("! Invalid EventId");
            }

            PreparedStatement firstPreparedStatement = connection.prepareStatement(firstQuery);
            firstPreparedStatement.setInt(1, eventId);
            firstPreparedStatement.setInt(2, organiserId);
            ResultSet resultSet = firstPreparedStatement.executeQuery();

            if (resultSet.next()) {
                String eventName = resultSet.getString("eventName");
                String description = resultSet.getString("description");
                String date = resultSet.getString("date");
                String time = resultSet.getString("time");
                String status = resultSet.getString("status");

                PreparedStatement secondPreparedStatement = connection.prepareStatement(secondQuery);
                secondPreparedStatement.setInt(1, eventId);
                ResultSet secondResultSet = secondPreparedStatement.executeQuery();

                System.out.printf("%-10s %-10s %-10s %-15s %-10s %-20s %-20s %-10s%n", "BOOKINGID", "EVENTID", "USERID", "SEATSBOOKED", "SEATSLEFT", "EVENT NAME", "DESCRIPTION", "ORGANISERID");
                System.out.println("-------------------------------------------------------------------------------------------------------------------------------");

                while (secondResultSet.next()) {
                    int bookingId = secondResultSet.getInt("bookingId");
                    int userId = secondResultSet.getInt("userId");
                    int seatsBooked = secondResultSet.getInt("seatsBooked");
                    int seatsLeft = secondResultSet.getInt("seatsLeft");

                    System.out.printf("%-10d %-10d %-10d %-15d %-10d %-20s %-20s %-10d%n",
                            bookingId,
                            eventId,
                            userId,
                            seatsBooked,
                            seatsLeft,
                            eventName,
                            description,
                            organiserId);
                }
            } else {
                System.out.println("EVENT doesn't exist or you are not the organiser.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
