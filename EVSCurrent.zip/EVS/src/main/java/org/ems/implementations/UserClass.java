package org.ems.implementations;

import org.ems.interfaces.Organiser;
import org.ems.interfaces.User;

import java.sql.*;
import java.util.Scanner;

public class UserClass implements User {
    String query = "";
    Connection connection;
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet resultSet;
    Scanner sc = new Scanner(System.in);
    private String eventName;
    private String description;
    private int organizerId;
    private Date date;
    private Time time;
    private String eventVenue;
    private int capacity;
    private String status, bookingStatus;
    private int eventId, userId, seatsBooked;
    private String firstQuery;
    private String secondQuery;
    private PreparedStatement secondPreparedStatement;

    //Event table = eventId, eventName, description, organizerId, date_time, venue, capacity, status

    @Override
    public boolean userVerifyEventId(Connection connection, int eventId) {
        int count = 0;
        String query = "SELECT COUNT(*) FROM EVENTSI1436 WHERE eventId = ? ";

        try {
            if (connection == null) {
                System.out.println("Connection is null");
                return false;
            }
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, eventId);
            resultSet = preparedStatement.executeQuery();

            if (resultSet == null) {
                System.out.println("ResultSet is null");
                return false;
            }

            while (resultSet.next()) {
                count = resultSet.getInt(1);
                if (count == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: " + e.getMessage());
        }

        return false;
    }

    @Override
    public boolean verifyUserExists(Connection connection, int userId) {
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE userId = ?";
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            if (connection == null) {
                System.out.println("Connection is null");
                return false;
            }

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            resultSet = preparedStatement.executeQuery();

            if (resultSet == null) {
                System.out.println("ResultSet is null");
                return false;
            }

            while (resultSet.next()) {
                int count = resultSet.getInt(1);
                if (count == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }

    @Override
    public int getCapacity(Connection connection, int eventId, int capacity) {
        String query = "SELECT capacity FROM EVENTSI1436 WHERE eventId = ?";
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int result = 0;

        try {
            if (connection == null) {
                System.out.println("Connection is null");
            }

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, eventId);
            resultSet = preparedStatement.executeQuery();

            if (resultSet == null) {
                System.out.println("ResultSet is null");
            }

            while (resultSet.next()) {
                result = resultSet.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return result;
    }

    @Override
    public boolean checkSeatCapacity(Connection connection, int eventId, int capacity) {
        String query = "SELECT capacity FROM EVENTSI1436 WHERE eventId = ?";
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            if (connection == null) {
                System.out.println("Connection is null");
                return false;
            }

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, eventId);
            resultSet = preparedStatement.executeQuery();

            if (resultSet == null) {
                System.out.println("ResultSet is null");
                return false;
            }

            while (resultSet.next()) {
                int result = resultSet.getInt(1);
                if (capacity <= result) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }

    @Override
    public void bookEvent(Connection connection) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++ BOOK EVENT +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        Organiser organizer = new OrganiserClass();
        organizer.viewEventDetails(connection);

        System.out.println();

        String query = "INSERT INTO BOOKINGSI1436(eventId, userId, seatsBooked, bookingStatus, seatsLeft) VALUES (?, ?, ?, ?, ?);";
        PreparedStatement preparedStatement = null;

        try {
            preparedStatement = connection.prepareStatement(query);

            //Validating Event Id
            System.out.print("Enter EVENT ID : \n-->");
            eventId = Integer.parseInt(sc.nextLine().trim());

            while(!String.valueOf(eventId).matches("^[0-9]$")){
                System.out.println("! Invalid Event ID type");
                eventId = Integer.parseInt(sc.nextLine().trim());
                System.out.println();
            }

            while(!userVerifyEventId(connection, eventId)){
                System.out.println("ENTER A VALID EVENT ID : \n-->");
                eventId = sc.nextInt();
                sc.nextLine();
            }
            preparedStatement.setInt(1, eventId);

            //Validating User Id
            System.out.print("Enter YOUR USER ID : \n-->");
            userId = Integer.parseInt(sc.nextLine().trim());
            while(!String.valueOf(userId).matches("^[0-9]$")){
                System.out.println("! Invalid User ID type\n-->");
                userId = Integer.parseInt(sc.nextLine().trim());
                System.out.println();
            }

            while(!verifyUserExists(connection,userId)){
                System.out.println("The USER ID Doesn't Exist \n-->");
                userId = sc.nextInt();
                sc.nextLine();
            }
            preparedStatement.setInt(2, userId);

            //Seats Booked
            System.out.print("Enter SEATS YOU WANT TO BOOK : \n-->");
            seatsBooked = sc.nextInt();
            sc.nextLine();
            while(!String.valueOf(seatsBooked).matches("^[0-9]$")){
                System.out.println("! Invalid Type\n-->");
                seatsBooked = Integer.parseInt(sc.nextLine().trim());
                System.out.println();
            }

            while(!checkSeatCapacity(connection, eventId, seatsBooked)) {
                System.out.println("CAPACITY EXCEEDED : \n-->");
                seatsBooked = Integer.parseInt(sc.nextLine().trim());
                System.out.println();
            }
            preparedStatement.setInt(3, seatsBooked);

            preparedStatement.setString(4, "BOOKED");
            System.out.println();

            preparedStatement.setInt(5, getCapacity(connection,eventId,seatsBooked)-seatsBooked);

            int i = preparedStatement.executeUpdate();

            if (i >= 1) {
                System.out.println("____________________________");
                System.out.println("| Event BOOKED Successfully |");
                System.out.println("|___________________________|");
                System.out.println();

                updateSeatsLeft(connection, eventId, seatsBooked);
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To BOOK Event    |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    @Override
//    public void bookEvent(Connection connection) {
//        System.out.println();
//        System.out.println("++++++++++++++++++++++++++++++++++++++");
//        System.out.println("+++++++++++++ BOOK EVENT +++++++++++++");
//        System.out.println("++++++++++++++++++++++++++++++++++++++");
//        System.out.println();
//
//        Organiser organizer = new OrganiserClass();
//        organizer.listEvents(connection);
//
//        System.out.println();
//
//        query = "INSERT INTO BOOKINGSI1436(eventId, userId, seatsBooked, bookingStatus) VALUES (?, ?, ?, ?);";
//        try {
//            preparedStatement = connection.prepareStatement(query);
//            System.out.print("Enter EVENT ID : \n-->");
//            eventId = sc.nextInt();
//            sc.nextLine();
//
//            if(verifyEventId(connection,eventId)){
//                preparedStatement.setInt(1,eventId);
//                System.out.println();
//            }else{
//                System.out.println("The EVENT ID Doesn't Exist");
//                return;
//            }
//
//            System.out.print("Enter Your USER ID : \n-->");
//            userId = sc.nextInt();
//            sc.nextLine();
//
//            if(verifyUserExists(connection, userId)){
//                preparedStatement.setInt(2,userId);
//                System.out.println();
//            }else{
//                System.out.println("The USER ID Doesn't Exist");
//                return;
//            }
//
//            System.out.print("Enter SEATS YOU WANT TO BOOK : \n-->");
//            seatsBooked = sc.nextInt();
//            sc.nextLine();
//            if(checkSeatCapacity(seatsBooked)){
//                preparedStatement.setInt(3,seatsBooked);
//                sc.nextLine();
//                System.out.println();
//            }else{
//                System.out.println("CAPACITY EXCEEDED");
//            }
//
//            preparedStatement.setString(4,"BOOKED");
//            System.out.println();
//
//            int i = preparedStatement.executeUpdate();
//
//            if(i>=1){
//                System.out.println("____________________________");
//                System.out.println("| Event BOOKED Successfully |");
//                System.out.println("|___________________________|");
//                System.out.println();
//
//                updateSeatsLeft(eventId, seatsBooked);
//            }else{
//                System.out.println("____________________________");
//                System.out.println("| ! Failed To BOOK Event     |");
//                System.out.println("|___________________________|");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }

    @Override
    public void updateSeatsLeft(Connection connection, int eventId, int seatsBooked) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++ UPDATE SEATS LEFT +++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "UPDATE EVENTSI1436 SET capacity = capacity - ? WHERE eventId = ?";
        PreparedStatement preparedStatement = null;

        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, seatsBooked);
            preparedStatement.setInt(2, eventId);
            System.out.println();

            int success = preparedStatement.executeUpdate();

            if (success >= 1) {
                System.out.println("_____________________________");
                System.out.println("| SEATS Updated Successfully |");
                System.out.println("|____________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Update SEATS  |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewEvents(Connection connection) {
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ LIST OF EVENTS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        query = "SELECT eventId, eventName, description, status FROM EVENTSI1436;";

        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);

            // Print the header
            System.out.printf("%-5s %-20s %-40s %-15s%n",
                    "EVENTID",
                    "EVENTNAME",
                    "DESCRIPTION",
                    "STATUS");

            System.out.println("-----------------------------------------------------------------------------------------------");

            // Iterate through the result set and print the data
            while (resultSet.next()) {
                System.out.printf("%-5s %-20s %-40s %-15s",
                        resultSet.getInt(1),//eventId
                        resultSet.getString(2),     // eventName
                        resultSet.getString(3),     // description
                        resultSet.getString(4));    // status
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewBookedEvents(Connection connection) {

        System.out.println();
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ MY BOOKED EVENTS ++++++++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        firstQuery = "SELECT eventName, description, date, time, status FROM EVENTSI1436 WHERE EVENTID = ?;";
        secondQuery = "SELECT EVENTID, SEATSBOOKED, BOOKINGSTATUS, SEATSLEFT, BOOKINGID FROM BOOKINGSI1436 WHERE USERID = ? AND bookingStatus = 'BOOKED'";

        try {
            String eventName, description, date, time, status = "";
            int seatsBooked, seatsLeft,bookingId;
            String bookingStatus;

            secondPreparedStatement = connection.prepareStatement(secondQuery);
            System.out.print("Enter YOUR USER ID : \n-->");
            eventId = sc.nextInt();
            secondPreparedStatement.setInt(1,eventId);
            System.out.println();

            ResultSet second = secondPreparedStatement.executeQuery();
            while(second.next()){

                eventId = second.getInt(1);
                seatsBooked =  second.getInt(2);
                bookingStatus = second.getString(3);
                seatsLeft=  second.getInt(4);
                bookingId = second.getInt(5);

                preparedStatement = connection.prepareStatement(firstQuery);
                preparedStatement.setInt(1,eventId);
                System.out.println();

                resultSet = preparedStatement.executeQuery();
                System.out.printf("%-10s %-7s %-20s %-30s %-12s %-12s %-10s %-6s%n","BOOKINGID","EVENTID", "EVENT NAME","DESCRIPTION", "DATE", "TIME", "SEATS BOOKED", "STATUS");
                System.out.println("--------------------------------------------------------------------------------------------------------------------");
                while(resultSet.next()){
                    System.out.printf("%-10s %-7s %-20s %-30s %-12s %-12s %-10s %-6s",
                            bookingId,
                            eventId,
                            resultSet.getString(1),
                            resultSet.getString(2),
                            String.valueOf(resultSet.getDate(3)),
                            String.valueOf(resultSet.getTime(4)),
                            seatsBooked,
                            status
                    );
                    System.out.println();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void cancelBooking(Connection connection) {

        viewBookedEvents(connection);

        System.out.println();
        System.out.println("+++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++ CANCEL BOOKING +++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++");
        System.out.println();
        query = "UPDATE BOOKINGSI1436 SET bookingStatus = 'CANCELLED'  WHERE bookingId = ?;";
        try {
            preparedStatement = connection.prepareStatement(query);
            System.out.println("Enter your BOOKING ID : ");
            int bookingId = sc.nextInt();
            preparedStatement.setInt(1,bookingId);
            System.out.println();
            int success = preparedStatement.executeUpdate();
            if(success>=1){
                System.out.println("____________________");
                System.out.println("| BOOKING CANCELLED |");
                System.out.println("|___________________|");
            }else{
                System.out.println("______________________");
                System.out.println("| ! Failed To CANCEL  |");
                System.out.println("|_____________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void provideFeedback(Connection connection) {
    }

    @Override
    public void viewNotifications(Connection connection) {
    }

    @Override
    public void viewEventDetails(Connection connection) {
        Organiser organiser = new OrganiserClass();
        organiser.viewEventDetails(connection);
    }

    @Override
    public void checkBookingStatus(Connection connection) {
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++ UPDATE SEATS LEFT +++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        query = "SELECT BOOKINGSTATUS FROM BOOKINGSI1436 WHERE bookingId = ?;";
        try {
            preparedStatement = connection.prepareStatement(query);
            System.out.println("Enter your BOOKING ID : ");
            int bookingId = sc.nextInt();
            preparedStatement.setInt(1,bookingId);
            System.out.println();

            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                System.out.println("BOOKING STATUS IS : " + resultSet.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Event table = eventId, eventName, description, organizerId, date_time, venue, capacity, status
}
