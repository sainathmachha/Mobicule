package org.ems.implementations;

import org.ems.Main;
import org.ems.interfaces.Admin;
import org.ems.interfaces.Organiser;
import org.ems.interfaces.User;

import java.sql.*;
import java.util.Scanner;

import static java.util.Base64.Encoder;
import static java.util.Base64.getEncoder;

public class AdminClass implements Admin {
    String query = "";
    Connection connection;
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet resultSet;
    Scanner sc = new Scanner(System.in);

    //User table = userId, name, email, password, role
    String name, email, password, role;
    int userId;
//Event table = eventId, eventName, description, organizerId, date_time, venue, capacity, status
//Booking table = bookingId, eventId, userId, seatsBooked, bookingStatus

    private String result;
    private String dbUsername;
    private String dbPassword;
    private String dbRole;
    private boolean status = false;
    private String username;

    @Override
    public void addUser(Connection connection) {
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ ADD USER +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        query = "INSERT INTO USERI1436(NAME, EMAIL, PASSWORD, ROLE, PASSWORD_HASH) VALUES (?, ?, ?, ?, ?);";
        try {
            preparedStatement = connection.prepareStatement(query);

            //Validating Username
            while (true) {
                System.out.print("Enter username: ");
                username = sc.nextLine().trim();
                if (username.matches("^[A-Za-z0-9._@#$&-]{8,15}+$")) {
                    break;
                }
                System.out.println("! USERNAME MUST BE BETWEEN 8 - 15 LETTERS");
            }
            preparedStatement.setString(1,username);
            System.out.println();

            //Validating Email
            while (true) {
                System.out.print("Enter Email : \n-->");
                email = sc.nextLine().trim();
                if (email.matches("(?i)^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$")) {
                    break;
                }
                System.out.println("PLEASE ENTER A VALID EMAIL !");
            }
            preparedStatement.setString(2, email);
            System.out.println();


            //Validating Password
            while (true) {
                System.out.print("Enter Password : \n-->");
                password = sc.nextLine().trim();
                if (password.matches("^[A-Za-z0-9.@#$%&]+$")) {
                    break;
                }
                System.out.println("! Password isn't Valid");
            }
            preparedStatement.setString(3,password);
            System.out.println();


            // Validating Role
            System.out.print("Enter Role (USER, ORGANISER, ADMIN): \n-->");
            String role = sc.nextLine().trim().toUpperCase();

            while (!(role.equals("USER") || role.equals("ORGANISER") || role.equals("ADMIN"))) {
                System.out.println("! INVALID ROLE");
                System.out.print("-->");
                role = sc.nextLine().trim().toUpperCase();
            }

            preparedStatement.setString(4, role);


            //ADDING ENCODED PASSWORD INTO THE DATABASE
            Encoder encoder = getEncoder();
            String encoded = encoder.encodeToString(password.getBytes());
            preparedStatement.setString(5,encoded);


            //RESULTSET
            int i = preparedStatement.executeUpdate();
            if(i>=1){
                System.out.println("____________________________");
                System.out.println("| User Added Successfully   |");
                System.out.println("|___________________________|");
                System.out.println();
                System.out.printf(" %-20s %-25s %-30s %-10s ", "USERNAME", "EMAIL","PASSWORD","ROLE");
                System.out.println();

                System.out.printf(" %-20s %-20s %-30s %-10s ",name,email,encoded,role);
                System.out.println();
            }else{
                System.out.println("____________________________");
                System.out.println("| ! Failed To Add User      |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewAllUsers(Connection connection) {
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ USER DETAILS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        query = "SELECT USERID, NAME, EMAIL, PASSWORD_HASH, ROLE FROM USERI1436;";
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);
            System.out.printf("| %-10s | %-20s | %-30s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL","PASSWORD","ROLE");
            System.out.println("--------------------------------------------------------------------------------------------------------------------");
            while(resultSet.next()){
                System.out.printf("  %-10s   %-20s   %-30s   %-30s   %-10s  ",
                        resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getString(4),
                        resultSet.getString(5));
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteUser(Connection connection) {
        int userId;
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        OrganiserClass organiserClass = new OrganiserClass();
        UserClass userClass = new UserClass();
        viewAllUsers(connection);

        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ DELETE USER +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String deleteBookingsQuery = "DELETE FROM BOOKINGSI1436 WHERE userId = ?";
        String deleteUserQuery = "DELETE FROM USERI1436 WHERE userId = ?";
        PreparedStatement preparedStatement = null;

        try {
            preparedStatement = connection.prepareStatement(deleteBookingsQuery);

            while (true) {
                System.out.print("Enter USER ID: \n-->");
                userId = sc.nextInt();
                sc.nextLine();
                if (String.valueOf(userId).matches("^[0-9]+$") && userClass.verifyUserExists(connection, userId)) {
                    break;
                }
                System.out.println("! USERID isn't Valid");
            }
            preparedStatement.setInt(1, userId);

            // Delete related bookings
            int bookingsDeleted = preparedStatement.executeUpdate();
            if (bookingsDeleted >= 1) {
                System.out.println("Related bookings deleted successfully.");
            }

            // Delete user
            preparedStatement = connection.prepareStatement(deleteUserQuery);
            preparedStatement.setInt(1, userId);
            int userDeleted = preparedStatement.executeUpdate();
            if (userDeleted >= 1) {
                System.out.println("____________________________");
                System.out.println("| User Deleted Successfully |");
                System.out.println("|___________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Delete User   |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void manageRoles(Connection connection) {
        OrganiserClass organiserClass = new OrganiserClass();

        viewAllUsers(connection);
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ UPDATE ROLES ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        query = "UPDATE USERI1436 SET ROLE = ? WHERE name = ?;";
        try {
            preparedStatement = connection.prepareStatement(query);

            while (true) {
                System.out.println("Enter ROLE You Want To Assign ( ADMIN, ORGANISER, USER ) : ");
                role = sc.nextLine().trim().toUpperCase();
                if (role.equals("ADMIN") || role.equals("USER") || role.equals("ORGANISER")) {
                    break;
                }
                System.out.println("! INVALID ROLE");
            }
            preparedStatement.setString(1,role);
            System.out.println();

            //Username
            System.out.println("Enter USERNAME : \n-->");
            String username = sc.nextLine().trim();
            preparedStatement.setString(2,username);
            System.out.println();

            int success = preparedStatement.executeUpdate();
            if(success>=1){
                System.out.println("____________________________");
                System.out.println("| Role Updated Successfully |");
                System.out.println("|___________________________|");
            }else{
                System.out.println("____________________________");
                System.out.println("| ! Failed To Update Role   |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewAllEvents(Connection connection, int uid) {
        Organiser organiser = new OrganiserClass();
        organiser.viewEventDetails(connection);
    }
}
