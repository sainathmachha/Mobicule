package org.ems;

public class JavaClass {

    /*
    *
    //Organiser
    addEvent()
        listEvents()
            viewEventDetails()
                updateEvent()
                    deleteEvent()
                        sendNotification()
                            viewBookingsForEvent()
                                viewFeedbackForEvent()
                                    generateEventReport()


    //Attendees
    viewEvents()
        bookEvent()
            viewBookedEvents()
                cancelBooking()
                    provideFeedback()
                        viewNotifications()
                            viewEventDetails()
                                checkBookingStatus()


//User table = userId, name, email, password, role
//Event table = eventId, eventName, description, organizerId, date_time, venue, capacity, status
//Booking table = bookingId, eventId, userId, seatsBooked, bookingStatus

    */
}

/*

//Admin
viewAllUsers()
viewAllEvents()
manageRoles()
deleteUser()
                *
                        *
*/
