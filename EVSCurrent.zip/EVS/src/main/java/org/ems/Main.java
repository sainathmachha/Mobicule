package org.ems;

import org.ems.JDBCConnection.TestConnection;
import org.ems.implementations.AdminClass;
import org.ems.implementations.OrganiserClass;
import org.ems.implementations.UserClass;
import org.ems.interfaces.Admin;
import org.ems.interfaces.Organiser;
import org.ems.interfaces.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

    public class Main {
        private static String loggedInUser = null; // Track logged-in username

        public static void main(String[] args) {
            Connection connection = TestConnection.test();
            Scanner sc = new Scanner(System.in);
            Admin admin = new AdminClass();
            Organiser organiser = new OrganiserClass();
            User user = new UserClass();
            boolean continueProgram;
            String roleSwitch;

            System.out.println();
            System.out.println("******************************");
            System.out.println("* WELCOME TO THE APPLICATION *");
            System.out.println("******************************");
            System.out.println();

            do {
                if (loggedInUser == null) {
                    String retry;
                    int retryCount = 1;
                    do {
                        System.out.println();
                        // Prompt for login only if no user is logged in
                        System.out.print(" Enter your username: ");
                        String username = sc.nextLine();
                        System.out.println("________________________________________");
                        System.out.print(" Enter your password: ");
                        String password = sc.nextLine();
                        System.out.println("________________________________________");

                        if (!validateUser(connection, username, password)) {
                            System.out.println("_______________________________________");
                            System.out.println("| Invalid credentials. Access denied.  |");
                            System.out.println("|______________________________________|");
                            System.out.println();
                            System.out.println("____________________________________________");
                            System.out.println("| Do you want to try again? (yes or y/no):  |");
                            System.out.println("|___________________________________________|");
                            System.out.println();
                            retry = sc.nextLine().trim().toLowerCase();
                            System.out.println();
                            if(retryCount<3){
                                if(retry.equals("yes") || retry.equals("y")) {
                                    System.out.println("____________________");
                                    System.out.println("| Chances Left : "+(3-retryCount)+"|");
                                    System.out.println("|___________________|");
                                    System.out.println();
                                    retryCount++;
                                }
                            }else{
                                System.out.println("________________________");
                                System.out.println("| ! Retry Limit Reached |");
                                System.out.println("|_______________________|");
                                System.out.println();
                                return;
                            }
                        }else{
                            loggedInUser = username;
                        }
                    }while(loggedInUser==null);

                    //loggedInUser = username; // Set logged-in user
                    System.out.println("\nLogin successful!");
                    System.out.println();
                    System.out.println("________________________________");
                    System.out.printf("| %-10s %-18s |","WELCOME ",loggedInUser);
                    System.out.println();
                    System.out.println("|_______________________________|");
                    System.out.println();
                } else {
                    System.out.println("_____________________________________");
                    System.out.printf("| %-15s %-18s |","WELCOME BACK ",loggedInUser);
                    System.out.println();
                    System.out.println("|____________________________________|");
                    System.out.println();
                    System.out.println("\nWelcome back, " + loggedInUser);
                }
//
//                // Role selection
//                System.out.println("------------------");
//                System.out.println("     1. USER    ");
//                System.out.println("    2. ADMIN    ");
//                System.out.println("   3. ORGANISER ");
//                System.out.println("------------------");
//
//                System.out.print("SELECT A ROLE : \n-->");

                int id = getUserId(connection, loggedInUser);
                String role = getRole(connection,loggedInUser);
                switch (role) {
                    case "USER":
                        do {
                            handleUserRole(user, connection, sc,id);
                            System.out.println();
                            System.out.println("____________________________________________");
                            System.out.println("| Do you want to continue? (yes or y/no):   |");
                            System.out.println("|___________________________________________|");
                            System.out.println();
                            String response = sc.nextLine().trim().toLowerCase();
                            continueProgram = response.equals("yes") || response.equals("y");
                        } while (continueProgram);
                        break;
                    case "ADMIN":
                        do {
                            handleAdminRole(admin, connection, sc,id);
                            System.out.println();
                            System.out.println("____________________________________________");
                            System.out.println("| Do you want to continue? (yes or y/no):   |");
                            System.out.println("|___________________________________________|");
                            System.out.println();
                            String response = sc.nextLine().trim().toLowerCase();
                            continueProgram = response.equals("yes") || response.equals("y");
                        }while(continueProgram);
                        break;
                    case "ORGANISER":
                        do {
                            handleOrganiserRole(organiser, connection, sc,id);
                            System.out.println();
                            System.out.println("____________________________________________");
                            System.out.println("| Do you want to continue? (yes or y/no):   |");
                            System.out.println("|___________________________________________|");
                            System.out.println();
                            String response = sc.nextLine().trim().toLowerCase();
                            continueProgram = response.equals("yes") || response.equals("y");
                        }while(continueProgram);
                        break;
                    default:
                        System.out.println();
                        System.out.println("______________________________________________");
                        System.out.println("| Invalid Role Selection. Please try again.   |");
                        System.out.println("|_____________________________________________|");
                        System.out.println();
                        break;
                }

                System.out.println();
                System.out.println("_________________________________________");
                System.out.println("| WANT TO STAY OR EXIT ? (yes or y/no):  |");
                System.out.println("|________________________________________|");
                roleSwitch = sc.nextLine().trim().toLowerCase();
                System.out.println();

                if (roleSwitch.equals("no")) {
                    // Reset login state if exiting
                    return;
                }else{
                    System.out.println("_________________");
                    System.out.println("| Login Again... |");
                    System.out.println("|________________|");
                    loggedInUser = null;
                }
            } while(roleSwitch.equals("yes") || roleSwitch.equals("y"));
            System.out.println();
            System.out.println("________________________________________________");
            System.out.println("| Thank you for using the application. Goodbye! |");
            System.out.println("|_______________________________________________|");
            System.out.println();
        }

        // Validate user credentials
        public static boolean validateUser(Connection connection, String username, String password) {
            String query = "SELECT name, password FROM USERI1436 WHERE name = ? AND password = ?";
            try{
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, password);
                ResultSet resultSet = preparedStatement.executeQuery();
                while(resultSet.next()) {
                    if(username.equals(resultSet.getString(1)) && password.equals(resultSet.getString(2))){
                        return true; //valid user
                    }
                }
            } catch (Exception e) {
                System.out.println("Error during user validation: " + e.getMessage());
            }
            return false;
        }

        //Get user role
        public static String getRole(Connection connection, String username){
            String role = "";
            String query = "SELECT role FROM USERI1436 WHERE name = ?";
            try {
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, username);
                ResultSet resultSet = statement.executeQuery();
                while(resultSet.next()){
                    role = resultSet.getString(1);
                }
            } catch (SQLException e) {
                e.getMessage();
            }
            return role;
        }

        // Handle user-specific actions
        public static void handleUserRole(User user, Connection connection, Scanner sc, int uid) {
            System.out.println();
            System.out.println("1. BOOK EVENT ");
            System.out.println("2. VIEW EVENTS ");
            System.out.println("3. CANCEL BOOKING ");
            System.out.println("4. VIEW BOOKED EVENTS ");
            System.out.println("5. CHECK STATUS OF BOOKING ");
            System.out.println();
            System.out.print("SELECT AN OPTION : \n-->");
            int userChoice = sc.nextInt();
            sc.nextLine(); // Consume newline
            System.out.println();

            switch (userChoice) {
                case 1:
                    System.out.println();
                    user.bookEvent(connection);
                    break;
                case 2:
                    System.out.println();
                    user.viewEvents(connection);
                    break;
                case 3:
                    System.out.println();
                    user.cancelBooking(connection);
                    break;
                case 4:
                    System.out.println();
                    user.viewBookedEvents(connection);
                    break;
                case 5:
                    System.out.println();
                    user.checkBookingStatus(connection);
                    break;
                default:
                    System.out.println();
                    System.out.println("Invalid Choice");
                    break;
            }
        }

        // Handle admin-specific actions
        public static void handleAdminRole(Admin admin, Connection connection, Scanner sc, int uid) {
            System.out.println();
            System.out.println("1. ADD USER ");
            System.out.println("2. DELETE USER ");
            System.out.println("3. VIEW EVENTS ");
            System.out.println("4. MANAGE ROLES ");
            System.out.println("5. VIEW ALL USERS ");
            System.out.println();
            System.out.print("SELECT AN OPTION : \n-->");
            int adminChoice = sc.nextInt();
            sc.nextLine(); // Consume newline
            System.out.println();

            switch (adminChoice) {
                case 1:
                    System.out.println();
                    admin.addUser(connection);
                    break;
                case 2:
                    System.out.println();
                    admin.deleteUser(connection);
                    break;
                case 3:
                    System.out.println();
                    admin.viewAllEvents(connection, uid);
                    break;
                case 4:
                    System.out.println();
                    admin.manageRoles(connection);
                    break;
                case 5:
                    System.out.println();
                    admin.viewAllUsers(connection);
                    break;
                default:
                    System.out.println();
                    System.out.println("Invalid Choice");
                    break;
            }
        }

        // Handle organiser-specific actions
        public static void handleOrganiserRole(Organiser organiser, Connection connection, Scanner sc, int uid) {
            System.out.println();
            System.out.println("1. ADD EVENT ");
            System.out.println("2. DELETE EVENT ");
            System.out.println("3. VIEW EVENTS DETAILS ");
            System.out.println("4. UPDATE EVENT ");
            System.out.println("5. LIST OF MY EVENTS ");
            System.out.println("6. VIEW BOOKINGS FOR EVENT");
            System.out.println();
            System.out.print("SELECT AN OPTION : \n-->");
            int organiserChoice = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (organiserChoice) {
                case 1:
                    System.out.println();
                    organiser.addEvent(connection, uid);
                    break;
                case 2:
                    System.out.println();
                    organiser.deleteEvent(connection, uid);
                    break;
                case 3:
                    System.out.println();
                    organiser.viewEventDetails(connection);
                    break;
                case 4:
                    System.out.println();
                    organiser.updateEvent(connection, uid);
                    break;
                case 5:
                    System.out.println();
                    organiser.listMyEvents(connection, uid);
                    break;
                case 6:
                    System.out.println();
                    organiser.viewBookingsForEvent(connection, uid);
                    break;
                default:
                    System.out.println();
                    System.out.println("Invalid Choice");
                    break;
            }
        }

        public static int getUserId(Connection connection, String username){
            int id = 0;
            try {
                String query = "SELECT userId FROM USERI1436 WHERE name = ?";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, username);
                ResultSet resultSet = statement.executeQuery();
                while(resultSet.next()){
                    id =  resultSet.getInt(1);
                }
            } catch (SQLException e) {
                e.getMessage();
            }
            return id;
        }
    }


