package org.ems.interfaces;

import java.sql.Connection;

public interface Admin {

    //User table
    void addUser(Connection connection);
    void viewAllUsers(Connection connection);
    void deleteUser(Connection connection);
    void manageRoles(Connection connection);

    //Events
    void viewAllEvents(Connection connection, int uid);

}
