package org.ems.interfaces;

import java.sql.Connection;

public interface User {

    void updateSeatsLeft(Connection connection, int eventId, int seatsBooked);

    void viewEvents(Connection connection);

    boolean userVerifyEventId(Connection connection, int eventId);

    boolean verifyUserExists(Connection connection, int userId);

    int getCapacity(Connection connection, int eventId, int capacity);

    boolean checkSeatCapacity(Connection connection, int eventId, int capacity);

    void bookEvent(Connection connection);
    void viewBookedEvents(Connection connection);
    void cancelBooking(Connection connection);
    void provideFeedback(Connection connection);
    void viewNotifications(Connection connection);

    void viewEventDetails(Connection connection);

    void checkBookingStatus(Connection connection);
}
