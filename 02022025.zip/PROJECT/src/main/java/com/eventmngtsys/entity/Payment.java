package com.eventmngtsys.entity;

import java.sql.Date;
import java.time.format.DateTimeFormatter;

public class Payment {

    int paymentId,bookingId,eventId;
    String username,paymentMethod;
    long amountPaid;
    Date datetime;

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public long getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(long amountPaid) {
        this.amountPaid = amountPaid;
    }

    public Date getDatetime() {
        return datetime;
    }

    public void setDatetime(Date datetime) {
        this.datetime = datetime;
    }

    public Payment(int bookingId, int eventId, String username, String paymentMethod, long amountPaid) {
        this.bookingId = bookingId;
        this.eventId = eventId;
        this.username = username;
        this.paymentMethod = paymentMethod;
        this.amountPaid = amountPaid;
    }
}
