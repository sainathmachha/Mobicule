package com.eventmngtsys.JDBCConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnection {
    //private static String url ="jdbc:sqlserver://10.1.1.196;databaseName=TRAINING_DB";
    //private static String username = "sa";
    //private static String password = "M0b1cule!";

    private static String url ="jdbc:mysql://localhost:3306/saidb";
    private static String username = "root";
    private static String password = "Sainath1811@mysqL";

    public static Connection test() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            connection = DriverManager.getConnection(url, username, password);
            if (!connection.isValid(10)) {
                System.out.println("Failed to connect to the database.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }
}
