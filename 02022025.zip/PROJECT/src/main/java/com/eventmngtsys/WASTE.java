package com.eventmngtsys;

public class WASTE {

    public static void main(String[] args) {

        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ USER DETAILS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ DELETE USER +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();


        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ UPDATE ROLES ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();



        System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ VIEW EVENT DETAILS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();


    }

}

