package com.eventmngtsys.service.impl;

import com.eventmngtsys.JDBCConnection.TestConnection;
import com.eventmngtsys.dao.OrganiserDAO;
import com.eventmngtsys.dao.impl.OrganiserDAOImpl;
import com.eventmngtsys.entity.Event;
import com.eventmngtsys.service.OrganiserService;

import java.sql.Connection;

import static com.eventmngtsys.JDBCConnection.TestConnection.*;

public class OrganiserServiceImpl implements OrganiserService {
    Connection connection = TestConnection.test();

    OrganiserDAO orgDAO = new OrganiserDAOImpl(connection);

    @Override
    public boolean addEvent(Event event) {
        return orgDAO.createEventInDB(event);
    }

    @Override
    public void listMyEvents(int orgId) {
        for(Event event : orgDAO.listAllMyEvents(orgId)){
            System.out.print(event);
        }
    }

    @Override
    public void viewEventDetails() {
        for(Event event : orgDAO.viewAllEvents()){
            System.out.print(event);
        }
    }

    @Override
    public boolean updateEvent(Event event) {
        return orgDAO.updateEvent(event);
    }

    @Override
    public boolean deleteEvent(int eventId) {
        return orgDAO.deleteEventFromDB(eventId);
    }

    @Override
    public void viewBookingsForEvent(int orgId) {
        orgDAO.viewBookedEvents(orgId);
    }

    @Override
    public void viewFeedBackForEvents(int orgId) {
        orgDAO.viewFeedBackForEvents(orgId);
    }

    @Override
    public boolean checkSeatCapacity(int eventId, int seatsBooked) {
        return orgDAO.checkSeatCapacity(eventId,seatsBooked);
    }

    @Override
    public boolean userVerifyEventId(int eventId){
        return orgDAO.userVerifyEventId(eventId);
    }

    @Override
    public boolean isOrganisersEvent(int orgId, int eventId) {
        return orgDAO.isOrganisersEventDB(eventId,orgId);
    }

}
