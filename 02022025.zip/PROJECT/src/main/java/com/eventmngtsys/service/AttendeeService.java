package com.eventmngtsys.service;

import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Feedback;

public interface AttendeeService {

    boolean bookEvent(Booking booking);
    void viewBookedEvents(int userId);
    boolean cancelBooking(int bookingId, int userId);
    boolean provideFeedback(Feedback feedback, String username);
    void viewEventDetails();
    boolean userVerifyEventId(int eventId);
    boolean isUsersBookedEvent(int eventId, int userId);
    boolean payForBookings(int bookingId, int eventId, String username, String paymentMethod, long amountPaid);
    void listPaymentsPending(int userId);
    long getPaymentAmount(int eventId, int seatsBooked);
    boolean canSubmitFeedback(int bookingId, int eventId, int userId);
    boolean isAttended(int bookingId, int userId);
}
