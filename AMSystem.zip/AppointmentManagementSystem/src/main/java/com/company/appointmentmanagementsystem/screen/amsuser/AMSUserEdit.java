package com.company.appointmentmanagementsystem.screen.amsuser;

import com.company.appointmentmanagementsystem.entity.AMSUser;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.TextField;
import io.jmix.ui.model.InstanceLoader;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Text;

@UiController("AMSUser.edit")
@UiDescriptor("ams-user-edit.xml")
@EditedEntityContainer("aMSUserDc")
public class AMSUserEdit extends StandardEditor<AMSUser> {

    @Autowired
    private TextField<String> emailField;
    @Autowired
    private TextField<String> passwordField;
    @Autowired
    private TextField<String> roleField;
    @Autowired
    private Notifications notifications;

    @Subscribe("loginBtn")
    public void onLogin(Button.ClickEvent event){
        if(emailField.getValue().equals("sainath1811@gmail.com")&&passwordField.getValue().equals("sainath") &&roleField.getValue().equals("USER")){
            notifications.create()
                    .withCaption("Login Successful")
                    .withType(Notifications.NotificationType.TRAY)
                    .withPosition(Notifications.Position.MIDDLE_CENTER)
                    .show();
        }else{
            notifications.create()
                    .withCaption("Invalid user credentials")
                    .withType(Notifications.NotificationType.WARNING)
                    .withPosition(Notifications.Position.MIDDLE_CENTER)
                    .show();
        }
    }

}