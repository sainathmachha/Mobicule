package com.company.appointmentmanagementsystem.screen.appointments;

import com.company.appointmentmanagementsystem.entity.Appointments;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("Appointments.browse")
@UiDescriptor("appointments-browse.xml")
@LookupComponent("appointmentsTable")
public class AppointmentsBrowse extends StandardLookup<Appointments> {
}