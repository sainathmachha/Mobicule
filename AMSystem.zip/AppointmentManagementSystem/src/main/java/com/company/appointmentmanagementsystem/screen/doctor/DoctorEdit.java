package com.company.appointmentmanagementsystem.screen.doctor;

import com.company.appointmentmanagementsystem.entity.Doctor;
import com.company.appointmentmanagementsystem.entity.Patients;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.Component;
import io.jmix.ui.component.Table;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("Doctor.edit")
@UiDescriptor("doctor-edit.xml")
@EditedEntityContainer("doctorDc")
public class DoctorEdit extends StandardEditor<Doctor> {

    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private Table<Patients> patientsTable;
    @Autowired
    private InstanceContainer<Doctor> doctorDc;

    @Install(to = "patientsTable.status", subject = "columnGenerator")
    private Component stepsTableCompletedColumnGenerator(Patients patients) {
        CheckBox checkBox = uiComponents.create(CheckBox.class);
        checkBox.setValue(patients.getStatus() != null);
        checkBox.addValueChangeListener(e -> {
            if (patients.getStatus() == null) {
                patients.setStatus(checkBox.isChecked());

            } else {
                patients.setStatus(checkBox.isChecked());
            }
        });
        return checkBox;
    }

}