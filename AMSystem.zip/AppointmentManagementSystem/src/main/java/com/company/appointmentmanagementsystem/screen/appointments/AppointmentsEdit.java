package com.company.appointmentmanagementsystem.screen.appointments;

import com.company.appointmentmanagementsystem.entity.Appointments;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("Appointments.edit")
@UiDescriptor("appointments-edit.xml")
@EditedEntityContainer("appointmentsDc")
public class AppointmentsEdit extends StandardEditor<Appointments> {
}