package org.example.entity;

public class User{

    private int id;
    private String username;
    private String password;
    private String mobileNumber;
    private String address;
    private String dateCreated;

    public User(int id, String username, String password, String mobileNumber, String address, String dateCreated) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.mobileNumber = mobileNumber;
        this.address = address;
        this.dateCreated = dateCreated;
    }

    public User(int id, String username, String mobileNumber, String address, String dateCreated) {
        this.id = id;
        this.username = username;
        this.mobileNumber = mobileNumber;
        this.address = address;
        this.dateCreated = dateCreated;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getAddress() {
        return address;
    }

    @Override
    public String toString() {
        String s ="\n{\nUser"+
                "\nId : " + id +",\n"+
                "Email : '" + username + '\'' +",\n"+
                "MobileNumber : '" + mobileNumber + '\'' +",\n"+
                "Address : '" + address + '\'' +",\n"+
                "DateCreated : '" + dateCreated + '\''+"\n"+
                '}'+"\n";
        return s;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }
}
