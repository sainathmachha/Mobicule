package org.example.JDBCConnection;

import java.sql.*;

public class TestConnection {
    private static String url = "jdbc:sqlserver://10.1.1.196;databaseName=TRAINING_DB";
    private static String username = "sa";
    private static String password = "M0b1cule!";

    public static Connection test() {
        Connection connection = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(url, username, password);
            if (connection.isValid(10)) {
                System.out.println("Connection established successfully.");
            } else {
                System.out.println("Failed to connect to the database.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }
}
