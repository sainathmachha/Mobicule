package org.example.comparator;

import org.example.entity.User;

import java.util.Comparator;

public class NameComparator implements Comparator<User> {
    @Override
    public int compare(User o1, User o2) {
        return o1.getId()-o2.getId();
    }

    @Override
    public Comparator<User> reversed() {
        return Comparator.super.reversed();
    }
}
