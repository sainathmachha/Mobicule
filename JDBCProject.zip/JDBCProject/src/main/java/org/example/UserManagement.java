package org.example;

import org.example.entity.User;

import java.sql.Connection;
import java.util.List;

public interface UserManagement {

    boolean createUser(Connection connection);

    boolean checkIfUserExists(Connection connection, String username);

    boolean verifyUser(Connection connection);

    User listUser(Connection connection, String username);

    void updateUser(Connection connection);

    void deleteUser(Connection connection);

    void forgotPassword(Connection connection);

    String generateOTP();

    void listAllUsers(Connection connection);
//    String listAllUsers(Connection connection);
}
