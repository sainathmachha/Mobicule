package org.example;

import org.example.JDBCConnection.TestConnection;

import java.sql.*;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);
    public static String choice;
    public static boolean result;
    public static Connection connection = TestConnection.test();
    public static UserManagement userManagement = new UserManagementImpl();

    public static String authenticate(){
        System.out.println("1. Create a user OR ");
        System.out.println("2. Verify user.");
        System.out.println("\nEnter your choice : ");
        choice = sc.next();
        switch (Integer.parseInt(choice)) {
            case 1:
                result = userManagement.createUser(connection);
                if (result) {
                    repeat();
                    break;
                }
                break;
            case 2:
                result = userManagement.verifyUser(connection);
                if (result) {
                    repeat();
                    break;
                }
                break;
            default:
                System.err.println("\nInvalid Option\n");
                break;
        }
        return choice;
    }

    public static void main(String[] args) throws Exception{
        System.out.println("\n++++++++++++++++++++++++++++++++++++++++++\n");
        System.out.println("Welcome to the application.\n");
        System.out.println("Authenticate Yourself : ");
        if(!(authenticate().contains("1") || authenticate().contains("2"))){
            System.out.println("Exiting the application.....");
            System.exit(0);
        }else {
            do {
                authenticate();
            } while (authenticate().equals("1") || authenticate().equals("2"));
        }
    }

    public static void repeat()
    {
    do
    {
        System.out.println("1. Edit user details.");
        System.out.println("2. Delete user from database.");
        System.out.println("3. List all users.");
        System.out.println("4. Forgot password ?");
        System.out.println("5. Exit.");
        System.out.println();
        System.out.print("Select an option to begin : ");
        String x = sc.next();
        System.out.println();
        switch (Integer.parseInt(x)) {
            case 1:
                userManagement.updateUser(connection);
                break;
            case 2:
                userManagement.deleteUser(connection);
                break;
            case 3:
                userManagement.listAllUsers(connection);
                break;
            case 4:
                userManagement.forgotPassword(connection);
                break;
            case 5:
                System.err.println("Exiting the application.....");
                System.exit(0);
        }
        System.out.print("\nDo you want to continue (yes or no) : ");
        choice = sc.next();
        if(choice.equalsIgnoreCase("no")){
            System.out.println("Thanks for using the application, have a good day.");
            System.exit(0);
        }
    } while(choice.equalsIgnoreCase("yes"));
}
}