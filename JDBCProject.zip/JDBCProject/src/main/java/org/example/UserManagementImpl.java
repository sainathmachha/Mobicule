package org.example;

import org.example.entity.User;

import java.sql.*;
import java.util.*;

public class UserManagementImpl implements UserManagement {
    Scanner sc = new Scanner(System.in);
    HashMap<Integer, User> verifiedUsers = new HashMap<>();
    public static String verifiedUsername;
    public static User user = null;
    public static boolean verified = false;

    @Override
    public boolean createUser(Connection connection) {
        String username;
        String password;
        String mobileNumber;
        String address;
        do{
            System.out.println("Enter your email : ");
            username = sc.next();
        }while(!username.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"+"[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"));
        if(checkIfUserExists(connection, username)){
            System.out.println("\nUser already exist.");
            return false;
        }
        System.out.println("Create your password : ");
        password = sc.next();
        System.out.println("Enter your mobile number : ");
        mobileNumber = sc.next();
        System.out.println("Enter your address : ");
        address = sc.next();
        System.out.println("User created successfully.");
        verified = true;
        String query = "INSERT INTO SAINATH_I1436(username, password, mobileNumber, address, dateCreated) VALUES (?,?,?,?,CURRENT_TIMESTAMP);";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1,username);
            statement.setString(2, password);
            statement.setString(3, mobileNumber.substring(0,10));
            statement.setString(4, address);
            int i = statement.executeUpdate();
            System.out.println(i);
            if(i>=1){
                System.out.println("Inserted successful.");
                return true;
            }else{
                System.out.println("Failed to insert.");
                return false;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean checkIfUserExists(Connection connection, String username) {
        String query = "SELECT * FROM SAINATH_I1436;";
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                if(resultSet.getString(2).equals(username)){
                    return true;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    @Override
    public boolean verifyUser(Connection connection) {
        String query = "SELECT ID, USERNAME, PASSWORD FROM SAINATH_I1436 WHERE USERNAME=?";
        System.out.println("* Verify Your Credentials. *\n");
        System.out.println("Enter your email : ");
        verifiedUsername = sc.next();
        System.out.println();
        System.out.println("Enter your password : ");
        String password = sc.next();
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, verifiedUsername);
            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()){
                String name = resultSet.getString(2);
                String pass = resultSet.getString(3);
                if(verifiedUsername.equals(name) && password.equals(pass)) {
                    System.out.println("\nUser verified successful.\n");
                    verified = true;
                    user = listUser(connection, name);
                    verifiedUsers.put(user.getId(), user);
                    return true;
                }else{
                    System.out.println("\nEmail or password doesn't match.\n");
                    return false;
                }
            }else {
                System.out.println("\nUser doesn't exist.\n");
                return false;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public User listUser(Connection connection, String username) {

        String query = "SELECT ID, USERNAME, PASSWORD, mobileNumber,ADDRESS, dateCreated FROM SAINATH_I1436 WHERE USERNAME=?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                user = new User(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }


//    @Override
//    public void updateUserDetails(Connection connection) {
//        HashMap<Integer, User> changedPassword = new HashMap<>(verifiedUsers);
//        String username="";
//        String password="";
//        String mobileNumber="";
//        String address="";
//        System.out.println("* Update Your Details *");
//        String query = "UPDATE SAINATH_I1436 SET USERNAME = ?, PASSWORD = ?, mobileNumber = ?, ADDRESS = ?, lastUpdated = CURRENT_TIMESTAMP WHERE USERNAME = ?;";
//        try {
//            PreparedStatement statement = connection.prepareStatement(query);
//            sc.nextLine();
//            System.out.println("Enter new email : ");
//            username = sc.nextLine();
//            if(username.isEmpty()) {
//                statement.setString(1,user.getUsername());
//            }
//            else{
//                statement.setString(1, username);
//            }
//
//            System.out.println("Enter new password : ");
//            password = sc.nextLine();
//            if(password.isEmpty()) {
//                statement.setString(2,user.getPassword());
//            }
//            else{
//                statement.setString(2,password);
//            }
//
//            System.out.println("Enter new contact : ");
//            mobileNumber = sc.nextLine();
//            if(username.isEmpty()) {
//                statement.setString(1,user.getMobileNumber());
//            }
//            else{
//                statement.setString(3, mobileNumber);
//            }
//
//            System.out.println("Enter new address : ");
//            address = sc.nextLine();
//            if(username.isEmpty()) {
//                statement.setString(4,user.getAddress());
//            }
//            else{
//                statement.setString(4, address);
//            }
//
//            statement.setString(5, verifiedUsername);
//            int i = statement.executeUpdate();
//                if(i>=1){
//                    System.out.println("Updated successfully.");
//                }else{
//                    System.out.println("Failed to update.");
//                }
//            } catch (SQLException e) {
//                throw new RuntimeException(e);
//            }
//    }

    @Override
    public void updateUser(Connection connection) {
        if(verified) {
            String username = "";
            String password = "";
            String mobileNumber = "";
            String address = "";

            System.out.println("* Update Your Details *");
            String query = "UPDATE SAINATH_I1436 SET USERNAME = ?, PASSWORD = ?, mobileNumber = ?, ADDRESS = ?, lastUpdated = CURRENT_TIMESTAMP WHERE USERNAME = ?;";

            try {
                PreparedStatement statement = connection.prepareStatement(query);
                sc.nextLine(); // Clear scanner buffer

                // Prompt for username and set value
                do {
                    System.out.println("Enter new email : ");
                    username = sc.nextLine();
                }while(!(username.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"+"[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")));
                statement.setString(1, username.isEmpty() ? user.getUsername() : username);

                // Prompt for password and set value
                System.out.println("Enter new password : ");
                password = sc.nextLine();
                statement.setString(2, password.isEmpty() ? user.getPassword() : password);

                // Prompt for mobile number and set value
                System.out.println("Enter new 10-digit contact no : ");
                mobileNumber = sc.nextLine();
                statement.setString(3, mobileNumber.isEmpty() ? user.getMobileNumber() : mobileNumber.substring(0,10));

                // Prompt for address and set value
                System.out.println("Enter new address : ");
                address = sc.nextLine();
                statement.setString(4, address.isEmpty() ? user.getAddress() : address);

                // Set the condition for the WHERE clause
                statement.setString(5, verifiedUsername);
                // Execute the update
                int i = statement.executeUpdate();
                if (i >= 1) {
                    System.out.println("Updated successfully.");
                } else {
                    System.out.println("Failed to update.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else{
            verifyUser(connection);
        }
    }


    @Override
    public void deleteUser(Connection connection) {
        System.out.println("Verify administrator credentials....\n");
        System.out.println("Enter admin username : ");
        String adminUsername = sc.next();
        System.out.println();
        System.out.println("Enter admin password : ");
        String adminPassword = sc.next();
        try {
            String query = "SELECT USERNAME, PASSWORD FROM SAINATH_I1436_ADMIN WHERE USERNAME=? AND PASSWORD=?;";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, adminUsername);
            statement.setString(2, adminPassword);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String username = resultSet.getString(1);
                String password = resultSet.getString(2);

                if (username.equals(adminUsername) && password.equals(adminPassword)) {
                    System.out.println("\nYou are verified now..\n");
                    System.out.println("Enter the user you want to delete : ");
                    String delete = sc.next();
                    String deleteQuery = "DELETE FROM SAINATH_I1436 WHERE USERNAME = ?";
                    statement = connection.prepareStatement(deleteQuery);
                    statement.setString(1, delete);
                    int i = statement.executeUpdate();
                    if (i >= 1) {
                        System.out.println("User deleted successfully.");
                    } else {
                        System.out.println("Failed to delete.");
                    }
                }else{
                    System.out.println("User is not in the administrator list.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void forgotPassword(Connection connection) {
        PreparedStatement statement;
        ResultSet resultSet;
        System.out.println("Enter your email : ");
        String username = sc.next();
        String password="";
        String resulsetUsername = "";
        String usernameQuery = "SELECT USERNAME FROM SAINATH_I1436 WHERE USERNAME = ?";
        try {
            statement = connection.prepareStatement(usernameQuery);
            statement.setString(1,username);
            resultSet = statement.executeQuery();
            while(resultSet.next()){
                resulsetUsername = resultSet.getString(1);
            }
            if(username.equals(resulsetUsername)){
                String otpReceived = String.valueOf(generateOTP());
                System.out.println("YOUR OTP IS : "+otpReceived);
                System.out.println("Enter the otp received : ");
                String otpEntered = sc.next();
                if(otpReceived.equals(otpEntered)){
                    System.out.println("OTP Confirmed");
                    String forgotQuery = "SELECT PASSWORD FROM SAINATH_I1436 WHERE USERNAME = ?";
                    try {
                        statement = connection.prepareStatement(forgotQuery);
                        statement.setString(1, username);
                        resultSet = statement.executeQuery();
                        while(resultSet.next()) {
                            password = resultSet.getString(1);
                        }
                        System.out.println("Your password is : "+password);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }else{
                    System.out.println("Invalid OTP.");
                }
            }else{
                System.out.println("User doesn't exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String generateOTP() {
        StringBuilder otp= new StringBuilder();
        for(int i = 0; i<6; i++){
            otp.append((int)(Math.random()*10));
        }
        return String.valueOf(otp);
    }

    @Override
    public void listAllUsers(Connection connection) {
        List<User> listOfUsers = new ArrayList<>();
        String result="";
        String query = "SELECT * FROM SAINATH_I1436;";
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                result = "ID : "+resultSet.getInt(1)+"\n"+
                        "Email : "+resultSet.getString(2)+"\n"+
                        "Contact : "+resultSet.getString(4)+"\n"+
                        "Address : "+resultSet.getString(5)+"\n"+
                        "Date Created : "+resultSet.getString(6)+"\n";
                System.out.println(result);
                listOfUsers.add(new User(resultSet.getInt(1),resultSet.getString(2),resultSet.getString(4),resultSet.getString(5),resultSet.getString(6)));
            }
        } catch (SQLException e) {
            e.getMessage();
        }
    }

//    @Override
//    public List<User> listAllUsers(Connection connection) {
//        List<User> listOfUsers = new ArrayList<>();
//        String query = "SELECT * FROM SAINATH_I1436;";
//        try {
//            Statement statement = connection.createStatement();
//            ResultSet resultSet = statement.executeQuery(query);
//            while(resultSet.next()){
//                listOfUsers.add(new User(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4),resultSet.getString(5), resultSet.getString(6)));
//            }
//        } catch (SQLException e) {
//            e.getMessage();
//        }
//        return listOfUsers;
//    }
}
