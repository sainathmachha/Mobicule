package rules;

import rules.Keywords.SuperKeyword;

public class SubClass extends SuperKeyword {

    String name;

    public SubClass(){
        super.display();
        System.out.println(super.roll);
        System.out.println(this.name = super.name);
        System.out.println("Inside Subclass constructor");
    }

    public static void main(String[] args) {
        SubClass subClass = new SubClass(); //it will call the constructors of both the classes by default.
    }
}
