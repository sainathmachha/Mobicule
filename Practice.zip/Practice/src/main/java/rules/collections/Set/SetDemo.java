package rules.collections.Set;

import rules.collections.Iterators.Iterators;
import rules.collections.Iterators.IteratorsImpl;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Spliterator;

public class SetDemo extends IteratorsImpl implements Iterators {

    static Set<Integer> set = new HashSet<>();

    public static void main(String[] args) {
        Iterators.SetInterface iterate = new SetDemo();
        set.add(12);
        set.add(49);
        set.add(56);
        set.add(12);
        System.out.println(set);

        System.out.println(set.contains(12));

        iterate.iteratorSet(set);
    }
}
