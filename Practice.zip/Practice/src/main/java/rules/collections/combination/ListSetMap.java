package rules.collections.combination;

import java.util.*;

public class ListSetMap {

    Set<Integer> integerSet = new HashSet<>();
    List<Integer> li;
    Set<Integer> integers = new HashSet<>();
    Map<Integer, Integer> integerMap = new HashMap<>(); //You can't add this to list directly because List takes only Integers, but map is of type (Integer, Integer).

    ListSetMap(){
        integerSet.add(10);
        integerSet.add(20);
        integerSet.add(30);
        li = new ArrayList<>(integerSet);

        integers.add(23);
        integers.add(32);
        integers.add(35);
        integers.add(40);

        integerMap.put(1,2);
        integerMap.put(3,5);
        integerMap.put(8,7);
    }

    public static void main(String[] args) {
        ListSetMap listSetMap = new ListSetMap();
        System.out.println(listSetMap.li);

        System.out.println("--------------------");

        for (Integer i : listSetMap.integers){
            listSetMap.li.add(i);
        }
        System.out.println(listSetMap.li);

        System.out.println("=====================");

        //System.out.println(listSetMap.li.add(listSetMap.integerMap)); //not possible
    }
}
