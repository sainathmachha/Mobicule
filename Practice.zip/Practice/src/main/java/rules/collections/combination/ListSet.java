package rules.collections.combination;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ListSet {

    static List<Set<String>> firstListSet = new ArrayList<>();
    static List<Set<String>> secondListSet = new ArrayList<>();
    static Set<List<Set<String>>> setListSet = new HashSet<>();
    static List<Integer> list = new ArrayList<>();

    public static void main(String[] args) {

        list.add(254);
        list.add(56);
        list.add(46);
        list.add(56);
        System.out.println(list);

        Set<Integer> set = new HashSet<>(list);
        System.out.println(set);

        //Sets
        System.out.println("<======SET======>\n");

        Set<String> firstSet = new HashSet<>();
        firstSet.add("Hi");
        firstSet.add("Hi");
        firstSet.add("Hello");
        firstSet.add("Hola");
        firstSet.add("Amigos");

        System.out.println("First set : " + firstSet);

        System.out.println("-----------------------");

        Set<String> secondSet = new HashSet<>();
        secondSet.add("One");
        secondSet.add("Two");
        secondSet.add("Three");
        secondSet.add("Four");

        System.out.println("Second set : " + secondSet);

        System.out.println("-----------------------");

        Set<String> thirdSet = new HashSet<>();
        thirdSet.add("Hi");
        thirdSet.add("Hi");
        thirdSet.add("Hello");
        thirdSet.add("Hola");
        thirdSet.add("Amigos");
        System.out.println("Third set : " + thirdSet);

        System.out.println("-----------------------");

        firstListSet.add(firstSet);
        firstListSet.add(secondSet);
        firstListSet.add(thirdSet);
        System.out.println();
        System.out.println("First List of sets : " + firstListSet +"\n\n\n");

        System.out.println("-----------------------");

        Set<String> fourthSet = new HashSet<>();
//        fourthSet.add("Hi");
//        fourthSet.add("Hello");
//        fourthSet.add("Hola");
//        fourthSet.add("Amigos");

        fourthSet.add("S");
        fourthSet.add("A");
        fourthSet.add("I");

        System.out.println("Fourth set : " + fourthSet);

        System.out.println("-----------------------");

        Set<String> fifthSet = new HashSet<>();
        fifthSet.add("One");
        fifthSet.add("Two");
        fifthSet.add("Three");
        fifthSet.add("Four");

        System.out.println("Fifth set : " + fifthSet);

        System.out.println("-----------------------");

        Set<String> sixthSet = new HashSet<>();
        sixthSet.add("Hi");
        sixthSet.add("Hello");
        sixthSet.add("Hola");
        sixthSet.add("Amigos");
        System.out.println("Sixth set : " + sixthSet);

        System.out.println("-----------------------");

        secondListSet.add(fourthSet);
        secondListSet.add(fifthSet);
        secondListSet.add(sixthSet);
        System.out.println();
        System.out.println("Second List of sets : " + secondListSet + "\n\n\n");

        System.out.println("<======== List of Set inside a Set =========>\n");

        setListSet.add(firstListSet);
        setListSet.add(secondListSet);

        System.out.println(setListSet);

        System.out.println("Both List of Sets are equal? : "+firstListSet.equals(secondListSet));
    }
}