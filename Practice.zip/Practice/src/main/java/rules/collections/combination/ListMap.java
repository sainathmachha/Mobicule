package rules.collections.combination;

import java.util.*;

public class ListMap {

    static List<Map<Integer, String>> listMap = new ArrayList<>();

    public static void main(String[] args){

        Map<Integer, String> fMap = new HashMap<>();
        fMap.put(25, "Rohit");
        fMap.put(32, "Sainath");
        fMap.put(36, "Aditya");

        System.out.println("First Map : "+fMap);

        System.out.println("-----------------------------");

        Map<Integer, String> sMap = new HashMap<>();
        sMap.put(10, "Hum");
        sMap.put(15, "Tum");

        System.out.println("Second Map : "+sMap);

        System.out.println("-----------------------------");

        listMap.add(fMap);
        listMap.add(sMap);

        System.out.println("Map inside a List : "+listMap);
        System.out.println();
    }

}
