package rules.collections.Map;

import rules.collections.Iterators.Iterators;
import rules.collections.Iterators.IteratorsImpl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MapDemo extends IteratorsImpl {

    static Map<Integer, String> maps = new HashMap<>();

    public static void main(String[] args) {
        Iterators.MapInterface iterators = new MapDemo();
        maps.put(1,"Sainath");
        maps.put(32, "Sai");
        maps.put(18, "Machha");

        System.out.println(maps.keySet() + " : " + maps.values()+"\n");

        iterators.entrySetIteration(maps);

        System.out.println("\n");

        iterators.keysIteration(maps);

        System.out.println("\n");

        iterators.valuesIteration(maps);

        System.out.println("\n");

        iterators.forEachIteration(maps);

        iterators.mapIterator(maps);
    }
}
