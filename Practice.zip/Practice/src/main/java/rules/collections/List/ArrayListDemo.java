package rules.collections.List;

import rules.collections.Iterators.Iterators;
import rules.collections.Iterators.IteratorsImpl;

import java.util.*;

public class ArrayListDemo extends IteratorsImpl implements Iterators.ListInterface {

    static ArrayList<Integer> list = new ArrayList<>();
    static List<Integer> secondList = Arrays.asList(35,45,56,3,8);
    static List<Integer> copy = list;
    static int[] arr = new int[]{1,2,3};
    static int[] dusra = new int[10];

    public static void main(String[] args) {
        dusra[0] = 1;
        dusra[1] = 2;
        dusra[2] = 3;

        /*
        Adding elements into a list : add();
         */
        list.add(10);
        list.add(20);
        list.add(34);
        list.add(56);
        list.add(230);
        list.add(1,23);
        System.out.println(list);

        System.out.println(Arrays.compare(arr, dusra));

        /*
        Adding a collection directly to the list : addAll();
         */
        list.addAll(secondList);
        System.out.println(list);

        /*
        Getting a element from a Collection : get(i);
         */
        System.out.println(list.get(2));

        /*
        Check for an element : contains();
         */
        System.out.println(list.contains(34));

        /*
        Check for a collection inside a collection: containsAll();
         */
        System.out.println(list.containsAll(secondList));
        System.out.println(secondList.containsAll(list));

        /*
        Compares two Collection/objects for equality
         */
        System.out.println(list.equals(secondList));
        System.out.println(list.equals(copy));

        System.out.println(list.isEmpty());

        /*
        Index of an element : indexOf();
         */
        System.out.println(list.indexOf(34));

        /*
        Clears elements of the list: clear();
         */
        //list.clear();
        System.out.println(list);

        System.out.println(list.lastIndexOf(56));

        /*
        remove an element from the list : remove(i)
         */
        list.remove(2);
        System.out.println(list);

        list.set(2, 32);
        System.out.println(list);

        System.out.println(list.size());

        System.out.println(list.retainAll(secondList));

        /*
        Sublist
         */
        System.out.println(list);
        System.out.println(list.subList(2,5));

        Arrays.fill(arr, 0);
        System.out.println(Arrays.toString(arr));

        list.ensureCapacity(20);

        Object[] arr = list.toArray();
        System.out.println(Collections.max(list));
        System.out.println(Arrays.toString(arr));

        Vector v1 = new Vector<>(Arrays.asList(dusra));
        System.out.println("..................");

        Vector<Integer> list1 = new Vector<>();
        list1.add(1);
        list1.add(35);
        list1.add(56);
        System.out.println(list1);

        System.out.println(list1.size());
        System.out.println(list1.capacity());

        System.out.println("++++++++++++++++++++++++++++");

        //Methods :
        Iterators.ListInterface iterate = new ArrayListDemo();
        iterate.iterateList(list);

        System.out.println("++++++++++++++++++++++++++++");
        iterate.forLoopIteration(list);

        System.out.println("++++++++++++++++++++++++++++");
        iterate.enhancedForLoop(list);

        System.out.println("++++++++++++++++++++++++++++");
        iterate.listIterateList(list);
    }

}
