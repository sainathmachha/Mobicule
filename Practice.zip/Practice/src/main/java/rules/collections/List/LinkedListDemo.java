package rules.collections.List;

import java.util.LinkedList;

public class LinkedListDemo {

    public static LinkedList<Integer> linkedList = new LinkedList<>();

    public static void main(String[] args) {
        linkedList.addFirst(25);
        linkedList.add(15);
        linkedList.add(19);
        linkedList.add(21);
        linkedList.addLast(18);

        System.out.println(linkedList);
        System.out.println(linkedList.peek());
        //Collections.sort(linkedList);
        //System.out.println(linkedList);

        //System.out.println(linkedList.element()); //prints head element

        //System.out.println(linkedList.get(2));

        linkedList.offer(10);
        linkedList.offerFirst(20);
        linkedList.offerLast(34);

        System.out.println(linkedList);
        System.out.println(linkedList.peekFirst());
        System.out.println(linkedList.peekLast());

        System.out.println(linkedList.getFirst());
        System.out.println(linkedList.getLast());

        linkedList.removeFirst();
        linkedList.removeLast();

        System.out.println(linkedList);
    }

}
