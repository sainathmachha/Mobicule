package rules.collections.List;

import java.util.Stack;

public class StackDemo {

    static Stack<Integer> stack = new Stack<>();

    public static void main(String[] args) {
        stack.add(10);
        stack.push(18);
        stack.insertElementAt(34, 1);
        System.out.println(stack);
        System.out.println(stack.peek());

        System.out.println(stack.pop());
        System.out.println(stack);

        System.out.println(stack.empty());
    }

}
