package rules.collections.Iterators;

import java.util.*;

public abstract class IteratorsImpl implements Iterators.ListInterface, Iterators.SetInterface, Iterators.MapInterface {
    @Override
    public void entrySetIteration(Map<Integer, String> map){
        System.out.println("Map Iteration using EntrySet\n");
        for(Map.Entry<Integer, String> entries : map.entrySet()){
            System.out.println("Key : " + entries.getKey());
            System.out.println("Value : " + entries.getValue());
            System.out.println("++++++++++++++++++++++++++++++++");
        }
    }

    @Override
    public void keysIteration(Map<Integer, String> map){
        System.out.println("Map Iteration using KeySet\n");
        for(Integer key : map.keySet()){
            System.out.println("Key : "+ key + " Value : "+map.get(key));
            System.out.println("++++++++++++++++++++++++++++++++");
        }
    }

    @Override
    public void valuesIteration(Map<Integer, String> map){
        System.out.println("Map Iteration using Values\n");
        for(String value : map.values()){
            System.out.println("Value : "+value);
            System.out.println("++++++++++++++++++++++++++++++++");
        }
    }

    @Override
    public void forEachIteration(Map<Integer, String> map){
        System.out.println("Map Iteration using ForEach\n");
        map.forEach((key, value) -> {
            System.out.println("Key: " + key + ", Value: " + value);
        });

        System.out.println("++++++++++++++++++++++++++++++++");
    }

    @Override
    public void mapIterator(Map<Integer, String> map){
        System.out.println("Map Iteration using Iterator\n");

        Iterator<Map.Entry<Integer, String>> mapIterator = map.entrySet().iterator();
        while(mapIterator.hasNext()){
            System.out.println(mapIterator.next());
        }
    }

    @Override
    public void iteratorSet(Set<Integer> set){
        Iterator<Integer> iterator = set.iterator();
        while(iterator.hasNext()){
            System.out.print(iterator.next()+", ");
        }
    }

    @Override
    public void forLoopIteration(List<Integer> list){
        System.out.println("Using a For Loop Iterator \n");
        for(int i = 0; i < list.size(); i++){
            System.out.print(list.get(i) + ", ");
        }
        System.out.println();
    }

    @Override
    public void iterateList(List<Integer> list){
        System.out.println("Using a Iterator \n");
        Iterator<Integer> iterator = list.iterator();
        while(iterator.hasNext()){
            System.out.print(iterator.next()+", ");
        }
        System.out.println();
    }

    @Override
    public void enhancedForLoop(List<Integer> list){
        System.out.println("Using a Enhanced For Loop \n");
        for (Integer i : list){
            System.out.print(i + ", ");
        }
        System.out.println();
    }

    @Override
    public void listIterateList(List<Integer> list){
        System.out.println("Using a List Iterator \n");
        ListIterator<Integer> iterator = list.listIterator();

        System.out.println("Forward : \n");
        while(iterator.hasNext()){
            System.out.print(iterator.next() +", ");
        }

        System.out.println("\n");

        System.out.println("Second : \n");
        while(iterator.hasPrevious()){
            System.out.print(iterator.previous()+", ");
        }
    }
}
