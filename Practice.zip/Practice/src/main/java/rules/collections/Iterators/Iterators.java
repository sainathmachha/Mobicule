package rules.collections.Iterators;

import java.util.*;

public interface Iterators {

    interface SetInterface {
        void iteratorSet(Set<Integer> set);
    }

    interface MapInterface{
        void entrySetIteration(Map<Integer, String> map);
        void keysIteration(Map<Integer, String> map);
        void valuesIteration(Map<Integer, String> map);
        void forEachIteration(Map<Integer, String> map);
        void mapIterator(Map<Integer, String> map);
    }

    interface ListInterface{
        public void listIterateList(List<Integer> list);
        public void forLoopIteration(List<Integer> list);
        public void iterateList(List<Integer> list);
        public void enhancedForLoop(List<Integer> list);
    }
}
