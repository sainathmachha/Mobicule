package rules.collections.ComparableComparator;

import java.util.*;

public class ComparatorClass{

    public static void main(String[] args) {
        List<Students> students = Arrays.asList(
                new Students(3, "Blice"),
                new Students(1, "Cob"),
                new Students(2, "Aharlie"),
                new Students(5, "Cob")
        );

        System.out.println("Name Comparator");

        Collections.sort(students, new NameComparator());
        System.out.println(students);

        System.out.println("\nMultiple Comparator");

        Collections.sort(students, new MultipleComparator());
        System.out.println(students);

        System.out.println("\nRoll Comparator");

        Collections.sort(students, new RollComparator());
        System.out.println(students);
    }
}

class RollComparator implements Comparator<Students>{

    @Override
    public int compare(Students o1, Students o2) {
        return o1.getRoll() - o2.getRoll();
    }

    @Override
    public Comparator<Students> reversed() {
        return Comparator.super.reversed();
    }
}

class MultipleComparator implements Comparator<Students>{

    @Override
    public int compare(Students o1, Students o2) {
        int nameCompareValue = o1.getName().compareTo(o2.getName());
        if(nameCompareValue == 0){
            return o1.getRoll() - o2.getRoll();
        }
        return nameCompareValue;
    }

    @Override
    public Comparator<Students> reversed() {
        return Comparator.super.reversed();
    }
}

class NameComparator implements Comparator<Students>{

    @Override
    public int compare(Students o1, Students o2) {
        return o1.getName().compareTo(o2.getName());
    }

    @Override
    public Comparator<Students> reversed() {
        return Comparator.super.reversed();
    }
}