package rules.collections.ComparableComparator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Students implements Comparable<Students>{
    private int roll;
    private String name;

    public Students(){
    }

    public Students(int roll, String name) {
        this.roll = roll;
        this.name = name;
    }

    public static void main(String[] args) {
        List<Students> studentsList = new ArrayList<>();
        studentsList.add(new Students(32,"Sainath"));
        studentsList.add(new Students(24,"Rohit"));
        studentsList.add(new Students(56,"More"));

        Collections.sort(studentsList);
        System.out.println(studentsList);
    }

    @Override
    public String toString() {
        return "Students{" +
                "roll=" + roll +
                ", name='" + name + '\'' +
                '}';
    }

    public int getRoll() {
        return roll;
    }

    public void setRoll(int roll) {
        this.roll = roll;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int compareTo(Students o) {
        return this.roll - o.getRoll();
    }
}
