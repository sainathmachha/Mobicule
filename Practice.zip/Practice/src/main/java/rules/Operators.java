package rules;

/*

Always be cautious with == for comparing floating-point numbers

Arithmetic - +, -, *, /, %
Assignment - +=, -=, *=, /=, %=
Relational - ==, !=, <=, >=, < , >
Logical - &&, ||, !
Bitwise - &, |, ^, ~
Shift -  <<, >>, >>>
Unary - +, -, ++, --, !
Ternary - condition ? if true : if false
*/

public class Operators {
    int a = -10;

    //Ternary Operator
    public static void main(String[] args) {
        Object s = 1==3 ? 1 : 0;
        System.out.println(s);

        int x = 5;
        System.out.println(++x + x-- + x++ + --x);
    }



    //Arithmetic - +, -, *, /, %
    public int add(int a, int b){
        return a + b;
    }

    public int diff(int a, int b){
        return a - b;
    }

    public int divide(int a, int b){
        return a / b;
    }

    public int multiply(int a, int b){
        return a * b;
    }

    public int remainder(int a, int b){
        return a%b;
    }
}
