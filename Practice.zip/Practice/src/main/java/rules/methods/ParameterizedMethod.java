package rules.methods;

public class ParameterizedMethod {

	public static void diff(int a, int b) {
		System.out.println(a - b);
	}

	public static void main(String[] args) {
		diff(10, 2);
	}

}
