package rules.methods;

public class StaticMethods {

	public static void GetName() {
		System.out.println("Sainath");
	}

	public static void main(String[] args) {
		GetName();
	}
}


/*
Classes
Methods
Constructor
Access Modifiers
Data Types
Type casting
Operators
If else
Switch
For Loop
While Loop
static
break
final
String and its methods
Arrays
Arrays Sorting
Getter and setter methods
*/