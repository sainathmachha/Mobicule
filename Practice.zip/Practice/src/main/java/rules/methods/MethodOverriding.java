package rules.methods;

public class MethodOverriding extends Parent {

	public static void main(String[] args) {
		MethodOverriding mover = new MethodOverriding();
		mover.Property(2500000);
	}

	@Override
	public void Property(double balance) {
		System.out.println("Total balance is : " + balance / 4 + " each.");
	}

}
