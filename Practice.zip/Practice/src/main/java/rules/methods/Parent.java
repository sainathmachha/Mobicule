package rules.methods;

public class Parent {
	double balance;

	public void Property(double balance) {
		this.balance = balance;
		System.out.println("Your balance is : " + balance / 2);
	}

}
