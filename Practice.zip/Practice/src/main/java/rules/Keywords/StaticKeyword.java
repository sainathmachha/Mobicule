package rules.Keywords;

import static java.lang.Math.PI;

//if a inner class is static then only you can declare static variables in it otherwise it cant't

public class StaticKeyword {

    //Static Variable
    static int count = 0;

    static {
        count = 10;
    }

    int a = 10;

    StaticKeyword(){
        count++;
        System.out.println(count);
    }

    static void Square(){
        System.out.println(count * count);
        count++;
    }

    static void StaticImport(){
        System.out.println(PI);
    }

    public static void main(String[] args) {
        StaticKeyword staticKeyword = new StaticKeyword();
        new StaticKeyword();
        new StaticKeyword();
        Square();
        Square();
        new StaticKeyword();
        StaticKeyword.Inner.Method();
        StaticImport();
    }

    static class Inner{
        static void Method(){
            System.out.println(new StaticKeyword().a);
            System.out.println("Static inside Static Class.");
        }
    }

//    class Second{
//        int y = 10;
//        static void StaticMethod(){
//
//        }
//    }
}