package rules.exceptionHandling;

import java.util.Scanner;

public class CustomExceptionDemo {
    static int age;

    public static void main(String[] args) throws ArithmeticException{
        try {
            Scanner sc = new Scanner(System.in);
            age = sc.nextInt();
            if (age == 18) {
                System.out.println("Valid user");
            } else {
                throw new AgeNotValidException("Age is less than 18 : Please enter a valid age.");
            }
        } catch (AgeNotValidException e) {
            e.printStackTrace();
        }
    }
}
