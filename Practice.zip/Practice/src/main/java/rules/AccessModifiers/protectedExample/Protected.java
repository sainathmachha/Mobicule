package rules.AccessModifiers.protectedExample;

import rules.AccessModifiers.AccessModifierRules;

public class Protected extends AccessModifierRules{

    public static void main(String[] args) {
        new Protected().call();
    }

    public void call() { //if you want to use the methods of superclass without super keyword you need to create a method then use/call inside it.
        methodProtected();
        methodPublic();
        //methodPrivate();
        //methodDefault();
    }

}
