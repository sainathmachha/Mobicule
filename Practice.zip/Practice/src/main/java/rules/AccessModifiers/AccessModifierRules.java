package rules.AccessModifiers;

/*

Variables, Classes, Methods can have - 4 Access Modifier - Public, Private, Default, Protected

Top-Level Classes can only be public or package-private (default).
Inner Classes can have private, protected, default, or public access.

You cannot reduce the accessibility of the overridden methods

Private/Final methods cannot be overridden

All variables in interfaces are implicitly: public, static, final

Interfaces methods are by default public abstract & it can have public default methods & public static methods

 */

public class AccessModifierRules {

    public void methodPublic(){
        System.out.println("--> Public methods can be accessed everywhere i.e. inside the package or outside the package of the same or different project.");
    }

    private void methodPrivate(){
        System.out.println("--> Private methods can only be accessed inside the current class not in a subclass or other class in same package or different package.");
    }

    protected void methodProtected(){
        System.out.println("--> Protected methods are accessible inside the current class and subclass inside same or different packages.");
    }

    void methodDefault(){
        System.out.println("--> Default methods can be accessed anywhere inside the same package.");
    }
}

class Private{

    public static void main(String[] args) {
        AccessModifierRules accessModifierRules = new AccessModifierRules();
        //accessModifierRules.methodPrivate(); //not accessible
        accessModifierRules.methodPublic();
        accessModifierRules.methodDefault();
        accessModifierRules.methodProtected();
    }
}