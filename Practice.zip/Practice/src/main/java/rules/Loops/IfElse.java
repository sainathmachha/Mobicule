package rules.Loops;

public class IfElse {

    public static void main(String[] args) {
        int a = 10, b = 20, c = 30;

        int result = ((a > b) ? (a > c) ? a : c : (b > c) ? b : c);

        if(a > b){
            if(a > c){
                System.out.println(a);
            }else{
                System.out.println(c);
            }
        }else{
            if(b>c){
                System.out.println(b);
            }else if(a > b){
                System.out.println(a);
            }
//            if(a>b)
//            {
//                System.out.println(a);
//            }
        }

        System.out.println(result);

        for(int i =0; i<10; i++){
            System.out.println(i);
            if(i==5){
                switch(i){
                    case 1:
                        System.out.println("X" + i);
                        break;
                }
                break;
            }
        }
//        System.out.println("Exited the loop using break");

//        if (false) {
//            System.out.println("Jhoot");
//        } else if (1 == 1) {
//            System.out.println("Sach");
//            return;
//        } else if (true) {
//            System.out.println("After True");
//        } else {
//            System.out.println("No use");
//        }

//        checkReturns();

//        int age = 25;
//
//        if (age < 18) {
//            System.out.println("Minor");
//        } else if (age >= 18 && age <= 65) {
//            System.out.println("Adult");
//        } else {
//            System.out.println("Senior");
//        }

    }

        /*
        infinite loops

        for(;;){
            System.out.println("true");
        }

        while(true){
            System.out.println("true");
        }

        for(int i=0; i>=0 ; i++){
            System.out.println("i"+i);
        }
        */

    public static void checkReturns(){
        if (true) {
            System.out.println("Before Return");
            return;
        }
        System.out.println("After Return");// This will not execute
    }
}
