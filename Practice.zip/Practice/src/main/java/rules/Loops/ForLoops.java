package rules.Loops;


/*
Loop Execution Order:
    1.Initialization happens first and only once.
    2.Condition is checked before each iteration.
    3.Loop body is executed if the condition is true.
    4.Increment/Decrement happens after each iteration.
 */

public class ForLoops {

    public static void main(String[] args) {
        /*
        //Infinite Loops

        for (int i = 0; i < 10; i--) {
            System.out.println(i);  // Never stops
        }
        */

        //Even numbers
        for(int i = 0; i < 10;){
            System.out.println(i);
            i++;
        }

        System.out.println("______________________________");

        for (int i = 0; i < 10; i++) {
            if (i == 5){
                break;
            }

            if (i % 2 == 0) {
                continue;
            }

            System.out.println(i);
        }

        System.out.println();

        for(int i = 0; i<5; i++){
            for(int j = 0; j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }


        for (int i = 0; i < 5; i++) {
            System.out.println(i);
            i++;
        }

    }

}
