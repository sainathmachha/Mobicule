package rules.oops.abstraction;

public interface AbstractionDemo {

    void hiddenImplementation();
}
