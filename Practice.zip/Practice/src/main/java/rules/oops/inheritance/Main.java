package rules.oops.inheritance;

public class Main {
    public static void main(String[] args) {
        Child child = new Child();
        Child.SecondChild secondChild = child.new SecondChild();
        System.out.println("In main class : ");
        secondChild.print(); //from Parent Class
        secondChild.write(); //from Child Class
        secondChild.read(); //from SecondChild Class

        Inherit inherit = new Child();
        inherit.walking();
        inherit.jogging();
        inherit.running();

        //Static method
        Inherit.stat();

        SecondInterface secondInterface = new Child();
        secondInterface.coding();
    }
}
