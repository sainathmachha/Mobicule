package rules.oops.encapsulation;

public class Main {
    public static void main(String[] args) {
        Encapsule encapsule = new Encapsule();
        //encapsule.shares; //not possible

        encapsule.setShares(10000);
        encapsule.setUsername("MrC00L");

        System.out.println(encapsule.getShares());
        System.out.println(encapsule.getUsername());
    }
}
