package rules.oops.encapsulation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GetterAndSetters {

    /*
    Getters and setters are useful for Encapsulation.

    Always use setters to set value for any field.

    Interfaces can have getters and setters.

    Use synchronized keyword for thread safety when the getters or setters are accessed by multiple threads at a time.

    Use private setters to create immutable objects.

    Lazy Initialization using getters.
    Chaining Setters: getterAndSetters.setRoll(32).setName("Sai").setAttendance(true);
     */

    private List<Integer> array = new ArrayList<>();
    private int roll;
    private String name;
    private boolean attendance;
    public GetterAndSetters(int roll, String name){
        setRoll(roll);
        setName(name);
    }

    public static void main(String[] args) {
        GetterAndSetters getterAndSetters = new GetterAndSetters(32, "Sainath");
        System.out.println(getterAndSetters.getRoll());
        System.out.println(getterAndSetters.getName());
        getterAndSetters.setName("Hello");
        getterAndSetters.setRoll(25);
        System.out.println(getterAndSetters.getRoll());
        System.out.println(getterAndSetters.getName());

        System.out.println(getterAndSetters.getArray());
        getterAndSetters.setArray(Arrays.asList(1,2,3,4,5));
        System.out.println(getterAndSetters.getArray());

        getterAndSetters.setRoll(32).setName("Sai").setAttendance(true);
        System.out.println(getterAndSetters.getRoll() + " : " + getterAndSetters.getName() + " : " + getterAndSetters.isAttendance() + " : " + getterAndSetters.getArray());
    }

    public boolean isAttendance() {
        return attendance;
    }

    public void setAttendance(boolean attendance) {
        this.attendance = attendance;
    }

    //Lazy Initialization for memory intensive application
    public List<Integer> getArray(){
        if(array == null){
            array = new ArrayList<>();
        }
        return array;
    }

    public void setArray(List<Integer> array) {
        this.array = array;
    }

    public int getRoll() {
        return roll;
    }

    public GetterAndSetters setRoll(int roll){
        this.roll = roll;
        return this;
    }

    public String getName() {
        return name;
    }

    public GetterAndSetters setName(String name){
        this.name = name;
        return this;
    }

//    public void setRoll(int roll) {
//        this.roll = roll;
//    }

//    public void setName(String name) {
//        this.name = name;
//    }
}
