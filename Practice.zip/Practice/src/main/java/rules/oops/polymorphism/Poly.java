package rules.oops.polymorphism;

public class Poly {

    public static void main(String[] args) {
        new Poly().firstMethod();
    }

    public void firstMethod(){
        System.out.println("First method from First Class...");
    }
}

class Demo extends Poly{

    public static void main(String[] args) {

        Demo demo = new Demo();
        demo.firstMethod();

        Poly poly = new Demo();
        poly.firstMethod();

        Poly parent = new Poly();
        parent.firstMethod();

        /*
        This isn't possible

        Demo pol = new Poly();
        pol.firstMethod();

         */
    }

    //Method Overriding(Runtime Polymorphism)
    @Override
    public void firstMethod(){
        System.out.println("First method from Subclass...");
    }

    //Method Overloading(Compile-time Polymorphism)
    public String firstMethod(String message){
        return "Hello "+message+". This is String First Method.";
    }
}
