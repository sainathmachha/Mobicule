package rules.oops.polymorphism;

/*
Same method name, different parameter list (either in the number of parameters or their types).

Can change the return type, but it doesn’t affect method overloading.

Can have different access modifiers.

type promotion can be possible in method overloading : suppose you are passing a char to a method and no method of char type is present and instead there is a int method, it will simply return the int type output;

 */

public class MethodOverloadingRules {

    public static void main(String[] args) {
        new MethodOverloadingRules().add();
        System.out.println(new MethodOverloadingRules().add('a')); //type promotion happens here
    }

    public int add(int a){
        return a;
    }

    public void add(){
        System.out.println("Adding...");
    }

    public String add(String amount){ //if you don't change the number of parameters or the type of parameters you cannot overload the methods
        return amount;
    }

}
