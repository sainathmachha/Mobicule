package rules.oops.polymorphism;

/*
Same method name, same parameter list.

return type can be the same or a subtype

Access modifier : You can increase the visibility but not decrease it.

Method must be non-static.

Final methods and Private methods cannot be overridden.

You can make a method Final in Child Class even if it's not a final method in Parent Class

 */

public class MethodOverridingRules {

    void ParentMethod(){
        System.out.println("Parent..");
    }
}

class ChildClass extends MethodOverridingRules{

    public static void main(String[] args) {
        new ChildClass().ParentMethod();
    }

    @Override
    protected void ParentMethod(){
        System.out.println("Child..");
    }
}
