package rules;

/*
Data Types: Primitive and Non Primitive
Primitive(value types and store in stack directly):- byte, short, int, long, float, double, boolean, char (Stored in stack)
Non-primitive(reference types so reference stored in stack, while value is stored in heap):- Strings, Arrays, Classes (Stored in heap memory)

Number Types: Integer Types: byte, short, int, long
              Float Types: float(6 decimal digits), double(15 decimal digits)

You cannot directly perform assignments outside of a method or block in Java it must be in a method or a static block
 */

import java.util.Arrays;

public class DataTypesRules {

    static byte aByte = 32;
    static short aShort = 123;
    static int anInt = 4353;
    static long aLong = 324_03_45_40L;
    static float aFloat = .47566255F; //can have 8 digits before point with Single digit precision or vice versa
    static double aDouble = .12345678901234567D; //can have 17 digits after point
    static boolean aBoolean = true;
    static char aChar = 'S';
    static Character c = 'a';
    static int[] arr = {23,32,4354, 45,342};

    //Autoboxing = Primitive -> Wrapper Class
    static Integer integer = new Integer(anInt);

    //Unboxing = Primitive <- Wrapper Class
    static int intU = integer;

    //Implicit Typecasting (smaller to larger does automatically) int -> long
    static long impli = anInt;

    //Explicit Typecasting (larger to smaller need to explicitly do it) long -> int
    static int expli = (int) aLong;

    //Overflow (values above its maximum limit)
    static byte overflowByte = (byte) 128; //-128

    //Underflow (values below its minimum limit)
    static byte underflowByte = (byte) -129;

    /*Type Promotion:
            - Happens when a smaller data type is promoted to a larger data type during operations.
            - Example: Byte -> Short -> Integer -> Long -> Float -> Double
            - Characters are promoted to Integer.
            - Happens automatically if no matching method is found.
    */
    String string = "String Value";

    public static void main(String[] args) {
        System.out.println("Byte : " + aByte); //-128 to 127
        System.out.println("Short : "+ aShort); //-32768 to 32767
        System.out.println("Int : "+ anInt); //-2,147,483,648 to 2,147,483,647
        System.out.println("Long : "+ aLong); //-9,223,372,036,854,775,808 to -9,223,372,036,854,775,807
        System.out.println("Float : "+aFloat); //-3.40282347E+38 to -3.40282347E+38
        System.out.println("Double : "+aDouble); //-1.797693134862315E+308 to -2.225073858507201E-308
        System.out.println("Boolean : "+aBoolean); //
        System.out.println("Char : "+ aChar);
        System.out.println(Integer.SIZE);
        //System.out.println(string);
        System.out.println(integer.getClass().getName());
        //System.out.println(intU.getName().getName());//cause no methods are available for primitive types
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));


        System.out.println(overflowByte);
        System.out.println(underflowByte);
    }
}
