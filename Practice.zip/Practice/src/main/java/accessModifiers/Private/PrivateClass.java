package accessModifiers.Private;

import accessModifiers.Public.AccessModifierExample;

import java.util.*;

public class PrivateClass {
    private int number = AccessModifierExample.num;

    public static void main(String[] args) {
        System.out.println(new PrivateClass().number);

        String result = (new PrivateClass().number > 1) ? "hi" : "hello";
        System.out.println(result);

    }
}
