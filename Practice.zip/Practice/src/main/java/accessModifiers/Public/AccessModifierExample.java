package accessModifiers.Public;

public class AccessModifierExample {
    public static int num = 10;
    public static void main(String[] args){
        System.out.println(num);
    }
}
