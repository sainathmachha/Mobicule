package accessModifiers.Protected;

import accessModifiers.Public.AccessModifierExample;

public class ProtectedClass{

    protected static int val = AccessModifierExample.num;
    //protected static int val = PrivateClass.number;

    public static void main(String[] args) {
        System.out.println(val);
    }

}
