package datatypes;

import java.util.Arrays;

public class DataTypes {

    static byte aByte = 32;
    static short aShort = 123;
    static int anInt = 4353;
    static long aLong = 324_03_45_40L;
    static float aFloat = 13024242.243043F;
    static double aDouble = 234934034.349330D;
    static boolean aBoolean = true;
    static char aChar = 'S';
    static Character c = 'a';
    static String string = "String Value";
    static int[] arr = {23,32,4354, 45,342};

    public static void main(String[] args) {
        System.out.println("Byte : " + aByte); //-128 to 127
        System.out.println("Short : "+ aShort); //-32768 to 32767
        System.out.println("Int : "+ anInt); //-2,147,483,648 to 2,147,483,647
        System.out.println("Long : "+ aLong); //-9,223,372,036,854,775,808 to -9,223,372,036,854,775,807
        System.out.println("Float : "+aFloat); //-3.40282347E+38 to -3.40282347E+38
        System.out.println("Double : "+aDouble); //-1.797693134862315E+308 to -2.225073858507201E-308
        System.out.println("Boolean : "+aBoolean); //
        System.out.println("Char : "+ aChar);
        System.out.println(Integer.SIZE);
        System.out.println(string);
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
