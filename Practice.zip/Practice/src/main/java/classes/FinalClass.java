package classes;

// final method --> cannot be overridden by subclasses
// final class --> cannot be extended

public final class FinalClass {

	static int a = 32;
	static String name = "Sainath";

	public void Show() {
		System.out.println(a);
		System.out.println(name);
	}
}

// public FinalClass(int a, String name) {
// this.a = a;
// this.name = name;
// System.out.println(a + " " + name);
// }

// public static void main(String[] args) {
// FinalClass fc = new FinalClass(a, name);
//
// // fc.Show();
// }

// class Other extends FinalClass {
// @Override
// public void Show() {
// System.out.println("Roll no : " +32 )
// }
// }

class Test {
	public static void main(String[] args) {
		// Other ot = new Other();
		FinalClass fc = new FinalClass();
		fc.Show();
	}
}
