package defaultClasses;

public class DefaultClass {
	
	static String name = "Sainath";
	public int rollNo = 32;

	public DefaultClass(){

	}

	public static void main(String[] args) {
		DefaultClass dc = new DefaultClass();
		System.out.println("Your roll no is :: "+dc.rollNo);
		System.out.println("Your name is :: "+name);
	}
}