package FileHandling;

import java.io.*;

public class FileHandlingDemo {

    public static void main(String[] args) {
        FileHandlingDemo fileHandlingDemo = new FileHandlingDemo();
        File file = fileHandlingDemo.createFile(new StringBuilder("newFile"));
        fileHandlingDemo.writeToFile(file,new StringBuilder("Hey hi how are you?"));
        fileHandlingDemo.readFromFile(file);
    }

    public File createFile(StringBuilder fileName){
        File file = new File(String.valueOf(fileName.append(".txt")));
        StringBuilder stringBuilder = new StringBuilder();
        try {
            if (file.createNewFile()) {
                System.out.println("File created successfully...");
            } else {
                System.out.println("File already exists...");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }

    public void writeToFile(File file, StringBuilder message){
        // Writing to the file using PrintWriter
        try (PrintWriter printWriter = new PrintWriter(new FileWriter(file))) {
            printWriter.append(new StringBuilder(message));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void readFromFile(File file){
        // Reading from the file using BufferedReader
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
