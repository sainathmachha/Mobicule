package org.example;

import org.example.JDBCConnection.TestConnection;
import org.example.roles.Admin;
import org.example.roles.Attendee;

import java.sql.Connection;
import java.sql.Date;
import java.util.Scanner;

import static org.example.CommonDeclarations.role;
import static org.example.DatabaseOperations.result;

public class Menu {
    public static int choice;
    public static Scanner sc = new Scanner(System.in);
    private static String keepGoing;

    public static void main(String[] args) {
        Admin admin = new Admin();
        DatabaseOperations databaseOperations = new DatabaseOperations();
        Connection connection = TestConnection.test();
        try {
            System.out.println("<--- Welcome to the Application --->");
            System.out.println("1.Login or 2.Signup");
            System.out.println("--> select an option to continue : ");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    databaseOperations.Login(connection);
                    do {
                        if (result.equals("ATTENDEE")) {
                            System.out.println("1. Search ");
                            System.out.println("2. Book Event");
                            System.out.println();
                            System.out.println("Enter a choice : ");
                            int choice = sc.nextInt();
                            System.out.println();
                            if (choice == 1) {
                                System.out.println("1. List by city");
                                System.out.println("2. List by Category");
                                System.out.println("3. List by Date");
                                System.out.println();
                                int innerChoice = sc.nextInt();
                                switch (innerChoice) {
                                    case 1:
                                        System.out.println("Enter city : ");
                                        String city = sc.next().trim().toUpperCase();
                                        Attendee.listVenuesByCity(connection, city);
                                        break;
                                    case 2:
                                        System.out.println("Enter Category : ");
                                        String category = sc.next().trim().toUpperCase();
                                        Attendee.listVenuesByCategory(connection, category);
                                        break;
                                    case 3:
                                        System.out.println("Enter Date (YYYY-MM-DD): ");
                                        Date date = Date.valueOf(sc.next());
                                        Attendee.listVenuesByDate(connection, date);
                                        break;
                                }
                            }else if(choice == 2){
                                Attendee.bookEvent(connection);
                            }
                        } else if (result.equals("ADMIN")) {
                            System.out.println("1. Create User");
                            System.out.println("2. Assign Role");
                            System.out.println("3. Delete User");
                            System.out.println("Enter an option : ");
                            int x = sc.nextInt();
                            switch (x) {
                                case 1:
                                    admin.createUser();
                                    break;
                                case 2:
                                    admin.assignRole();
                                    break;
                                case 3:
                                    admin.deleteUser();
                                    break;
                            }
                        } else if (result.equals("ORGANISER")) {
                            System.out.println("1. Add Event");
                            System.out.println("2. Update Event");
                            System.out.println("Enter an option : ");
                            int x = sc.nextInt();
                            switch (x) {
                                case 1:
                                    admin.createUser();
                                    break;
                                case 2:
                                    admin.assignRole();
                                    break;
                                case 3:
                                    admin.deleteUser();
                                    break;
                            }
                        }
                        System.out.println("Do you want to continue (yes or no): ");
                        keepGoing = sc.next();
                    }while(keepGoing.equalsIgnoreCase("YES"));
                    break;
                case 2:
                    databaseOperations.SignUp(connection);
                    break;
                default:
                    System.out.println("Invalid input.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
