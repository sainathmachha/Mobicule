package org.example.roles;

import java.sql.*;
import java.sql.Date;
import java.util.*;

import static org.example.CommonDeclarations.*;

public class Attendee {
    public static int eventId;
    public static String eventCategory, eventLocation,eventCost,eventCapacity,eventStatus,eventCity;
    public static String orgCategory, orgLocation, orgCost, orgCapacity, orgCity;
    public static int index = 0;
    public static List<String> listOfVenuesByCity = new ArrayList<>();
    public static List<String> listOfVenuesByCategory = new ArrayList<>();
    public static List<String> listOfVenuesByDate = new ArrayList<>();
    public static HashMap<String, String> eventCosts = new HashMap<>();
    private static String secondEventCategory;

    //search and view events by category, date or location

    public static void listVenuesByCity(Connection connection, String city){
        query = "SELECT eventLocation, status FROM SAINATHI1436_ORGANISER WHERE status = 'NOT BOOKED' AND eventCity = ?;";
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, city);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                listOfVenuesByCity.add(resultSet.getString(1));
                eventStatus = resultSet.getString(2);
            }
            System.out.println("Available list of Venues are --> \n");
            for (String venues : listOfVenuesByCity){
                System.out.println(index+". "+"Venue : "+venues+", Status : "+eventStatus);
                index++;
            }
        } catch (SQLException e) {
            e.getMessage();
        }
    }

    public static void listVenuesByCategory(Connection connection, String category){
        query = "SELECT eventLocation, status FROM SAINATHI1436_ORGANISER WHERE status = 'NOT BOOKED' AND eventCategory = ?;";
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, category);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                listOfVenuesByCategory.add(resultSet.getString(1));
                eventStatus = resultSet.getString(2);
            }
            System.out.println("Available list of Venues are --> \n");
            for (String venues : listOfVenuesByCategory){
                System.out.println(index+". "+"Venue : "+venues+", Status : "+eventStatus);
                index++;
            }
        } catch (SQLException e) {
            e.getMessage();
        }
    }

    public static void listVenuesByDate(Connection connection, Date date){
        query = "SELECT eventLocation, status FROM SAINATHI1436_ORGANISER WHERE status = 'NOT BOOKED' AND eventDate = ?;";
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setDate(1, date);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                listOfVenuesByDate.add(resultSet.getString(1));
                eventStatus = resultSet.getString(2);
            }
            System.out.println("Available list of Venues are --> \n");
            for (String venues : listOfVenuesByDate){
                System.out.println(index+". "+"Venue : "+venues+", Status : "+eventStatus);
                index++;
            }
        } catch (SQLException e) {
            e.getMessage();
        }
    }

    public static String checkAvailability(Connection connection, String eventLocation){
        String status = "";
        query = "SELECT status FROM SAINATHI1436_ORGANISER WHERE eventLocation = ?";
        try{
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, eventLocation);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                status = resultSet.getString(1);
            }
        }catch (Exception e){
            e.getMessage();
        }
        return status;
    }

    public static void bookEvent(Connection connection) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Fill the following details :: \n");
        System.out.println("Select a category : ");
        System.out.println("1. Birthday");
        System.out.println("2. Seminar / Meeting");
        System.out.println("3. Family Reunion");
        System.out.println("4. Marriage");
        System.out.println("5. Reception");

        int choice = sc.nextInt();
        sc.nextLine();

        String categoryIdQuery = "SELECT eventCategory, eventLocation, eventCost, eventCapacity, eventCity FROM SAINATHI1436_ORGANISER WHERE categoryID = ?";
        String insertQuery = "INSERT INTO SAINATHI1436_EVENT(eventCategory, eventLocation, eventCost, eventDate, eventCapacity, status, eventCity, eventTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement categoryStatement = connection.prepareStatement(categoryIdQuery);
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

            // Fetching category details
            categoryStatement.setInt(1, choice);
            ResultSet secondResultSet = categoryStatement.executeQuery();
                if (secondResultSet.next()) {
                    String orgCategory = secondResultSet.getString(1);
                    String orgLocation = secondResultSet.getString(2);
                    String orgCost = secondResultSet.getString(3);
                    String orgCapacity = secondResultSet.getString(4);
                    String orgCity = secondResultSet.getString(5);

                    // Booking details
                    System.out.println("To see the list of locations, enter your city: ");
                    String eventCity = sc.next().trim();
                    preparedStatement.setString(1, orgCategory);
                    listVenuesByCity(connection, eventCity);

                    sc.nextLine();

                    System.out.println("Enter location: ");
                    String eventLocation = sc.nextLine();
                    System.out.println(eventLocation);
                    preparedStatement.setString(2, eventLocation.toUpperCase());

                    System.out.println("Cost of Events --> " + orgCost);
                    preparedStatement.setString(3, orgCost);

                    System.out.println("Enter the date (YYYY-MM-DD): ");
                    Date eventDate = Date.valueOf(sc.next().trim());
                    preparedStatement.setDate(4, eventDate);

                    System.out.println("Capacity --> "+orgCapacity);
                    System.out.println("Enter no. of Attendee's: ");
                    String eventCapacity = sc.next().trim();
                    while (Integer.parseInt(eventCapacity) > Integer.parseInt(orgCapacity)) {
                        System.out.println("! Cannot accommodate the limit. Try again: ");
                        eventCapacity = sc.next();
                    }
                    preparedStatement.setString(5, eventCapacity);

                    preparedStatement.setString(6, "BOOKED");

                    preparedStatement.setString(7, eventCity);

                    System.out.println("Enter time (hh:mm:ss): ");
                    Time eventTime = Time.valueOf(sc.next().trim());

                    preparedStatement.setTime(8, eventTime);

                    // Execute booking
                    int rowsAffected = preparedStatement.executeUpdate();
                    if (rowsAffected > 0) {
                        System.out.println("( Successfully Booked )");
                        updateOrganiserStatus(connection, eventLocation);
                    } else {
                        System.out.println("! Failed to Book.");
                    }
                } else {
                    System.out.println("Invalid category ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void updateOrganiserStatus(Connection connection, String eventLocation){
        query = "UPDATE TABLE SAINATHI1436_ORGANISER SET status = 'BOOKED' WHERE eventLocation = ?";
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,eventLocation);
            int i = preparedStatement.executeUpdate();
            if(!(i>=1)){
                System.out.println("! Failed to Update");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }
}
