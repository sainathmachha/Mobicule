package org.example.roles;

import java.sql.SQLException;
import java.util.HashMap;

import static org.example.CommonDeclarations.*;

public class Organiser extends Admin{

    //add/update/delete events
    HashMap<String, Integer> categoryId = new HashMap<>();
    String eventCategory, eventCost, eventCapacity, eventCity, eventLocation;

    public Organiser(){
        categoryId.put("BIRTHDAY", 1);
        categoryId.put("SEMINAR", 2);
        categoryId.put("FAMILY_REUNION", 3);
        categoryId.put("MARRIAGE", 4);
        categoryId.put("RECEPTION", 5);
    }

    public void addVenue(){
        query = "INSERT INTO SAINATHI1436_ORGANISER(categoryId, eventCategory, eventCost, eventCapacity, eventCity, eventLocation) VALUES (?,?,?,?,?,?)";
        try {
            preparedStatement = connection.prepareStatement(query);

            System.out.println("Enter category : ");
            eventCategory = sc.next().trim();
            preparedStatement.setInt(1,categoryId.get(eventCategory));
            preparedStatement.setString(2,eventCategory);

            System.out.println("Enter city : ");
            eventCity = sc.next().trim();
            preparedStatement.setString(5,eventCity);

            System.out.println("Enter location : ");
            eventLocation = sc.next().trim();
            preparedStatement.setString(5,eventLocation);

            System.out.println("Enter charges (in Rupees) : ");
            eventCost = sc.next().trim();
            preparedStatement.setString(3,eventCost);

            System.out.println("Enter capacity : ");
            eventCapacity = sc.next().trim();
            preparedStatement.setString(4,eventCapacity);

        } catch (SQLException e) {
            e.getMessage();
        }
    }

    public void updateVenue(){
    }

    public void deleteVenue(){

    }
}
