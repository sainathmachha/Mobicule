package org.example.roles;

import org.example.DatabaseOperations;
import org.example.JDBCConnection.TestConnection;

import java.sql.Connection;

public class Admin {

    DatabaseOperations databaseOperations = new DatabaseOperations();
    Connection connection = TestConnection.test();

    //create, update and delete events(Admin and organizer)

    public void createUser(){
        databaseOperations.SignUp(connection);
    }

    public void deleteUser(){
        databaseOperations.deleteUser(connection);
    }

    public void assignRole(){
        databaseOperations.updateRole(connection);
    }
}
