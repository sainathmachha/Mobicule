package org.example;

import org.example.JDBCConnection.TestConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import static org.example.JDBCConnection.TestConnection.*;

public class CommonDeclarations {

    public static Statement statement;
    public static PreparedStatement preparedStatement;
    public static ResultSet resultSet;
    public static Scanner sc = new Scanner(System.in);
    public static String username;
    public static String password;
    public static String contact;
    public static String role;
    public static String dbPassword;
    public static String dbUsername;
    public static String query;
    public static String rePassword;
    public static boolean status = false;
    public static String dbRole;
}
