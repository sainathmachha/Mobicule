package org.example;

import java.sql.Date;
import java.sql.Time;

public class EventClass {
    int eventId;
    String eventCategory;
    String eventLocation;
    String eventCost;
    Date eventDate;
    String eventCapacity;
    String eventStatus;
    String eventCity;
    Time eventTime;
}
