package org.example;

public class Event {
}
