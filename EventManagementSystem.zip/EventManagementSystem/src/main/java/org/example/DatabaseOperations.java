package org.example;

import org.example.JDBCConnection.TestConnection;

import java.sql.*;

import static org.example.CommonDeclarations.*;

public class DatabaseOperations {
    public static String result;
    Connection connection = TestConnection.test();

    public void Login(Connection connection){
        System.out.println("<> Enter your USERNAME and PASSWORD to continue <>\n");
        System.out.println("Username : ");
        username = sc.next().trim();
        System.out.println("Password : ");
        password = sc.next().trim();
        query = "SELECT username, password, role FROM SAINATHI1436_USER WHERE username = ?";
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,username);

            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                dbUsername = resultSet.getString(1);
                dbPassword = resultSet.getString(2);
                dbRole = resultSet.getString(3);
            }
            if(isExist(connection,username) && dbPassword.equals(password)){
                System.out.println("( Login successful )");
                result = getRole(connection, username);
            }else{
                System.out.println("! Incorrect user credentials");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //System.out.println("<> Register Yourself <>\n");
    public void SignUp(Connection connection){
        System.out.println("--> Username : ");
        username = sc.next().trim();
        System.out.println("--> Contact : ");
        contact = sc.next().trim();
        while(contact.length()<10){
            System.out.println("--> Enter a valid mobile number : ");
            contact = sc.next().trim();
        }
        System.out.println("--> Password : ");
        password = sc.next().trim();
        while(password.length()<=8 || password.length()>=15){
            System.out.println("--> Password cannot be less than 8 AND greater than 15 : ");
            contact = sc.next().trim();
        }
        System.out.println("--> Re-Enter your password : ");
        rePassword = sc.next().trim();

        if(isExist(connection, username)){
            System.out.println("! User already exists.");
        }else {
            query = "INSERT INTO SAINATHI1436_USER(username, contact, password) VALUES(?, ?, ?)";
            try {
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, contact);
                preparedStatement.setString(3, password);
                int i = preparedStatement.executeUpdate();
                if (i >= 1) {
                    System.out.println("( User created successfully )");
                    status = true;
                } else {
                    System.out.println("! Failed to create user )");
                    status = false;
                }
            } catch (SQLException e) {
                e.getMessage();
            }
        }
    }

    public boolean isExist(Connection connection, String username){
        query = "SELECT username, password FROM SAINATHI1436_USER WHERE username = ?";
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,username);

            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                dbUsername = resultSet.getString(1);
                dbPassword = resultSet.getString(2);
                if(dbUsername.equals(username)){
                    status = true;
                }
            }
        } catch (SQLException e) {
            e.getMessage();
        }
        return status;
    }

    public String getRole(Connection connection, String username){
        query = "SELECT role FROM SAINATHI1436_USER WHERE username = ?";
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,username);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                role = resultSet.getString(1);
                if(role.equals("ATTENDEE")){
                    result = "ATTENDEE";
                } else if (role.equals("ADMIN")) {
                    result = "ADMIN";
                }else{
                    result = "ORGANISER";
                }
            }
        } catch (SQLException e) {
            e.getMessage();
        }
        return result;
    }

    public void deleteUser(Connection connection){
        System.out.println("Enter username : ");
        username = sc.next().trim();
        if(isExist(connection, username)) {
            query = "DELETE FROM SAINATHI1436_USER WHERE USERNAME = ?";
            try {
                connection.prepareStatement(query);
                preparedStatement.setString(1, username);
                int i = preparedStatement.executeUpdate();
                if(i>=1){
                    System.out.println("( Deleted successfully )");
                }
                System.out.println("! Failed to delete");
            } catch (SQLException e) {
                e.getMessage();
            }
        }else{
            System.out.println("! Invalid User");
        }
    }

    public void updateRole(Connection connection){
        System.out.println("Enter username : ");
        username = sc.next().trim();
        System.out.println("Select a role : (ADMIN, ORGANISER, ATTENDEE)");
        role = sc.next().trim().toUpperCase();
        if(isExist(connection, username)) {
            query = "UPDATE SAINATHI1436_USER SET role = ? WHERE username = ?";
            try {
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, role);
                preparedStatement.setString(2, username);
                int i = preparedStatement.executeUpdate();
                if(i>=1){
                    System.out.println("( Role updated successfully ) ");
                }else{
                    System.out.println("! Failed to update");
                }
            } catch (Exception e) {
                e.getMessage();
            }
        }else{
            System.out.println("! User doesn't exist");
        }
    }
}
