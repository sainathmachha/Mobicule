package org.example;

import org.example.JDBCConnection.TestConnection;
import org.example.controller.EventController;
import org.example.controller.UserController;
import org.example.entities.Event;
import org.example.entities.User;

import java.sql.Connection;
import java.util.Scanner;

public class Main {
    private static String loggedInUser  = null;
    private static boolean logout = false;

    public static void main(String[] args) {
        Connection connection = TestConnection.test();
        Scanner sc = new Scanner(System.in);
        UserController userController = new UserController();
        EventController eventController = new EventController();

        while (true) {
            System.out.println("1. LOGIN");
            System.out.println("2. SIGNUP");
            System.out.print("SELECT AN OPTION: ");
            String opt = sc.nextLine().trim();

            if (opt.equals("2")) {
                signUp(connection, userController);
            }

            if (opt.equals("1")) {
                loggedInUser  = login(connection);
                if (loggedInUser  != null) {
                    while (!logout) {
                        System.out.println("1. VIEW ALL USERS");
                        System.out.println("2. ADD USER");
                        System.out.println("3. DELETE USER");
                        System.out.println("4. VIEW ALL EVENTS");
                        System.out.println("5. ADD EVENT");
                        System.out.println("6. DELETE EVENT");
                        System.out.print("SELECT AN OPTION: ");
                        String choice = sc.nextLine().trim();

                        switch (choice) {
                            case "1":
                                userController.getAllUsers(connection).forEach(user -> System.out.println(user.getFullName()));
                                break;
                            case "2":
                                User user = new User();
                                // Set user properties from input
                                userController.addUser (connection, user);
                                break;
                            case "3":
                                System.out.print("Enter User ID to delete: ");
                                int userId = Integer.parseInt(sc.nextLine());
                                userController.deleteUser (connection, userId);
                                break;
                            case "4":
                                eventController.getAllEvents(connection).forEach(event -> System.out.println(event.getEventName()));
                                break;
                            case "5":
                                Event event = new Event();
                                // Set event properties from input
                                eventController.addEvent(connection, event);
                                break;
                            case "6":
                                System.out.print("Enter Event ID to delete: ");
                                int eventId = Integer.parseInt(sc.nextLine());
                                eventController.deleteEvent(connection, eventId);
                                break;
                            default:
                                System.out.println("Invalid choice.");
                        }
                    }
                }
            }
        }
    }

    private static void signUp(Connection connection, UserController userController) {
        Scanner sc = new Scanner(System.in);
        User user = new User();
        // Set user properties from input
        userController.addUser(connection, user);
    }

    private static String login(Connection connection) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = sc.nextLine();
        System.out.print("Enter password: ");
        String password = sc.nextLine();
        // Validate user credentials
        return username; // Return username if valid, else return null
    }
}
