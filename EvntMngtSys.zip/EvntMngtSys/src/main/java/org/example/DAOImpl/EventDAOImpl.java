package org.example.DAOImpl;

import org.example.DAO.EventDAO;
import org.example.entities.Event;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EventDAOImpl implements EventDAO{

    @Override
    public void addEvent(Connection connection, Event event) {
        String query = "INSERT INTO EVENTSI1436(eventName, description, organizerId, eventDate, eventTime, venue, capacity, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, event.getEventName());
            preparedStatement.setString(2, event.getDescription());
            preparedStatement.setInt(3, event.getOrganizerId());
            preparedStatement.setDate(4, (Date) event.getEventDate());
            preparedStatement.setTime(5, event.getEventTime());
            preparedStatement.setString(6, event.getVenue());
            preparedStatement.setInt(7, event.getCapacity());
            preparedStatement.setString(8, event.getStatus());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Event> getAllEvents(Connection connection) {
        List<Event> events = new ArrayList<>();
        String query = "SELECT * FROM EVENTSI1436;";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                Event event = new Event();
                event.setEventId(resultSet.getInt("eventId"));
                event.setEventName(resultSet.getString("eventName"));
                event.setDescription(resultSet.getString("description"));
                event.setOrganizerId(resultSet.getInt("organiserId"));
                event.setEventDate(resultSet.getDate("eventDate"));
                event.setEventTime(resultSet.getTime("eventTime"));
                event.setVenue(resultSet.getString("venue"));
                event.setCapacity(resultSet.getInt("capacity"));
                event.setStatus(resultSet.getString("status"));
                events.add(event);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return events;
    }

    @Override
    public void deleteEvent(Connection connection, int eventId) {
        String query = "DELETE FROM EVENTSI1436 WHERE eventId = ?;";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Event getEventById(Connection connection, int eventId) {
        Event event = null;
        String query = "SELECT * FROM EVENTSI1436 WHERE eventId = ?;";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                event = new Event();
                event.setEventId(resultSet.getInt("eventId"));
                event.setEventName(resultSet.getString("eventName"));
                event.setDescription(resultSet.getString("description"));
                event.setOrganizerId(resultSet.getInt("organizerId"));
                event.setEventDate(resultSet.getDate("eventDate"));
                event.setEventTime(resultSet.getTime("eventTime"));
                event.setVenue(resultSet.getString("venue"));
                event.setCapacity(resultSet.getInt("capacity"));
                event.setStatus(resultSet.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return event;
    }
}
