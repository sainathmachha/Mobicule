package org.example.DAO;

import org.example.entities.User;

import java.sql.Connection;
import java.util.List;

public interface UserDAO {
    void addUser (Connection connection, User user);
    List<User> getAllUsers(Connection connection);
    void deleteUser (Connection connection, int userId);
    User getUserById(Connection connection, int userId);
}
