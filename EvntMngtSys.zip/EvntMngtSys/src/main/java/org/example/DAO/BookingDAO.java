package org.example.DAO;

import java.sql.Connection;

public interface BookingDAO {
    void deleteBookingsByEvent(Connection connection, int eventId);
    void deleteBookingsByUser(Connection connection, int userId);
}
