package org.example.DAO;

import org.example.entities.Event;

import java.sql.Connection;
import java.util.List;

public interface EventDAO {
    void addEvent(Connection connection, Event event);
    List<Event> getAllEvents(Connection connection);
    void deleteEvent(Connection connection, int eventId);
    Event getEventById(Connection connection, int eventId);
}
