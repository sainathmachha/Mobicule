package org.example.service.impl;

import org.example.DAO.UserDAO;
import org.example.DAOImpl.UserDAOImpl;
import org.example.entities.User;
import org.example.service.UserService;

import java.sql.Connection;
import java.util.List;

public class UserServiceImpl implements UserService {
    private UserDAO userDAO = new UserDAOImpl();

    @Override
    public void addUser (Connection connection, User user) {
        userDAO.addUser (connection, user);
    }

    @Override
    public List<User> getAllUsers(Connection connection) {
        return userDAO.getAllUsers(connection);
    }

    @Override
    public void deleteUser (Connection connection, int userId) {
        userDAO.deleteUser (connection, userId);
    }

    @Override
    public User getUserById(Connection connection, int userId) {
        return userDAO.getUserById(connection, userId);
    }
}
