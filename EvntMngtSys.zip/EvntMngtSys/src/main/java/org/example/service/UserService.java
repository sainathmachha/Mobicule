package org.example.service;

import org.example.entities.User;

import java.sql.Connection;
import java.util.List;

public interface UserService {
    void addUser (Connection connection, User user);
    List<User> getAllUsers(Connection connection);
    void deleteUser (Connection connection, int userId);
    User getUserById(Connection connection, int userId);
}
