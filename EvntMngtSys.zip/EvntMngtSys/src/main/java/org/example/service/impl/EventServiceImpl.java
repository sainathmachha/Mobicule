package org.example.service.impl;

import org.example.DAO.EventDAO;
import org.example.DAOImpl.EventDAOImpl;
import org.example.entities.Event;
import org.example.service.EventService;

import java.sql.Connection;
import java.util.List;

public class EventServiceImpl implements EventService {
    private EventDAO eventDAO = new EventDAOImpl();

    @Override
    public void addEvent(Connection connection, Event event) {
        eventDAO.addEvent(connection, event);
    }

    @Override
    public List<Event> getAllEvents(Connection connection) {
        return eventDAO.getAllEvents(connection);
    }

    @Override
    public void deleteEvent(Connection connection, int eventId) {
        eventDAO.deleteEvent(connection, eventId);
    }

    @Override
    public Event getEventById(Connection connection, int eventId) {
        return eventDAO.getEventById(connection, eventId);
    }
}
