package org.example.controller;

import org.example.entities.User;
import org.example.service.UserService;
import org.example.service.impl.UserServiceImpl;

import java.sql.Connection;
import java.util.List;

public class UserController {
    private UserService userService = new UserServiceImpl();

    public void addUser (Connection connection, User user) {
        userService.addUser (connection, user);
    }

    public List<User> getAllUsers(Connection connection) {
        return userService.getAllUsers(connection);
    }

    public void deleteUser (Connection connection, int userId) {
        userService.deleteUser (connection, userId);
    }

    public User getUserById(Connection connection, int userId) {
        return userService.getUserById(connection, userId);
    }
}
