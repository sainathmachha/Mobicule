package org.example.controller;

import org.example.entities.Event;
import org.example.service.EventService;
import org.example.service.impl.EventServiceImpl;

import java.sql.Connection;
import java.util.List;

public class EventController {
    private EventService eventService = new EventServiceImpl();

    public void addEvent(Connection connection, Event event) {
        eventService.addEvent(connection, event);
    }

    public List<Event> getAllEvents(Connection connection) {
        return eventService.getAllEvents(connection);
    }

    public void deleteEvent(Connection connection, int eventId) {
        eventService.deleteEvent(connection, eventId);
    }

    public Event getEventById(Connection connection, int eventId) {
        return eventService.getEventById(connection, eventId);
    }
}
