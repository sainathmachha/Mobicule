package org.example.dao;

import org.example.JDBCConnection.TestConnection;
import org.example.model.Task;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TaskDAOImpl implements TaskDAO {

    private Connection connection = TestConnection.test();

    @Override
    public void addTask(String title, String description) {

    }

    @Override
    public List<Task> getAllTasks() {
        return Collections.emptyList();
    }

    @Override
    public Task getTaskById(int id) {
        return null;
    }

    @Override
    public List<Task> getTasksByStatus(String status) {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT * FROM tasks WHERE status = ?";
        try (Connection conn = connection;
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                tasks.add(new Task(rs.getInt("id"), rs.getString("title"),
                        rs.getString("description"), rs.getString("status")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tasks;
    }

    @Override
    public void updateTask(int id, String title, String description, String status) {

    }

    @Override
    public void markTaskAsCompleted(int id) {
        String sql = "UPDATE tasks SET status = 'Completed' WHERE id = ?";
        try (Connection conn = connection;
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Task marked as completed.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteTask(int id) {

    }

    @Override
    public void clearAllCompletedTasks() {
        String sql = "DELETE FROM tasks WHERE status = 'Completed'";
        try (Connection conn = connection;
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.executeUpdate();
            System.out.println("All completed tasks cleared.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getPendingTaskCount() {
        String sql = "SELECT COUNT(*) FROM tasks WHERE status != 'Completed'";
        try (Connection conn = connection;
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int getTotalTaskCount() {
        String sql = "SELECT COUNT(*) FROM tasks";
        Connection conn = connection;
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
