package org.example.dao;

import org.example.model.Task;

import java.util.List;

public interface TaskDAO {
    void addTask(String title, String description);
    List<Task> getAllTasks();
    Task getTaskById(int id);
    List<Task> getTasksByStatus(String status);
    void updateTask(int id, String title, String description, String status);
    void markTaskAsCompleted(int id);
    void deleteTask(int id);
    void clearAllCompletedTasks();
    int getPendingTaskCount();
    int getTotalTaskCount();
}
