package org.example.JDBCConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnection {
    private static final String url = "jdbc:mysql://localhost:3306/saidb";
    //"jdbc:sqlserver://10.1.1.196;databaseName=TRAINING_DB";
    private static final String username =  "root";//"sa";
    private static final String password = "Sainath1811@mysqL";//"M0b1cule!";
    private static Connection connection;

    public static Connection test() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(url, username, password);
            if (connection.isValid(10)) {
                System.out.println("Connection established successfully.");
            } else {
                System.out.println("Failed to connect to the database.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }
}
