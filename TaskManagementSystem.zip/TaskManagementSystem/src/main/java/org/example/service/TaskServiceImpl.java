package org.example.service;

import org.example.JDBCConnection.TestConnection;
import org.example.dao.TaskDAO;
import org.example.dao.TaskDAOImpl;
import org.example.model.Task;

import java.sql.Connection;
import java.util.Collections;
import java.util.List;

public class TaskServiceImpl implements TaskService {

    private final TaskDAO taskDAO = new TaskDAOImpl();

    @Override
    public void createTask(String title, String description) {
        taskDAO.addTask(title, description);
    }

    @Override
    public List<Task> fetchAllTasks() {
        return taskDAO.getAllTasks();
    }

    @Override
    public Task fetchTaskById(int id) {
        return taskDAO.getTaskById(id);
    }

    @Override
    public void modifyTask(int id, String title, String description, String status) {
        taskDAO.updateTask(id, title, description, status);
    }

    @Override
    public void removeTask(int id) {
        taskDAO.deleteTask(id);
    }

    @Override
    public List<Task> fetchTasksByStatus(String status) {
        return taskDAO.getTasksByStatus(status);
    }

    @Override
    public void completeTask(int id) {
        taskDAO.markTaskAsCompleted(id);
    }

    @Override
    public void deleteCompletedTasks() {
        taskDAO.clearAllCompletedTasks();
    }

    @Override
    public int getPendingTasks() {
        return taskDAO.getPendingTaskCount();
    }

    @Override
    public int getTotalTasks() {
        return taskDAO.getTotalTaskCount();
    }
}
