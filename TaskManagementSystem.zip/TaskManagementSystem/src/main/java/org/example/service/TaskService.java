package org.example.service;

import org.example.model.Task;

import java.util.List;

public interface TaskService {
    void createTask(String title, String description);
    List<Task> fetchAllTasks();
    Task fetchTaskById(int id);
    List<Task> fetchTasksByStatus(String status);
    void modifyTask(int id, String title, String description, String status);
    void completeTask(int id);
    void removeTask(int id);
    void deleteCompletedTasks();
    int getPendingTasks();
    int getTotalTasks();
}
