package org.example;

import org.example.JDBCConnection.TestConnection;
import org.example.model.Task;
import org.example.service.TaskService;
import org.example.service.TaskServiceImpl;

import java.util.List;
import java.util.Scanner;

public class TaskManager {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TaskService taskService = new TaskServiceImpl();

        while (true) {
            System.out.println("\n1. Add Task\n2. View Tasks\n3. View Tasks by Status\n4. Mark Task as Completed" +
                    "\n5. Update Task\n6. Delete Task\n7. Clear Completed Tasks\n8. View Pending Task Count" +
                    "\n9. View Total Tasks\n10. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    System.out.print("Enter Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter Description: ");
                    String description = scanner.nextLine();
                    taskService.createTask(title, description);
                    break;
                case 2:
                    List<Task> tasks = taskService.fetchAllTasks();
                    tasks.forEach(System.out::println);
                    break;
                case 3:
                    System.out.print("Enter Status (Pending, In Progress, Completed): ");
                    String status = scanner.nextLine();
                    List<Task> filteredTasks = taskService.fetchTasksByStatus(status);
                    filteredTasks.forEach(System.out::println);
                    break;
                case 4:
                    System.out.print("Enter Task ID to mark as completed: ");
                    int completeId = scanner.nextInt();
                    taskService.completeTask(completeId);
                    break;
                case 5:
                    System.out.print("Enter Task ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter New Title: ");
                    String newTitle = scanner.nextLine();
                    System.out.print("Enter New Description: ");
                    String newDesc = scanner.nextLine();
                    System.out.print("Enter Status: ");
                    String newStatus = scanner.nextLine();
                    taskService.modifyTask(id, newTitle, newDesc, newStatus);
                    break;
                case 6:
                    System.out.print("Enter Task ID to delete: ");
                    int deleteId = scanner.nextInt();
                    taskService.removeTask(deleteId);
                    break;
                case 7:
                    taskService.deleteCompletedTasks();
                    break;
                case 8:
                    System.out.println("Pending Tasks: " + taskService.getPendingTasks());
                    break;
                case 9:
                    System.out.println("Total Tasks: " + taskService.getTotalTasks());
                    break;
                case 10:
                    System.exit(0);
            }
        }
    }
}
