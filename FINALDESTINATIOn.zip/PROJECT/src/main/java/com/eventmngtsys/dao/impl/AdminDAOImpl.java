package com.eventmngtsys.dao.impl;

import com.eventmngtsys.HashingPassword;
import com.eventmngtsys.dao.AdminDAO;
import com.eventmngtsys.entity.Event;
import com.eventmngtsys.entity.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static com.eventmngtsys.presentation.Main.connection;

public class AdminDAOImpl implements AdminDAO {

    @Override
    public boolean addUserInDB(User user) {
        String query = "INSERT INTO USERI1436(NAME, EMAIL, MOBILENUMBER, PASSWORD, ROLE) VALUES (?, ?, ?, ?, ?);";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, user.getName());
            preparedStatement.setString(2, user.getEmail());
            preparedStatement.setString(3, user.getMobileNumber());
            preparedStatement.setString(4, HashingPassword.hashPassword(user.getPassword()));
            preparedStatement.setString(5, user.getRole());
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error adding user: " + e.getMessage());
        }
        return false;
    }

    @Override
    public List<User> viewAllUsers() {
        List<User> usersList = new ArrayList<>();

        String query = "SELECT USERID, NAME, EMAIL, ROLE FROM USERI1436 WHERE ROLE = 'USER' OR ROLE = 'ORGANISER';";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
             while (resultSet.next()) {
                usersList.add(new User(resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getString(4)));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving users: " + e.getMessage());
        }
        return usersList;
    }

    @Override
    public boolean deleteUserFromDB(int userId) {
        String deleteBookingsQuery = "DELETE FROM BOOKINGSI1436 WHERE userId = ?";
        String deleteUserQuery = "DELETE FROM USERI1436 WHERE userId = ?";
        try (PreparedStatement deleteBookingsStmt = connection.prepareStatement(deleteBookingsQuery);
             PreparedStatement deleteUserStmt = connection.prepareStatement(deleteUserQuery)) {

            deleteBookingsStmt.setInt(1, userId);
            deleteBookingsStmt.executeUpdate();

            deleteUserStmt.setInt(1, userId);
            return deleteUserStmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting user: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean manageRoles(User user) {
        String query = "UPDATE USERI1436 SET ROLE = ? WHERE USERID = ?;";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, user.getRole());
            preparedStatement.setInt(2, user.getUserId());
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating role: " + e.getMessage());
        }
        return false;
    }

    @Override
    public List<Event> viewAllEventFromDB() {
        List<Event> eventsList = new ArrayList<>();
        String query = "SELECT eventId, eventName, description, organiserId, eventdate, eventTime, venue, capacity, status, price FROM EVENTSI1436;";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                eventsList.add(new Event(
                        resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getInt(4),
                        resultSet.getDate(5),
                        resultSet.getTime(6),
                        resultSet.getString(7),
                        resultSet.getInt(8),
                        resultSet.getString(9),
                        resultSet.getLong(10)));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving events: " + e.getMessage());
        }
        return eventsList;
    }

    @Override
    public boolean validateUserCredentials(String username, String password){
        String query = "SELECT name,password FROM USERI1436 WHERE name = ? AND password = ?;";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,username);
            preparedStatement.setString(2,password);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                return username.equals(resultSet.getString(1)) && password.equals(resultSet.getString(2));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public String getUserRole(String username) {
        String dbUsername = "";
        String query = "SELECT ROLE FROM USERI1436 WHERE name = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,username);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                dbUsername = resultSet.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dbUsername;
    }

    @Override
    public int getUserId(String username) {
        int dbUserId = 0;
        String query = "SELECT USERID FROM USERI1436 WHERE name = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,username);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                dbUserId = resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dbUserId;
    }

    @Override
    public boolean checkIfUsernameAlreadyExists(String username) {
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE name = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                return resultSet.getInt(1)>0;
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean checkIfEmailAlreadyExists(String email) {
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE email = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                return resultSet.getInt(1)>0;
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean checkIfUserExistToDelete(int userId){
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE userId = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                return resultSet.getInt(1)>0;
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }
}
