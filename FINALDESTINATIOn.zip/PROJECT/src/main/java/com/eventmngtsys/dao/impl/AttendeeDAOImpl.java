package com.eventmngtsys.dao.impl;

import com.eventmngtsys.dao.AttendeeDAO;
import com.eventmngtsys.entity.BookedEvents;
import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Feedback;
import net.glxn.qrgen.QRCode;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AttendeeDAOImpl implements AttendeeDAO {
    private final Connection connection;

    public AttendeeDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public String generateQR(int bookingId, int eventId, String username, String paymentMethod, long amountPaid){
        String qrData = "BOOKINGID_" + bookingId + "_EVENTID_" + eventId + "_USERNAME_" + username + "_PAYMENTMETHOD_" + paymentMethod + "_AMOUNTPAID_" + amountPaid;

        String dirPath = "home\\BOOKINGS\\";
        String fileName = qrData + ".png";
        File dir = new File(dirPath);

        if (!dir.exists()) {
            dir.mkdirs();
        }

        try {
            File qrFile = new File(dir, fileName);
            QRCode.from(qrData).withSize(250, 250).writeTo(Files.newOutputStream(qrFile.toPath()));

            if (qrFile.exists()) {
                return qrData;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean createBooking(Booking booking) {
        if (!userExists(booking.getUserId())) {
            System.out.println("User does not exist.");
            return false;
        }
        String query = "INSERT INTO BOOKINGSI1436(eventId, userId,username, seatsBooked, bookingStatus, amount) VALUES (?, ?, ?, ?,?,?);";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, booking.getEventId());
            preparedStatement.setInt(2, booking.getUserId());
            preparedStatement.setString(3,booking.getUsername());
            preparedStatement.setInt(4, booking.getSeatsBooked());
            preparedStatement.setString(5, "PAYMENT PENDING");
            preparedStatement.setLong(6,getBookingAmount(booking.getEventId(), booking.getSeatsBooked()));
            if (preparedStatement.executeUpdate() > 0) {

                //Updating Capacity in events table
                updateSeatsLeft(booking.getEventId(), booking.getSeatsBooked());
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateSeatsLeft(int eventId, int seatsBooked) {
        String query = "UPDATE EVENTSI1436 SET capacity = capacity - ? WHERE eventId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, seatsBooked);
            preparedStatement.setInt(2, eventId);

            if (preparedStatement.executeUpdate() > 0) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    @Override
    public List<BookedEvents> viewBookedEvents(int userId) {
        List<BookedEvents> bookedEvents = new ArrayList<>();
        String query = "SELECT E.eventName, E.description, E.eventDate, E.eventTime, E.status, "
                + "B.bookingId, B.eventId, B.seatsBooked, B.bookingStatus, B.amount "
                + "FROM EVENTSI1436 E "
                + "JOIN BOOKINGSI1436 B ON E.eventId = B.eventId "
                + "WHERE B.userId = ?;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {

                // Iterate and print results
                while (resultSet.next()) {
                    bookedEvents.add(new BookedEvents(resultSet.getInt("bookingId"),
                            resultSet.getInt("eventId"),
                            resultSet.getString("eventName"),
                            resultSet.getString("description"),
                            resultSet.getDate("eventDate"),
                            resultSet.getTime("eventTime"),
                            resultSet.getInt("seatsBooked"),
                            resultSet.getString("bookingStatus"),
                            resultSet.getLong("amount")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookedEvents;
    }


    @Override
    public boolean userExists(int userId) {
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE userId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next() && resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean cancelBookedEvent(int bookingId, int userId) {
        String fetchQuery = "SELECT eventId, seatsBooked FROM BOOKINGSI1436 WHERE bookingId = ? AND userId = ?";

        int eventId = 0;
        int seatsBooked = 0;

        try (PreparedStatement fetchStmt = connection.prepareStatement(fetchQuery)) {
            fetchStmt.setInt(1, bookingId);
            fetchStmt.setInt(2, userId);
            try (ResultSet rs = fetchStmt.executeQuery()) {
                if (rs.next()) {
                    eventId = rs.getInt("eventId");
                    seatsBooked = rs.getInt("seatsBooked");
                } else {
                    return false; // Booking not found
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        String cancelQuery = "UPDATE BOOKINGSI1436 SET bookingStatus = 'CANCELLED', seatsBooked = 0 WHERE bookingId = ? AND userId = ?";
        String updateSeatsQuery = "UPDATE EVENTSI1436 SET capacity = capacity + ? WHERE eventId = ?";
        try (PreparedStatement cancelStmt = connection.prepareStatement(cancelQuery);
             PreparedStatement updateSeatsStmt = connection.prepareStatement(updateSeatsQuery)) {

            cancelStmt.setInt(1, bookingId);
            cancelStmt.setInt(2, userId);

            if (cancelStmt.executeUpdate() > 0) {
                updateSeatsStmt.setInt(1, seatsBooked);
                updateSeatsStmt.setInt(2, eventId);
                return updateSeatsStmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean createFeedback(Feedback feedback, String username) {
            String query = "INSERT INTO FEEDBACKSI1436(eventId, userId, rating, comments, username) VALUES (?, ?, ?, ?,?);";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, feedback.getEventId());
                preparedStatement.setInt(2, feedback.getUserId());
                preparedStatement.setInt(3, feedback.getRating());
                preparedStatement.setString(4, feedback.getComments());
                preparedStatement.setString(5,username);
                return preparedStatement.executeUpdate() > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
    }

    @Override
    public boolean userVerifyEventId(int eventId) {
        String query = "SELECT COUNT(*) FROM EVENTSI1436 WHERE eventId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next() && resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean isUsersBookedEvent(int eventId, int userId) {
        String query = "SELECT COUNT(*) FROM BOOKINGSI1436 WHERE eventId = ? AND userId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            preparedStatement.setInt(2, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next() && resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean pay(int bookingId, int eventId, String username, String paymentMethod, long amountPaid) {
        String query = "INSERT INTO PAYMENTSI1436(bookingId, eventId, username, paymentMethod, amountPaid, datetime) VALUES(?,?,?,?,?, CURRENT_TIMESTAMP);";
        // Removed single quotes around CURRENT_TIMESTAMP

        String updateBookings = "UPDATE BOOKINGSI1436 SET bookingStatus = 'BOOKED' WHERE bookingId = ?;";
        // Removed 'TABLE' keyword, added '?' for security

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, bookingId);
            preparedStatement.setInt(2, eventId);
            preparedStatement.setString(3, username);
            preparedStatement.setString(4, paymentMethod);
            preparedStatement.setLong(5, amountPaid);

            PreparedStatement updateBookingStmt = connection.prepareStatement(updateBookings);
            updateBookingStmt.setInt(1, bookingId); // Using parameterized query

            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                generateQR(bookingId,eventId,username,paymentMethod,amountPaid);
                return updateBookingStmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


    @Override
    public List<BookedEvents> pendingPayments(int userId){
        List<BookedEvents> pendingPaymentsList = new ArrayList<>();
        String query = "SELECT E.eventName, E.description, E.eventDate, E.eventTime, E.status, "
                + "B.bookingId, B.eventId, B.seatsBooked, B.bookingStatus, B.amount "
                + "FROM EVENTSI1436 E "
                + "JOIN BOOKINGSI1436 B ON E.eventId = B.eventId "
                + "WHERE B.userId = ? AND B.bookingStatus = 'PAYMENT PENDING';";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {

                // Iterate and print results
                while (resultSet.next()) {
                    pendingPaymentsList.add(new BookedEvents(resultSet.getInt("bookingId"),
                            resultSet.getInt("eventId"),
                            resultSet.getString("eventName"),
                            resultSet.getString("description"),
                            resultSet.getDate("eventDate"),
                            resultSet.getTime("eventTime"),
                            resultSet.getInt("seatsBooked"),
                            resultSet.getString("bookingStatus"),
                            resultSet.getLong("amount")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pendingPaymentsList;
    }

    @Override
    public long getBookingAmount(int eventId, int seatsBooked) {
        long amount = 0;
        String query = "SELECT PRICE FROM EVENTSI1436 WHERE eventId = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1,eventId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                amount = (resultSet.getLong(1)) * seatsBooked;
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return amount;
    }

    @Override
    public Date getDateOfEvent(int bookingId, int eventId, int userId) {
        String query = "SELECT E.eventDate FROM EVENTSI1436 E " +
                "JOIN BOOKINGSI1436 B ON B.eventId = E.eventId " +
                "WHERE B.userId = ? AND B.bookingId = ? AND B.eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, bookingId);
            preparedStatement.setInt(3, eventId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getDate("eventDate");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String getIsAttended(int bookingId) {
        String query = "SELECT isAttended FROM BOOKINGSI1436 WHERE bookingId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, bookingId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getString("isAttended");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean canSubmitFeedback(int bookingId, int eventId, int userId) {
        // Validate input parameters
        if (bookingId <= 0 || eventId <= 0 || userId <= 0) {
            throw new IllegalArgumentException("Invalid input parameters");
        }

        java.util.Date eventDate = getDateOfEvent(bookingId, eventId, userId);

        if (eventDate == null) {
            throw new IllegalStateException("Event date not found for the provided booking, event, and user");
        }

        java.util.Date currentDate = new java.util.Date();
        if (eventDate.after(currentDate)) {
            return false;
        }

        return currentDate.after(eventDate);
    }

    @Override
    public boolean updateIsAttended(int bookingId, int userId) {
        String query = "UPDATE BOOKINGSI1436 SET isATTENDED = 'ATTENDED' WHERE bookingId = ? AND userId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, bookingId);
            preparedStatement.setInt(2, userId);
            int rowsUpdated = preparedStatement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
