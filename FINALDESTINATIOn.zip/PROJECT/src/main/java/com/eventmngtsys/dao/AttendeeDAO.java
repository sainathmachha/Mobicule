package com.eventmngtsys.dao;

import com.eventmngtsys.entity.BookedEvents;
import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Feedback;

import java.sql.Date;
import java.util.List;

public interface AttendeeDAO {

    String generateQR(int bookingId, int eventId, String username, String paymentMethod, long amountPaid);

    boolean createBooking(Booking booking);

    boolean updateSeatsLeft(int eventId, int seatsBooked);

    boolean userExists(int userId);

    List<BookedEvents> viewBookedEvents(int userId);

    boolean cancelBookedEvent(int bookingId, int userId);

    boolean createFeedback(Feedback feedback, String username);

    boolean userVerifyEventId(int eventId);

    boolean isUsersBookedEvent(int eventId, int userId);

    boolean pay(int bookingId, int eventId, String username, String paymentMethod, long amountPaid);

    List<BookedEvents> pendingPayments(int userId);

    long getBookingAmount(int eventId, int seatsBooked);

    Date getDateOfEvent(int bookingId, int eventId, int userId);

    String getIsAttended(int bookingId);

    boolean canSubmitFeedback(int bookingId, int eventId, int userId);

    boolean updateIsAttended(int bookingId, int userId);
}
