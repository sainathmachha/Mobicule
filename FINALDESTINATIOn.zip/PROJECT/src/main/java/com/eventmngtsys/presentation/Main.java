package com.eventmngtsys.presentation;

import com.eventmngtsys.HashingPassword;
import com.eventmngtsys.JDBCConnection.TestConnection;
import com.eventmngtsys.dao.impl.AttendeeDAOImpl;
import com.eventmngtsys.entity.*;
import com.eventmngtsys.service.AdminService;
import com.eventmngtsys.service.AttendeeService;
import com.eventmngtsys.service.OrganiserService;
import com.eventmngtsys.service.impl.AdminServiceImpl;
import com.eventmngtsys.service.impl.AttendeeServiceImpl;
import com.eventmngtsys.service.impl.OrganiserServiceImpl;
import com.eventmngtsys.validators.InputValidator;
import com.sun.xml.internal.ws.addressing.WsaActionUtil;

import java.io.File;
import java.nio.file.Paths;
import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

import static com.eventmngtsys.validators.InputValidator.getPaymentDetails;

public class Main {

    public static Connection connection = TestConnection.test();
    public static Scanner sc = new Scanner(System.in);
    private static int choice;
    private static String eventName;
    private static String description;
    private static int organiserId;
    private static Date eventDate;
    private static Time eventTime;
    private static String venue;
    private static int capacity;
    private static String status;
    private static long price;
    private static int bookingId;
    private static int eventId;
    private static int seatsBooked;
    private static int userId;
    private static int id;
    private static String role;
    private static String userRole;
    private static String retries;
    private static AdminService adminService = new AdminServiceImpl();
    private static OrganiserService organiserService = new OrganiserServiceImpl();
    private static AttendeeService attendeeService = new AttendeeServiceImpl();
    private static String username;
    private static long amount;

    public static void main(String[] args) {
        boolean validUser = false;

        System.out.print("ARE YOU A ADMIN? (y/n) \n--> ");
        String areYouAdmin = sc.nextLine().trim().toLowerCase();

        if (areYouAdmin.equalsIgnoreCase("y")) {
            // Admin login directly
            Login login = InputValidator.getValidUsersLoginDetails(sc);
            if (adminService.validateUserCredentials(login.getUsername(), HashingPassword.hashPassword(login.getPassword()))) {
                userRole = adminService.getUserRole(login.getUsername());
                if(userRole.equals("ADMIN")){
                    id = adminService.getUserIdInfo(login.getUsername());
                    username = login.getUsername();
                    validUser = true;
                }else{
                    System.out.println("YOU ARE NOT A ADMIN");
                    return;
                }
            } else {
                System.out.println("INVALID CREDENTIALS");
            }
        } else {
            // Non-admin users - show login/signup/exit menu
            System.out.println("-------------");
            System.out.println("| 1. LOGIN   |");
            System.out.println("|____________|");
            System.out.println("-------------");
            System.out.println("| 2. SIGNUP  |");
            System.out.println("|____________|");
            System.out.println("-------------");
            System.out.println("| 3. EXIT    |");
            System.out.println("|____________|");
            System.out.print("\n--> ");
            try {
                int select = sc.nextInt();
                sc.nextLine(); // Consume newline

                switch (select) {
                    case 1:
                        int retryCount = 0;
                        do {
                            System.out.println("------------------------");
                            System.out.println("| LOGIN TO YOU ACCOUNT |");
                            System.out.println("|______________________|");
                            System.out.println();
                            Login login = InputValidator.getValidUsersLoginDetails(sc);
                            if (adminService.validateUserCredentials(login.getUsername(), HashingPassword.hashPassword(login.getPassword()))) {
                                validUser = true;
                                userRole = adminService.getUserRole(login.getUsername());
                                id = adminService.getUserIdInfo(login.getUsername());
                                username = login.getUsername();
                                break;
                            } else {
                                System.out.println("DO YOU WANT TO RETRY? Y/N");
                                retries = sc.nextLine().trim().toLowerCase();
                                if (retries.equalsIgnoreCase("y")) {
                                    retryCount++;
                                    System.out.println("RETRIES LEFT: " + (3 - retryCount));
                                }
                            }
                        } while (retries.equalsIgnoreCase("y") && retryCount < 3);
                        break;

                    case 2:
                        System.out.println("---------------------");
                        System.out.println("| CREATE AN ACCOUNT |");
                        System.out.println("|___________________|");
                        System.out.println();
                        User user = InputValidator.getUserDetails(sc, "USER");
                        validUser = signUp(user); // Ensure signUp method exists
                        if (validUser) {
                            userRole = adminService.getUserRole(user.getName());
                            id = adminService.getUserIdInfo(user.getName());
                            username = user.getName();
                        }
                        break;

                    case 3:
                        System.out.println("Exiting...");
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Invalid selection. Please choose 1, 2, or 3.");
                }
            } catch (InputMismatchException e) {
                System.out.println("INPUT MISMATCH: " + e.getMessage());
                sc.nextLine(); // Clear buffer to prevent infinite loop
            }
        }

        // After login/signup, proceed to user-specific logic if validUser is true
        if (validUser) {
            System.out.println("____________________________");
            System.out.printf("| WELCOME %-17s |%n", username);
            System.out.println("|___________________________|");
            System.out.println();

            try {
                boolean running = true;
                while (running) {
                    switch (userRole.toUpperCase()) {
                        case "ADMIN":
                            handleAdmin(id);
                            break;
                        case "ORGANISER":
                            handleOrganiser(id, userRole);
                            break;
                        case "USER":
                            handleUser(id);
                            break;
                        case "UNKNOWN":
                            System.out.println("Role not recognized. Exiting.");
                            running = false;
                            break;
                        default:
                            System.out.println("Invalid role. Please enter again.");
                            running = false;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


private static void handleUser(int id) {
        System.out.println("____________________________");
        System.out.println("|     ATTENDEE ACTIONS      |");
        System.out.println("|___________________________|");
        System.out.println("| 1. Book Event             |");
        System.out.println("| 2. Booking History        |");
        System.out.println("| 3. Cancel Booking         |");
        System.out.println("| 4. Provide Feedback       |");
        System.out.println("| 5. Event Details          |");
        System.out.println("| 6. Pending Payments       |");
        System.out.println("| 7. Pay for Bookings       |");
        System.out.println("| 8. Check-In For Event     |");
        System.out.println("|___________________________|");
        System.out.print("-->");
        int choice = 0;
        try {
            choice = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }

        try{
            switch (choice) {
                case 1:
                    try {
                        System.out.println("______________________");
                        System.out.println("| LIST OF ALL EVENTS |");
                        System.out.println("|____________________|");
                        System.out.println();
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        attendeeService.viewEventDetails();
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println();

                        OrganiserService organiserService = new OrganiserServiceImpl();
                        while (true) {
                            // Validating Event Id
                            eventId = InputValidator.getValidEventId(sc);
                            if (organiserService.userVerifyEventId(eventId)) break;
                            else System.out.println("Event ID does not exist. Please enter a valid EVENT ID!");
                        }

                        userId = id;
                        while(true) {
                            seatsBooked = InputValidator.getValidSeats(sc, eventId);
                            if (organiserService.checkSeatCapacity(eventId, seatsBooked)) break;
                            else System.out.println("CAPACITY EXCEEDED!");
                        }

                        amount = attendeeService.getPaymentAmount(eventId,seatsBooked);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if(attendeeService.bookEvent(new Booking(eventId,seatsBooked,username,userId, amount))){
                        System.out.println("____________________________");
                        System.out.println("| Event Booked Successfully |");
                        System.out.println("|___________________________|");
                    }else{
                        System.out.println("____________________________");
                        System.out.println("| ! Failed To Book Event    |");
                        System.out.println("|___________________________|");
                    }
                    break;
                case 2:
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-12s | %-12s | %-35s | %-50s | %-15s | %-15s | %-16s | %-20s | %-12s |%n",
                            "BOOKING ID", "EVENT ID", "EVENT NAME", "DESCRIPTION", "DATE", "TIME", "SEATS BOOKED", "STATUS", "PRICE");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    attendeeService.viewBookedEvents(id);
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println();
                    break;
                case 3:
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-12s | %-12s | %-35s | %-50s | %-15s | %-15s | %-16s | %-20s | %-12s |%n",
                            "BOOKING ID", "EVENT ID", "EVENT NAME", "DESCRIPTION", "DATE", "TIME", "SEATS BOOKED", "STATUS", "PRICE");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    attendeeService.viewBookedEvents(id);
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println();

                    bookingId = InputValidator.getValidBookingId(sc);
                    if(attendeeService.cancelBooking(bookingId, id)){
                        System.out.println("____________________");
                        System.out.println("| BOOKING CANCELLED |");
                        System.out.println("|___________________|");
                    }else{
                        System.out.println("______________________");
                        System.out.println("| ! Failed To CANCEL  |");
                        System.out.println("|_____________________|");
                    }
                    break;
                case 4:
                    Feedback feedback = InputValidator.getValidFeedbackDetails(sc, id);
                    if (attendeeService.userVerifyEventId(feedback.getEventId()) &&
                            (attendeeService.isUsersBookedEvent(feedback.getEventId(),feedback.getUserId()))){
                        System.out.print("ENTER BOOKING ID: \n-->");
                        bookingId = sc.nextInt();
                        sc.nextLine();
                        if(attendeeService.canSubmitFeedback(bookingId,feedback.getEventId(),id)) {
                            if (attendeeService.provideFeedback(feedback, username)) {
                                System.out.println("__________________________________");
                                System.out.println("| Feedback Submitted Successfully |");
                                System.out.println("|_________________________________|");
                            } else {
                                System.out.println("_______________________________");
                                System.out.println("| ! Failed To Submit Feedback  |");
                                System.out.println("|______________________________|");
                            }
                        }else{
                            System.out.println("__________________________");
                            System.out.println("| CANNOT SUBMIT FEEDBACK |");
                            System.out.println("|________________________|");
                        }
                    }else{
                        System.out.println("INVALID EVENT ID!");
                    }
                    break;
                case 5:
                    System.out.println("______________________");
                    System.out.println("| LIST OF ALL EVENTS |");
                    System.out.println("|____________________|");
                    System.out.println();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    attendeeService.viewEventDetails();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println();
                    break;
                case 6:
                    System.out.println("____________________________");
                    System.out.println("| LIST OF PENDING PAYMENTS |");
                    System.out.println("|__________________________|");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-12s | %-12s | %-35s | %-50s | %-15s | %-15s | %-16s | %-20s | %-12s |%n",
                            "BOOKING ID", "EVENT ID", "EVENT NAME", "DESCRIPTION", "DATE", "TIME", "SEATS BOOKED", "STATUS", "AMOUNT");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    attendeeService.listPaymentsPending(id);
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println();
                    break;
                case 7:
                    System.out.println("____________________________");
                    System.out.println("| LIST OF PENDING PAYMENTS |");
                    System.out.println("|__________________________|");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-12s | %-12s | %-35s | %-50s | %-15s | %-15s | %-16s | %-20s | %-12s |%n",
                            "BOOKING ID", "EVENT ID", "EVENT NAME", "DESCRIPTION", "DATE", "TIME", "SEATS BOOKED", "STATUS", "AMOUNT");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    attendeeService.listPaymentsPending(id);
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println();
                    System.out.println("Want to complete payment? (y/n)");
                    String isPaying = sc.nextLine().trim().toLowerCase();
                    if(isPaying.equalsIgnoreCase("y")){
                        Payment payment = getPaymentDetails(sc,username);
                        if(attendeeService.payForBookings(payment.getBookingId(),
                                payment.getEventId(),
                                payment.getUsername(),
                                payment.getPaymentMethod(),
                                payment.getAmountPaid()))
                        {
                            System.out.println("______________________");
                            System.out.println("| PAYMENT SUCCESSFUL |");
                            System.out.println("|____________________|");
                        }else{
                            System.out.println("__________________");
                            System.out.println("| PAYMENT FAILED |");
                            System.out.println("|________________|");
                        }
                    }
                    break;
                case 8:
                    System.out.println("ENTER YOUR BOOKING ID:");
                    bookingId = sc.nextInt();
                    sc.nextLine();
                    System.out.println("SHOW YOUR QR...");
                    System.out.println("Scanning....");
                    if(attendeeService.isAttended(bookingId, id))
                    {
                        System.out.println("YOU MAY ENTER.");
                    }else{
                        System.out.println("FAILED TO SCAN QR!");
                    }
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void handleOrganiser(int id, String userRole){
        OrganiserService organiserService = new OrganiserServiceImpl();
        System.out.println("________________________________");
        System.out.println("|        ORGANISER ACTIONS     |");
        System.out.println("|______________________________|");
        System.out.println("| 1. Add Event                 |");
        System.out.println("| 2. List My Events            |");
        System.out.println("| 3. View Event Details        |");
        System.out.println("| 4. Update Event              |");
        System.out.println("| 5. Delete Event              |");
        System.out.println("| 6. View Bookings for Event   |");
        System.out.println("| 7. View Feedback for Events  |");
        System.out.println("|______________________________|");
        System.out.print("-->");

        choice = 0;
        try {
            choice = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }

        try {
            switch (choice) {
                case 1:
                    Event event;
                    event = InputValidator.getEventDetails(sc, id);
                    System.out.println("_________________");
                    System.out.println("| ADD NEW EVENT |");
                    System.out.println("|_______________|");
                    System.out.println();
                    if(organiserService.addEvent(event)){
                        System.out.println("____________________________");
                        System.out.println("| Event Added Successfully  |");
                        System.out.println("|___________________________|");
                    }else{
                        System.out.println("____________________________");
                        System.out.println("| ! Failed To Add Event     |");
                        System.out.println("|___________________________|");
                    }
                    break;
                case 2:
                    System.out.println("_________________________");
                    System.out.println("| LIST OF ALL MY EVENTS |");
                    System.out.println("|_______________________|");
                    System.out.println();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    organiserService.listMyEvents(id);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("_____________________");
                    System.out.println("| LIST OF ALL EVENTS |");
                    System.out.println("|____________________|");
                    System.out.println();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    organiserService.viewEventDetails();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;
                case 4:
                    while(true){
                        event = InputValidator.getEventDetails(sc, id);
                        if(organiserService.isOrganisersEvent(id,event.getEventId())){
                           break;
                        }
                        System.out.println("YOU ARE NOT THE ORGANISER FOR THE EVENT!\n-->");
                    }
                    /*
                    Update Event Details
                     */
                    if(organiserService.updateEvent(event)){
                        System.out.println("______________________________");
                        System.out.println("| Event UPDATED Successfully  |");
                        System.out.println("|_____________________________|");
                    }else{
                        System.out.println("__________________________");
                        System.out.println("| FAILED To UPDATE Event  |");
                        System.out.println("|_________________________|");
                    }
                    break;
                case 5:
                    System.out.println("_________________________");
                    System.out.println("| LIST OF ALL MY EVENTS |");
                    System.out.println("|_______________________|");
                    System.out.println();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    organiserService.listMyEvents(id);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println();
                    while(true){
                        eventId = InputValidator.getValidEventId(sc);
                        if(organiserService.isOrganisersEvent(id,eventId)){
                            break;
                        }
                        System.out.println("INVALID EVENT ID!\n-->");
                    }

                    if(organiserService.deleteEvent(eventId)){
                        System.out.println("_____________________________");
                        System.out.println("| Event Deleted Successfully |");
                        System.out.println("|____________________________|");
                    }else{
                        System.out.println("____________________________");
                        System.out.println("| ! Failed To Delete Event  |");
                        System.out.println("|___________________________|");
                    }
                    break;
                case 6:
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-12s | %-12s | %-35s | %-50s | %-15s | %-15s | %-16s | %-20s | %-12s |%n",
                            "BOOKING ID", "EVENT ID", "EVENT NAME", "DESCRIPTION", "DATE", "TIME", "SEATS BOOKED", "STATUS", "PRICE");
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    organiserService.viewBookingsForEvent(id);
                    System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;
                case 7:
                    System.out.println("----------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-10s | %-7s | %-30s |%n", "EVENTID", "USERID", "RATING", "COMMENTS");
                    System.out.println("----------------------------------------------------------------------");
                    organiserService.viewFeedBackForEvents(id);
                    System.out.println("----------------------------------------------------------------------");
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void handleAdmin(int id){
        AdminService adminService = new AdminServiceImpl();
        System.out.println();
        System.out.println("____________________________");
        System.out.println("|        ADMIN ACTIONS     |");
        System.out.println("|__________________________|");
        System.out.println("| 1. Add User              |");
        System.out.println("| 2. View All Users        |");
        System.out.println("| 3. Delete User           |");
        System.out.println("| 4. Manage Roles          |");
        System.out.println("| 5. View All Events       |");
        System.out.println("|__________________________|");
        System.out.print("-->");

        choice = 0;
        try {
            choice = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }

        try{
            switch (choice) {
                case 1:
                    User user;
                    while(true) {
                        user = InputValidator.getUserDetails(sc, "");
                        if(!adminService.checkIfUsernameAlreadyExist(user.getName()) && !adminService.checkIfEmailAlreadyExist(user.getEmail())){
                            break;
                        }
                        System.out.println("USER ALREADY EXISTS!");
                    }
                    System.out.println("_______________");
                    System.out.println("| ADD NEW USER |");
                    System.out.println("|______________|");
                    System.out.println();
                    if(adminService.addUser(user)){
                        System.out.println("____________________________");
                        System.out.println("| User Added Successfully   |");
                        System.out.println("|___________________________|");
                    }else{
                        System.out.println("____________________________");
                        System.out.println("| ! Failed To Add User      |");
                        System.out.println("|___________________________|");
                    }
                    break;
                case 2:
                    System.out.println(" ___________________");
                    System.out.println("| LIST OF ALL USERS |");
                    System.out.println("|___________________|");
                    System.out.println();
                    System.out.println("______________________________________________________________________________");
                    System.out.printf("| %-8s | %-17s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL", "ROLE");
                    System.out.println("------------------------------------------------------------------------------");
                    adminService.viewAllUsers();
                    System.out.println("------------------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("____________________");
                    System.out.println("| LIST OF ALL USERS |");
                    System.out.println("|___________________|");
                    System.out.println();
                    System.out.println("______________________________________________________________________________");
                    System.out.printf("| %-8s | %-17s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL", "ROLE");
                    System.out.println("------------------------------------------------------------------------------");
                    adminService.viewAllUsers();
                    System.out.println("------------------------------------------------------------------------------");
                    /*
                    Get User ID to Delete User
                     */
                    while(true){
                        userId = InputValidator.getValidUserId(sc);
                        if(userId == id){
                            System.out.println("THEY CAN'T DELETE THEMESELVES!");
                        }else{
                            break;
                        }
                    }

                    if(adminService.checkIfUserExistsToDelete(userId)) {
                        if (adminService.deleteUser(userId)) {
                            System.out.println("____________________________");
                            System.out.println("| User Deleted Successfully |");
                            System.out.println("|___________________________|");
                        } else {
                            System.out.println("____________________________");
                            System.out.println("| ! Failed To Delete User   |");
                            System.out.println("|___________________________|");
                        }
                    }else{
                        System.out.println("USER Doesn't Exist!");
                    }
                    break;
                case 4:
                    System.out.println("____________________");
                    System.out.println("| LIST OF ALL USERS |");
                    System.out.println("|___________________|");
                    System.out.println();
                    System.out.println("______________________________________________________________________________");
                    System.out.printf("| %-8s | %-17s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL", "ROLE");
                    System.out.println("------------------------------------------------------------------------------");
                    adminService.viewAllUsers();
                    System.out.println("------------------------------------------------------------------------------");
                    /*
                    Getting userId and role to update
                     */
                    userId = InputValidator.getValidUserId(sc);
                    String role = InputValidator.getValidRole(sc);
                    if(userId != id) {
                        if (adminService.manageRoles(new User(role, userId))) {
                            System.out.println("_____________________________");
                            System.out.println("| Role Updated Successfully |");
                            System.out.println("|___________________________|");
                        } else {
                            System.out.println("_____________________________");
                            System.out.println("| ! Failed To Update Role   |");
                            System.out.println("|___________________________|");
                        }
                    }else{
                        System.out.println("ADMIN ROLE CAN'T BE CHANGED!");
                    }

                    break;
                case 5:
                    System.out.println("______________________");
                    System.out.println("| LIST OF ALL EVENTS |");
                    System.out.println("|____________________|");
                    System.out.println();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("| %-10s | %-20s | %-40s | %-15s | %-12s | %-12s | %-40s | %-10s | %-20s | %-10s |%n","EVENTID", "EVENTNAME", "DESCRIPTION", "ORGANISERID", "DATE", "TIME", "VENUE", "CAPACITY", "STATUS", "PRICE");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    adminService.viewAllEvents();
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static boolean signUp(User user){
        AdminService adminService = new AdminServiceImpl();
        while(true) {
            if(!adminService.checkIfUsernameAlreadyExist(user.getName()) && !adminService.checkIfEmailAlreadyExist(user.getEmail())){
                break;
            }
            System.out.println("USER ALREADY EXISTS!");
        }
        if(adminService.addUser(user)){
            System.out.println("____________________________");
            System.out.println("| User Added Successfully   |");
            System.out.println("|___________________________|");
            return true;
        }else{
            System.out.println("____________________________");
            System.out.println("| ! Failed To Add User      |");
            System.out.println("|___________________________|");
            return false;
        }
    }
}
