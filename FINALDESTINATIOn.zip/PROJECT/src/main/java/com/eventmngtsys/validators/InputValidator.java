package com.eventmngtsys.validators;

import com.eventmngtsys.entity.*;
import com.eventmngtsys.service.impl.AdminServiceImpl;

import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;

public class InputValidator {


    // Validate integer input
    public static int getIntInput(Scanner sc) {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }
    }

    // Validate event ID
    public static int getValidEventId(Scanner sc) {
        while (true) {
            System.out.print("Enter EVENT ID: \n-->");
            String input = sc.nextLine().trim();
            if (input.matches("^[0-9]+$")) {
                return Integer.parseInt(input);
            }
            System.out.println("ENTER A VALID EVENT ID: \n-->");
        }
    }

    // Validate user ID
    public static int getValidUserId(Scanner sc) {
        while (true) {
            System.out.print("Enter USER ID: \n-->");
            String input = sc.nextLine().trim();
            if (input.matches("^[0-9]+$")) {
                return Integer.parseInt(input);
            }
            System.out.println("! Invalid User ID type");
        }
    }

    public static int getValidBookingId(Scanner sc) {
        while (true) {
            System.out.print("Enter BOOKING ID: \n-->");
            String input = sc.nextLine().trim();
            if (input.matches("^[0-9]+$")) {
                return Integer.parseInt(input);
            }
            System.out.println("! Invalid Booking ID type");
        }
    }

    // Validate number of seats
    public static int getValidSeats(Scanner sc, int eventId) {
        while (true) {
            System.out.print("Enter SEATS YOU WANT TO BOOK: \n-->");
            String input = sc.nextLine().trim();
            if (input.matches("^[0-9]+$")) {
                int seats = Integer.parseInt(input);
                return seats;
            }
            System.out.println("ENTER A VALID NUMBER OF SEATS: \n-->");
        }
    }

    // Validate rating (1-5)
    public static int getValidRating(Scanner sc) {
        while (true) {
            System.out.print("Enter RATING (1-5): \n-->");
            String input = sc.nextLine().trim();
            if (input.matches("^[1-5]$")) {
                return Integer.parseInt(input);
            }
            System.out.println("---------------------");
            System.out.println("|  !INVALID RATING  |");
            System.out.println("---------------------");
        }
    }




    // Validate event details
    public static Event getEventDetails(Scanner sc, int orgId) {
        String eventName, description, venue, status;
        int organiserId, capacity;
        long price;
        Date eventDate;
        Time eventTime;

        // Validating Event Name
        while (true) {
            System.out.print("Enter Event Name: \n-->");
            eventName = sc.nextLine().trim();
            if (eventName.matches("^[A-Za-z '_-]+$")) {
                break;
            } else {
                System.out.println("---------------------------");
                System.out.println("|   !INVALID EVENT NAME   |");
                System.out.println("---------------------------");
            }
        }

        // Description
        System.out.print("Enter Description: \n-->");
        description = sc.nextLine().trim();

        organiserId = orgId;

        // Validating Date
        while (true) {
            System.out.print("Enter Date (YYYY-MM-DD): \n-->");
            String dateInput = sc.nextLine().trim();
            try {
                eventDate = Date.valueOf(dateInput);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("---------------------");
                System.out.println("|   !INVALID DATE   |");
                System.out.println("---------------------");
            }
        }

        // Validating Time
        while (true) {
            System.out.print("Enter Time (HH:MM:SS): \n-->");
            String timeInput = sc.nextLine().trim();
            try {
                eventTime = Time.valueOf(timeInput);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("---------------------");
                System.out.println("|   !INVALID TIME   |");
                System.out.println("---------------------");
            }
        }

        // Validating Venue
        while (true) {
            System.out.print("Enter Venue: \n-->");
            venue = sc.nextLine().trim();
            if (venue.matches("^[A-Za-z0-9\\-,.:'{}()\\s]+$")) {
                break;
            } else {
                System.out.println("---------------------------------");
                System.out.println("|   !INVALID EVENT VENUE NAME   |");
                System.out.println("---------------------------------");
            }
        }

        // Validating Capacity
        while (true) {
            System.out.print("Enter Capacity: \n-->");
            String capacityInput = sc.nextLine().trim();
            if (capacityInput.matches("^[0-9]+$")) {
                capacity = Integer.parseInt(capacityInput);
                break;
            } else {
                System.out.println("-------------------------");
                System.out.println("|   !INVALID CAPACITY   |");
                System.out.println("-------------------------");
            }
        }

        // Validating Status
        while (true) {
            System.out.print("Enter Status (SCHEDULED, RESCHEDULED, ON HOLD, IN PROGRESS, COMPLETED, DELAYED, CANCELLED): \n-->");
            status = sc.nextLine().trim().toUpperCase();
            if (status.matches("^(SCHEDULED|RESCHEDULED|ON HOLD|IN PROGRESS|COMPLETED|DELAYED|CANCELLED)$")) {
                break;
            } else {
                System.out.println("! INVALID STATUS");
            }
        }

        // Validating Price
        while (true) {
            System.out.print("Enter Price: \n-->");
            String input = sc.nextLine().trim();
            if (input.matches("^[0-9]+$")) {
                price = Long.parseLong(input);
                break;
            } else {
                System.out.println("-------------------------");
                System.out.println("|   !INVALID PRICE   |");
                System.out.println("-------------------------");
            }
        }

        return new Event(organiserId, capacity, price, eventName, description, venue, status, eventDate, eventTime);
    }

    // Validate user details
    public static User getUserDetails(Scanner sc, String role) {
        String fullName, email, password, mobileNumber;

        // Validating Full Name
        while (true) {
            System.out.print("Enter username: \n-->");
            fullName = sc.nextLine().trim();
            if (fullName.matches("^[A-Za-z0-9.-_@#$&%* ']{4,30}+$")) {
                break;
            }
            System.out.println("! USERNAME IS NOT VALID");
        }

        // Validating Email
        while (true) {
            System.out.print("Enter Email: \n-->");
            email = sc.nextLine().trim();
            if (email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$") && (!checkIfUserExists(email))){
                break;
            }
            System.out.println("PLEASE ENTER A VALID EMAIL!");
        }

        // Validating Password
        while (true) {
            System.out.print("Enter Password: \n-->");
            password = sc.nextLine().trim();
            if (password.matches("^[A-Za-z0-9.@#$%&]+$")) {
                break;
            }
            System.out.println("! PASSWORD ISN'T VALID");
        }

        // Validating Mobile Number
        while (true) {
            System.out.print("Enter Mobile Number(10-12 Digits Number): \n-->");
            mobileNumber = sc.nextLine().trim();
            if (mobileNumber.matches("^[0-9]{10,12}$")) {
                break;
            }
            System.out.println("! MOBILE NUMBER ISN'T VALID");
        }

        if(role.isEmpty()) {
            // Validating Role
            while (true) {
                System.out.print("Enter Role (USER, ORGANISER): \n-->");
                role = sc.nextLine().trim().toUpperCase();
                if (role.equals("USER") || role.equals("ORGANISER")) {
                    break;
                }
                System.out.println("! INVALID ROLE");
            }
        }

        return new User(fullName, email, password, role,mobileNumber);
    }

    public static Feedback getValidFeedbackDetails(Scanner sc, int userId){
        int rating=0,eventId = 0;
        String comments="";
        try{
            // Validating Event Id
            while (true) {
                System.out.print("Enter EVENT ID: \n-->");
                String eventIdInput = sc.nextLine().trim();
                if (eventIdInput.matches("^[0-9]+$")) {
                    eventId = Integer.parseInt(eventIdInput);
                    break;
                }
                System.out.println("ENTER A VALID EVENT ID: \n-->");
            }

            System.out.println("----------------------------------------------------------");

            // Rating
            while (true) {
                System.out.print("Enter RATING (1-5): \n-->");
                String ratingInput = sc.nextLine().trim();
                if (ratingInput.matches("^[1-5]$")) {
                    rating = Integer.parseInt(ratingInput);
                    break;
                } else {
                    System.out.println("---------------------");
                    System.out.println("|  !INVALID RATING  |");
                    System.out.println("|---------------------");
                }
            }

            System.out.println("----------------------------------------------------------");

            // Comments
            while (true) {
                System.out.print("Enter COMMENTS: \n--> ");
                comments = sc.nextLine().trim();

                // Allow letters, numbers, spaces, and common punctuation
                if (comments.matches("^[A-Za-z0-9 .,!?'-]+$")) {
                    break;
                }
                System.out.println("! INVALID COMMENT. Only letters, numbers, spaces, and .,!?'- are allowed.");
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return new Feedback(eventId,userId,rating,comments);
    }

    public static String getValidRole(Scanner sc) {
        String role;
        while (true) {
            System.out.print("Enter Role (USER, ORGANISER, ADMIN): \n-->");
            role = sc.nextLine().trim().toUpperCase();
            if (role.equals("USER") || role.equals("ORGANISER") || role.equals("ADMIN")) {
                break;
            }
            System.out.println("! INVALID ROLE");
        }
        return role;
    }


    public static Login getValidUsersLoginDetails(Scanner sc) {
        String username, password;
        while (true) {
            System.out.print("ENTER YOUR USERNAME: \n-->");
            username = sc.nextLine().trim();

            System.out.print("ENTER YOUR PASSWORD: \n-->");
            password = sc.nextLine().trim();
            if (username.matches("^[A-Za-z0-9.-_@#$&%* ]{4,30}+$") && password.matches("^[A-Za-z0-9.@#$%&]+$")) {
                break;
            }
            System.out.println("! INVALID TYPE");
        }
        return new Login(username,password);
    }

    public static boolean checkIfUserExists(String email){
        return new AdminServiceImpl().checkIfUsernameAlreadyExist(email);
    }


    public static Payment getPaymentDetails(Scanner sc, String username){
        int eventId, bookingId;

        // Validating Event Id
        while (true) {
            System.out.print("Enter BOOKING ID: \n-->");
            String bookingIdInput = sc.nextLine().trim();
            if (bookingIdInput.matches("^[0-9]+$")) {
                bookingId = Integer.parseInt(bookingIdInput);
                break;
            }
            System.out.println("ENTER A VALID BOOKING ID: \n-->");
        }
        System.out.println("----------------------------------------------------------");
        // Validating Event Id
        while (true) {
            System.out.print("Enter EVENT ID: \n-->");
            String eventIdInput = sc.nextLine().trim();
            if (eventIdInput.matches("^[0-9]+$")) {
                eventId = Integer.parseInt(eventIdInput);
                break;
            }
            System.out.println("ENTER A VALID EVENT ID: \n-->");
        }
        System.out.println("----------------------------------------------------------");
        System.out.println();
        int choice;
        String paymentMethod = "";
            System.out.println("CHOOSE A PAYMENT METHOD: ");
            System.out.println("1. UPI.");
            System.out.println("2. CREDIT CARD.");
            System.out.println("3. DEBIT CARD.");
            System.out.print("4. BANK TRANSFER.\n-->");
            choice = sc.nextInt();
            sc.nextLine();
            switch (choice){
                case 1:
                    paymentMethod = "UPI";
                    break;
                case 2:
                    paymentMethod = "CREDIT CARD";
                    break;
                case 3:
                    paymentMethod = "DEBIT CARD";
                    break;
                case 4:
                    paymentMethod = "BANK TRANSFER";
                    break;
                default:
                    System.out.println("INVALID!");
                    break;
            }

        System.out.println("----------------------------------------------------------");

        long amountPaid;
        while (true) {
            System.out.print("Enter AMOUNT: \n-->");
            String amount = sc.nextLine().trim();
            if (amount.matches("^[0-9]+$")) {
                amountPaid = Long.parseLong(amount);
                break;
            }
            System.out.println("ENTER A VALID EVENT ID: \n-->");
        }

        return new Payment(bookingId,eventId,username,paymentMethod,amountPaid);
    }
}
