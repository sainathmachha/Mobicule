package com.eventmngtsys.service.impl;

import com.eventmngtsys.dao.AttendeeDAO;
import com.eventmngtsys.dao.impl.AttendeeDAOImpl;
import com.eventmngtsys.entity.BookedEvents;
import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Feedback;
import com.eventmngtsys.service.AttendeeService;

import static com.eventmngtsys.presentation.Main.connection;

public class AttendeeServiceImpl implements AttendeeService {

    AttendeeDAO attendeeDAO = new AttendeeDAOImpl(connection);

    @Override
    public boolean bookEvent(Booking booking) {
        return attendeeDAO.createBooking(booking);
    }

    @Override
    public void viewBookedEvents(int userId) {
        for (BookedEvents be : attendeeDAO.viewBookedEvents(userId)){
            System.out.println(be);
        }
    }

    @Override
    public boolean cancelBooking(int bookingId, int userId) {
        return attendeeDAO.cancelBookedEvent(bookingId,userId);
    }

    @Override
    public boolean provideFeedback(Feedback feedback, String username) {
        return attendeeDAO.createFeedback(feedback, username);
    }

    @Override
    public void viewEventDetails() {
        new OrganiserServiceImpl().viewEventDetails();
    }

    @Override
    public boolean userVerifyEventId(int eventId) {
        return attendeeDAO.userVerifyEventId(eventId);
    }

    @Override
    public boolean isUsersBookedEvent(int eventId, int userId) {
        return attendeeDAO.isUsersBookedEvent(eventId,userId);
    }

    @Override
    public boolean payForBookings(int bookingId, int eventId, String username, String paymentMethod, long amountPaid) {
        return attendeeDAO.pay(bookingId, eventId, username,paymentMethod,amountPaid);
    }

    @Override
    public void listPaymentsPending(int userId) {
        for(BookedEvents be : attendeeDAO.pendingPayments(userId)){
            System.out.println(be);
        }
    }

    @Override
    public long getPaymentAmount(int eventId, int seatsBooked) {
        return attendeeDAO.getBookingAmount(eventId,seatsBooked);
    }

    @Override
    public boolean canSubmitFeedback(int bookingId, int eventId, int userId) {
        return attendeeDAO.canSubmitFeedback(bookingId,eventId,userId);
    }

    @Override
    public boolean isAttended(int bookingId, int userId) {
        return attendeeDAO.updateIsAttended(bookingId, userId);
    }

}
