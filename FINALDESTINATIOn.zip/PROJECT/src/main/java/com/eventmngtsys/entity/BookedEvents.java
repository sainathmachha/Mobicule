package com.eventmngtsys.entity;

import java.sql.Date;
import java.sql.Time;

    public class BookedEvents {
        private int bookingId;
        private int eventId;
        private String eventName;
        private String description;
        private Date eventDate;
        private Time eventTime;
        private int seatsBooked;
        private String bookingStatus;
        private long amount;

        public long getAmount() {
            return amount;
        }

        public void setAmount(long amount) {
            this.amount = amount;
        }

        // Constructor
        public BookedEvents(int bookingId, int eventId, String eventName, String description,
                           Date eventDate, Time eventTime, int seatsBooked, String bookingStatus, long amount) {
            this.bookingId = bookingId;
            this.eventId = eventId;
            this.eventName = eventName;
            this.description = description;
            this.eventDate = eventDate;
            this.eventTime = eventTime;
            this.seatsBooked = seatsBooked;
            this.bookingStatus = bookingStatus;
            this.amount = amount;
        }

        // Getters and Setters
        public int getBookingId() { return bookingId; }
        public int getEventId() { return eventId; }
        public String getEventName() { return eventName; }
        public String getDescription() { return description; }
        public Date getEventDate() { return eventDate; }
        public Time getEventTime() { return eventTime; }
        public int getSeatsBooked() { return seatsBooked; }
        public String getBookingStatus() { return bookingStatus; }

        @Override
        public String toString() {
            return String.format("| %-12s | %-12s | %-35s | %-50s | %-15s | %-15s | %-16s | %-20s | %-12s |%n",
                    bookingId, eventId, eventName, description, eventDate, eventTime, seatsBooked, bookingStatus, amount);
        }

}
