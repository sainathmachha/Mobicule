package com.eventmngtsys;

public class databaseQueries {
    /*

    CREATE TABLE USERSI1436 (
            userid INT PRIMARY KEY IDENTITY(1,1),
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    mobileNumber VARCHAR(15)
);

    CREATE TABLE EVENTSI1436 (
            eventId INT PRIMARY KEY IDENTITY(1,1),
    eventName VARCHAR(100) NOT NULL,
    description TEXT,
    organiserId INT NOT NULL,
    eventDate DATE NOT NULL,
    eventTime TIME NOT NULL,
    venue VARCHAR(255) NOT NULL,
    capacity INT NOT NULL,
    status VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (organiserId) REFERENCES USERSI1436(userid)
            );

    CREATE TABLE BOOKINGSI1436 (
            bookingId INT PRIMARY KEY IDENTITY(1,1),
    eventId INT NOT NULL,
    userId INT NOT NULL,
    username VARCHAR(100) NOT NULL,
    seatsBooked INT NOT NULL,
    bookingStatus VARCHAR(50) NOT NULL,
    isAttended BIT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (eventId) REFERENCES EVENTSI1436(eventId),
    FOREIGN KEY (userId) REFERENCES USERSI1436(userid)
            );

    CREATE TABLE PAYMENTSI1436 (
            paymentId INT PRIMARY KEY IDENTITY(1,1),
    bookingId INT NOT NULL,
    eventId INT NOT NULL,
    username VARCHAR(100) NOT NULL,
    paymentMethod VARCHAR(50) NOT NULL,
    amountPaid DECIMAL(10, 2) NOT NULL,
    datetime DATETIME NOT NULL,
    FOREIGN KEY (bookingId) REFERENCES BOOKINGSI1436(bookingId),
    FOREIGN KEY (eventId) REFERENCES EVENTSI1436(eventId)
            );

    CREATE TABLE FEEDBACKSI1436 (
            feedbackId INT PRIMARY KEY IDENTITY(1,1),
    eventId INT NOT NULL,
    userId INT NOT NULL,
    username VARCHAR(100) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comments TEXT,
    FOREIGN KEY (eventId) REFERENCES EVENTSI1436(eventId),
    FOREIGN KEY (userId) REFERENCES USERSI1436(userid)
            );



    //------------------------------------
    CREATE TABLE USERSI1436 (
            userid INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    mobileNumber VARCHAR(15)
);

    CREATE TABLE EVENTSI1436 (
            eventId INT AUTO_INCREMENT PRIMARY KEY,
            eventName VARCHAR(100) NOT NULL,
    description TEXT,
    organiserId INT NOT NULL,
    eventDate DATE NOT NULL,
    eventTime TIME NOT NULL,
    venue VARCHAR(255) NOT NULL,
    capacity INT NOT NULL,
    status VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (organiserId) REFERENCES USERSI1436(userid)
            );

    CREATE TABLE BOOKINGSI1436 (
            bookingId INT AUTO_INCREMENT PRIMARY KEY,
            eventId INT NOT NULL,
            userId INT NOT NULL,
            username VARCHAR(100) NOT NULL,
    seatsBooked INT NOT NULL,
    bookingStatus VARCHAR(50) NOT NULL,
    isAttended BOOLEAN NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (eventId) REFERENCES EVENTSI1436(eventId),
    FOREIGN KEY (userId) REFERENCES USERSI1436(userid)
            );

    CREATE TABLE PAYMENTSI1436 (
            paymentId INT AUTO_INCREMENT PRIMARY KEY,
            bookingId INT NOT NULL,
            eventId INT NOT NULL,
            username VARCHAR(100) NOT NULL,
    paymentMethod VARCHAR(50) NOT NULL,
    amountPaid DECIMAL(10, 2) NOT NULL,
    datetime DATETIME NOT NULL,
    FOREIGN KEY (bookingId) REFERENCES BOOKINGSI1436(bookingId),
    FOREIGN KEY (eventId) REFERENCES EVENTSI1436(eventId)
            );

    CREATE TABLE FEEDBACKSI1436 (
            feedbackId INT AUTO_INCREMENT PRIMARY KEY,
            eventId INT NOT NULL,
            userId INT NOT NULL,
            username VARCHAR(100) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comments TEXT,
    FOREIGN KEY (eventId) REFERENCES EVENTSI1436(eventId),
    FOREIGN KEY (userId) REFERENCES USERSI1436(userid)
            );

    */

}
