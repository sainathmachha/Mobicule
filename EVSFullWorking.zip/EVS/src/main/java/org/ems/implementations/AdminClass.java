package org.ems.implementations;

import org.ems.interfaces.Admin;
import org.ems.interfaces.Organiser;

import java.sql.*;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Scanner;

public class AdminClass implements Admin {
    String query = "";
    Connection connection;
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet resultSet;
    Scanner sc = new Scanner(System.in);

    // User table: userId, name, email, password, role
    String name, email, password, role;
    int userId;
    // Event table: eventId, eventName, description, organizerId, date_time, venue, capacity, status
    // Booking table: bookingId, eventId, userId, seatsBooked, bookingStatus

    private String dbUsername;
    private String dbPassword;
    private String dbRole;
    private String username;

    @Override
    public void addUser(Connection connection) {
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ ADD USER +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        query = "INSERT INTO USERI1436(NAME, EMAIL, PASSWORD, ROLE, PASSWORD_HASH) VALUES (?, ?, ?, ?, ?);";
        try {
            preparedStatement = connection.prepareStatement(query);

            // Validating Username
            while (true) {
                System.out.print("Enter username: ");
                username = sc.nextLine().trim();
                if (username.matches("^[A-Za-z0-9._@#$&-]{6,15}$")) {
                    break;
                }
                System.out.println("! USERNAME MUST BE BETWEEN 6 - 15 LETTERS");
            }
            preparedStatement.setString(1, username);
            System.out.println();

            // Validating Email
            while (true) {
                System.out.print("Enter Email: \n-->");
                email = sc.nextLine().trim();
                if (email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$")) {
                    break;
                }
                System.out.println("PLEASE ENTER A VALID EMAIL!");
            }
            preparedStatement.setString(2, email);
            System.out.println();

            // Validating Password
            while (true) {
                System.out.print("Enter Password: \n-->");
                password = sc.nextLine().trim();
                if (password.matches("^[A-Za-z0-9.@#$%&]+$")) {
                    break;
                }
                System.out.println("! PASSWORD ISN'T VALID");
            }
            preparedStatement.setString(3, password);
            System.out.println();

            // Validating Role
            while (true) {
                System.out.print("Enter Role (USER, ORGANISER, ADMIN): \n-->");
                role = sc.nextLine().trim().toUpperCase();
                if (role.equals("USER") || role.equals("ORGANISER") || role.equals("ADMIN")) {
                    break;
                }
                System.out.println("! INVALID ROLE");
            }
            preparedStatement.setString(4, role);

            // Adding Encoded Password into the Database
            Encoder encoder = Base64.getEncoder();
            String encoded = encoder.encodeToString(password.getBytes());
            preparedStatement.setString(5, encoded);

            // Result Set
            int i = preparedStatement.executeUpdate();
            if (i >= 1) {
                System.out.println("____________________________");
                System.out.println("| User Added Successfully   |");
                System.out.println("|___________________________|");
                System.out.println();
                System.out.printf(" %-20s %-25s %-30s %-10s ", "USERNAME", "EMAIL", "PASSWORD", "ROLE");
                System.out.println();
                System.out.printf(" %-20s %-25s %-30s %-10s ", username, email, encoded, role);
                System.out.println();
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Add User      |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewAllUsers(Connection connection) {
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ USER DETAILS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        query = "SELECT USERID, NAME, EMAIL, PASSWORD_HASH, ROLE FROM USERI1436;";
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);

            System.out.println("_______________________________________________________________________________________________________________");
            System.out.printf("| %-8s | %-17s | %-30s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL", "PASSWORD", "ROLE");
            System.out.println("---------------------------------------------------------------------------------------------------------------");

            while (resultSet.next()) {
                System.out.printf("| %-8d | %-17s | %-30s | %-30s | %-10s |%n",
                        resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getString(4),
                        resultSet.getString(5));
            }
            System.out.println("_______________________________________________________________________________________________________________");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteUser(Connection connection) {
        int userId;
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        viewAllUsers(connection);

        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ DELETE USER +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String deleteBookingsQuery = "DELETE FROM BOOKINGSI1436 WHERE userId = ?";
        String deleteUserQuery = "DELETE FROM USERI1436 WHERE userId = ?";

        try {
            preparedStatement = connection.prepareStatement(deleteBookingsQuery);

            while (true) {
                System.out.print("Enter USER ID: \n-->");
                userId = sc.nextInt();
                sc.nextLine();
                if (String.valueOf(userId).matches("^[0-9]+$")) {
                    break;
                }
                System.out.println("! USERID ISN'T VALID");
            }
            preparedStatement.setInt(1, userId);

            // Delete related bookings
            int bookingsDeleted = preparedStatement.executeUpdate();
            if (bookingsDeleted >= 1) {
                System.out.println();
                System.out.println("____________________________________________");
                System.out.println("|  Related bookings deleted successfully.   |");
                System.out.println("|___________________________________________|");
                System.out.println();
            }

            // Delete user
            preparedStatement = connection.prepareStatement(deleteUserQuery);
            preparedStatement.setInt(1, userId);
            int userDeleted = preparedStatement.executeUpdate();
            if (userDeleted >= 1) {
                System.out.println("____________________________");
                System.out.println("| User Deleted Successfully |");
                System.out.println("|___________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Delete User   |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void manageRoles(Connection connection) {
        viewAllUsers(connection);
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ UPDATE ROLES ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        query = "UPDATE USERI1436 SET ROLE = ? WHERE NAME = ?;";
        try {
            preparedStatement = connection.prepareStatement(query);

            while (true) {
                System.out.print("Enter ROLE You Want To Assign (ADMIN, ORGANISER, USER): ");
                role = sc.nextLine().trim().toUpperCase();
                if (role.equals("ADMIN") || role.equals("USER") || role.equals("ORGANISER")) {
                    break;
                }
                System.out.println("! INVALID ROLE");
            }
            preparedStatement.setString(1, role);
            System.out.println();

            // Username
            System.out.print("Enter USERNAME: \n-->");
            username = sc.nextLine().trim();
            preparedStatement.setString(2, username);
            System.out.println();

            int success = preparedStatement.executeUpdate();
            if (success >= 1) {
                System.out.println("____________________________");
                System.out.println("| Role Updated Successfully |");
                System.out.println("|___________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Update Role   |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewAllEvents(Connection connection, int uid) {
        Organiser organiser = new OrganiserClass();
        organiser.viewEventDetails(connection);
    }

    @Override
    public void createNotifications(Connection connection){
        OrganiserClass organiserClass = new OrganiserClass();
        organiserClass.createNotification(connection);
    }

}
