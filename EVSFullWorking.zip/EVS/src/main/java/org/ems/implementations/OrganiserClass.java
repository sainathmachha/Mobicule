package org.ems.implementations;

import org.ems.interfaces.Organiser;

import java.sql.*;
import java.util.Scanner;

public class OrganiserClass implements Organiser {
    String query = "";
    Connection connection;
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet resultSet;
    Scanner sc = new Scanner(System.in);
    private String eventName;
    private String description;
    private int organizerId;
    private Date eventDate;
    private Time eventTime;
    private String eventVenue;
    private int capacity;
    private String status;
    private int eventId;

    public int getOrgId(Connection connection, int eventId) {
        int orgId = 0;
        String query = "SELECT organiserId FROM EVENTSI1436 WHERE eventId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, organizerId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while(resultSet.next()){
                    orgId = resultSet.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return orgId;
    }

    public void getOrgList(Connection connection) {
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++ LIST OF ORGANISERS +++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        query = "SELECT userId, name FROM USERI1436 WHERE role = 'ORGANISER'";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                System.out.println("USER ID: " + resultSet.getInt(1) + "\n" + "NAME: " + resultSet.getString(2) + "\n");
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean checkIfAnOrgOrNot(Connection connection, int organizerId) {
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE role = 'ORGANISER' AND userId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, organizerId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return false;
    }


    @Override
    public void addEvent(Connection connection, int userId) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        AdminClass admin = new AdminClass();

        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++ ADD EVENT ++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "INSERT INTO EVENTSI1436(eventName, description, organiserId, eventDate, eventTime, venue, capacity, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Validating Event Name
            String eventName;
            while (true) {
                System.out.print("Enter Event Name: \n-->");
                eventName = sc.nextLine().trim();
                if (eventName.matches("^[A-Za-z\\s]+$")) {
                    break;
                } else {
                    System.out.println("! Invalid Event Name");
                }
            }
            preparedStatement.setString(1, eventName);
            System.out.println();

            // Description
            System.out.print("Enter Description: \n-->");
            String description = sc.nextLine().trim();
            preparedStatement.setString(2, description);
            System.out.println();

            getOrgList(connection);

            // Validating Organiser ID
            int organiserId = userId; // Assuming userId is the organiser ID
            preparedStatement.setInt(3, organiserId);
            System.out.println();

            // Validating Date
            Date eventDate;
            while (true) {
                System.out.print("Enter Date (YYYY-MM-DD): \n-->");
                String dateInput = sc.nextLine().trim();
                try {
                    eventDate = Date.valueOf(dateInput);
                    break;
                } catch (IllegalArgumentException e) {
                    System.out.println("! INVALID DATE");
                }
            }
            preparedStatement.setDate(4, eventDate);
            System.out.println();

            // Validating Time
            Time eventTime;
            while (true) {
                System.out.print("Enter Time (HH:MM:SS): \n-->");
                String timeInput = sc.nextLine().trim();
                try {
                    eventTime = Time.valueOf(timeInput);
                    break;
                } catch (IllegalArgumentException e) {
                    System.out.println("! INVALID TIME");
                }
            }
            preparedStatement.setTime(5, eventTime);
            System.out.println();

            // Validating Venue
            String venue;
            while (true) {
                System.out.print("Enter Venue: \n-->");
                venue = sc.nextLine().trim();
                if (venue.matches("^[A-Za-z0-9\\-,.:'{}()\\s]+$")) {
                    break;
                } else {
                    System.out.println("! Invalid Venue Name");
                }
            }
            preparedStatement.setString(6, venue);
            System.out.println();

            // Validating Capacity
            int capacity;
            while (true) {
                System.out.print("Enter Capacity: \n-->");
                String capacityInput = sc.nextLine().trim();
                if (capacityInput.matches("^[0-9]+$")) {
                    capacity = Integer.parseInt(capacityInput);
                    break;
                } else {
                    System.out.println("! INVALID CAPACITY");
                }
            }
            preparedStatement.setInt(7, capacity);
            System.out.println();

            // Validating Status
            String status;
            while (true) {
                System.out.print("Enter Status (SCHEDULED, RESCHEDULED, ON HOLD, IN PROGRESS, COMPLETED, DELAYED, CANCELLED): \n-->");
                status = sc.nextLine().trim().toUpperCase();
                if (status.matches("^(SCHEDULED|RESCHEDULED|ON HOLD|IN PROGRESS|COMPLETED|DELAYED|CANCELLED)$")) {
                    break;
                } else {
                    System.out.println("! INVALID STATUS");
                }
            }
            preparedStatement.setString(8, status);
            System.out.println();

            int i = preparedStatement.executeUpdate();
            if (i >= 1) {
                System.out.println("____________________________");
                System.out.println("| Event Added Successfully  |");
                System.out.println("|___________________________|");
                System.out.println();

                createNotification(connection,organiserId,"💗 NEW EVENT ADDED 💗");

            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Add Event     |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void listMyEvents(Connection connection, int userId) {
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ LIST OF MY EVENTS ++++++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        query = "SELECT eventId, eventName, description, capacity, status FROM EVENTSI1436 WHERE organiserId = ? ;";

        try {
            preparedStatement = connection.prepareStatement(query);
            int orgId = userId;
            if (!checkIfAnOrgOrNot(connection, orgId)) {
                System.out.println("! USER IS NOT AN ORGANISER");
                return;
            }
            preparedStatement.setInt(1, orgId);
            resultSet = preparedStatement.executeQuery();
            System.out.println();
            // Print the header
            System.out.printf("%-10s %-20s %-40s %-10s %-15s%n",
                    "EVENTID",
                    "EVENTNAME",
                    "DESCRIPTION",
                    "CAPACITY",
                    "STATUS");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.println();
            // Iterate through the result set and print the data
            while (resultSet.next()) {
                System.out.printf("%-10s %-20s %-40s %-10s %-15s%n",
                        resultSet.getInt(1), // eventId
                        resultSet.getString(2), // eventName
                        resultSet.getString(3), // description
                        resultSet.getInt(4), // capacity
                        resultSet.getString(5)); // status
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewEventDetails(Connection connection) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ VIEW EVENT DETAILS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "SELECT eventId, eventName, description, organiserId, eventdate, eventTime, venue, capacity, status FROM EVENTSI1436;";

        try {
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            // Print the header
            System.out.printf("%-10s %-20s %-40s %-15s %-12s %-12s %-20s %-10s %-10s%n",
                    "EVENTID",
                    "EVENTNAME",
                    "DESCRIPTION",
                    "ORGANISERID",
                    "DATE",
                    "TIME",
                    "VENUE",
                    "CAPACITY",
                    "STATUS");
            System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            // Iterate through the result set and print the data
            while (resultSet.next()) {
                System.out.printf("%-10d %-20s %-40s %-15d %-12s %-12s %-20s %-10d %-10s%n",
                        resultSet.getInt(1), // eventId
                        resultSet.getString(2), // eventName
                        resultSet.getString(3), // description
                        resultSet.getInt(4), // organizerId
                        resultSet.getDate(5), // eventDate
                        resultSet.getTime(6), // eventTime
                        resultSet.getString(7), // venue
                        resultSet.getInt(8), // capacity
                        resultSet.getString(9)); // status
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewFeedbackForEvents(Connection connection, int organiserId) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++ VIEW EVENT FEEDBACK +++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "SELECT f.eventId, f.userId, f.rating, f.comments FROM FEEDBACKS f " +
                "JOIN EVENTSI1436 e ON f.eventId = e.eventId " +
                "WHERE e.organiserId = ?;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, organiserId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                System.out.printf("%-10s %-10s %-7s %-50s%n", "EVENTID", "USERID", "RATING", "COMMENTS");
                System.out.println("----------------------------------------------------------------------");

                while (resultSet.next()) {
                    System.out.printf("%-10d %-10d %-7d %-50s%n",
                            resultSet.getInt("eventId"),
                            resultSet.getInt("userId"),
                            resultSet.getInt("rating"),
                            resultSet.getString("comments"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void createNotification(Connection connection, int organiserId, String message) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ CREATE NOTIFICATION ++++++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "INSERT INTO NOTIFICATIONS(userId, message, eventDate) VALUES (?, ?, ?);";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            // Validating User Id
            preparedStatement.setInt(1, organiserId);

            // Validating Message
            preparedStatement.setString(2, message);

            // Validating Event Date
            preparedStatement.setDate(3, eventDate);

            int success = preparedStatement.executeUpdate();
            if (success >= 1) {
                System.out.println("______________________________________");
                System.out.println("| Notification Created Successfully |");
                System.out.println("|____________________________________|");
            } else {
                System.out.println("__________________________________");
                System.out.println("| ! Failed To Create Notification |");
                System.out.println("|_________________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void createNotification(Connection connection) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ CREATE NOTIFICATION ++++++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "INSERT INTO NOTIFICATIONS(userId, message) VALUES (?, ?);";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            // Validating User Id
            int userId;
            while (true) {
                System.out.print("Enter USER ID: \n-->");
                String userIdInput = sc.nextLine().trim();
                if (userIdInput.matches("^[0-9]+$")) {
                    userId = Integer.parseInt(userIdInput);
                    break;
                } else {
                    System.out.println("! Invalid User ID");
                }
            }
            preparedStatement.setInt(1, userId);

            // Validating Message
            System.out.println("ENTER MESSAGE : ");
            String message = sc.nextLine().trim();
            preparedStatement.setString(2, message);

            int success = preparedStatement.executeUpdate();
            if (success >= 1) {
                System.out.println("______________________________________");
                System.out.println("| Notification Created Successfully |");
                System.out.println("|____________________________________|");
            } else {
                System.out.println("__________________________________");
                System.out.println("| ! Failed To Create Notification |");
                System.out.println("|_________________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateEvent(Connection connection, int userId) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ UPDATE EVENT ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        try {
            // Query to get current values of the event
            String selectQuery = "SELECT eventName, description, organiserId, eventDate, eventTime, venue, capacity, status FROM EVENTSI1436 WHERE eventId = ?";
            PreparedStatement selectStatement = connection.prepareStatement(selectQuery);

            int orgId = userId;

            System.out.print("Enter Event ID to update: ");
            int eventId = Integer.parseInt(scanner.nextLine());
            selectStatement.setInt(1, eventId);

            ResultSet rs = selectStatement.executeQuery();
            if (rs.next()) {
                String currentEventName = rs.getString("eventName");
                String currentDescription = rs.getString("description");
                int currentOrganizerId = rs.getInt("organiserId");
                Date currentDate = rs.getDate("eventDate");
                Time currentTime = rs.getTime("eventTime");
                String currentVenue = rs.getString("venue");
                int currentCapacity = rs.getInt("capacity");
                String currentStatus = rs.getString("status");

                // Get new values or keep existing
                System.out.print("Enter new Event Name (current: " + currentEventName + "): ");
                String newEventName = scanner.nextLine();
                if (newEventName.isEmpty()) newEventName = currentEventName;

                System.out.print("Enter new Description (current: " + currentDescription + "): ");
                String newDescription = scanner.nextLine();
                if (newDescription.isEmpty()) newDescription = currentDescription;

                System.out.print("Enter new Organizer ID (current: " + currentOrganizerId + "): ");
                String newOrganizerIdInput = scanner.nextLine();
                int newOrganizerId = newOrganizerIdInput.isEmpty() ? currentOrganizerId : Integer.parseInt(newOrganizerIdInput);

                System.out.print("Enter new Date (YYYY-MM-DD) (current: " + currentDate + "): ");
                String newDateInput = scanner.nextLine();
                Date newDate = newDateInput.isEmpty() ? currentDate : Date.valueOf(newDateInput);

                System.out.print("Enter new Time (HH:MM:SS) (current: " + currentTime + "): ");
                String newTimeInput = scanner.nextLine();
                Time newTime = newTimeInput.isEmpty() ? currentTime : Time.valueOf(newTimeInput);

                System.out.print("Enter new Venue (current: " + currentVenue + "): ");
                String newVenue = scanner.nextLine();
                if (newVenue.isEmpty()) newVenue = currentVenue;

                System.out.print("Enter new Capacity (current: " + currentCapacity + "): ");
                String newCapacityInput = scanner.nextLine();
                int newCapacity = newCapacityInput.isEmpty() ? currentCapacity : Integer.parseInt(newCapacityInput);

                System.out.print("Enter new Status (current: " + currentStatus + "): ");
                String newStatus = scanner.nextLine();
                if (newStatus.isEmpty()) newStatus = currentStatus;

                // Update the event
                String updateQuery = "UPDATE EVENTSI1436 SET eventName = ?, description = ?, organiserId = ?, eventDate = ?, eventTime = ?, venue = ?, capacity = ?, status = ? WHERE eventId = ? and organiserId = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);

                updateStatement.setString(1, newEventName);
                updateStatement.setString(2, newDescription);
                updateStatement.setInt(3, newOrganizerId);
                updateStatement.setDate(4, newDate);
                updateStatement.setTime(5, newTime);
                updateStatement.setString(6, newVenue);
                updateStatement.setInt(7, newCapacity);
                updateStatement.setString(8, newStatus);
                updateStatement.setInt(9, eventId);
                updateStatement.setInt(10, orgId);

                int rowsAffected = updateStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("______________________________");
                    System.out.println("| Event UPDATED Successfully  |");
                    System.out.println("|_____________________________|");
                    System.out.println();
                } else {
                    System.out.println("________________________________________");
                    System.out.println("| No event found with the specified ID  |");
                    System.out.println("|_______________________________________|");
                    System.out.println();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("An error occurred while updating the event.");
        }
    }

    @Override
    public void deleteEvent(Connection connection, int userId) {
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ DELETE EVENT ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        listMyEvents(connection, userId);

        String deleteBookingsQuery = "DELETE FROM BOOKINGSI1436 WHERE eventId = ?";
        String deleteEventQuery = "DELETE FROM EVENTSI1436 WHERE eventId = ? AND organiserId = ?;";

        try (PreparedStatement deleteBookingsStmt = connection.prepareStatement(deleteBookingsQuery);
             PreparedStatement deleteEventStmt = connection.prepareStatement(deleteEventQuery)) {

            int eventId;
            while (true) {
                System.out.print("Enter EVENT ID: \n-->");
                String eventIdInput = sc.nextLine().trim();
                if (eventIdInput.matches("^[0-9]+$")) {
                    eventId = Integer.parseInt(eventIdInput);
                    break;
                } else {
                    System.out.println("! Invalid Event ID");
                }
            }

            deleteBookingsStmt.setInt(1, eventId);
            deleteBookingsStmt.executeUpdate();

            int organizerId = userId;
            deleteEventStmt.setInt(1, eventId);
            deleteEventStmt.setInt(2, organizerId);

            int success = deleteEventStmt.executeUpdate();
            if (success >= 1) {
                System.out.println("_____________________________");
                System.out.println("| Event Deleted Successfully |");
                System.out.println("|____________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Delete Event  |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean orgVerifyEventId(Connection connection, int eventId) {
        String query = "SELECT COUNT(*) FROM EVENTSI1436 WHERE eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return false;
    }

    @Override
    public void viewBookingsForEvent(Connection connection, int uid) {
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ MY EVENTS ++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String firstQuery = "SELECT eventName, description, organiserId, eventDate, eventTime, status FROM EVENTSI1436 WHERE eventId = ? AND organiserId = ?";
        String secondQuery = "SELECT bookingId, eventId, userId, seatsBooked, bookingStatus, seatsLeft FROM BOOKINGSI1436 WHERE bookingStatus = 'BOOKED' AND eventId = ?";

        try (PreparedStatement firstPreparedStatement = connection.prepareStatement(firstQuery);
             PreparedStatement secondPreparedStatement = connection.prepareStatement(secondQuery)) {

            int organiserId = uid;

            int eventId;
            while (true) {
                System.out.print("Enter EVENT ID: \n-->");
                String eventIdInput = sc.nextLine().trim();
                if (eventIdInput.matches("^[0-9]+$")) {
                    eventId = Integer.parseInt(eventIdInput);
                    break;
                } else {
                    System.out.println("! Invalid Event ID");
                }
            }
            firstPreparedStatement.setInt(1, eventId);
            firstPreparedStatement.setInt(2, organiserId);
            ResultSet resultSet = firstPreparedStatement.executeQuery();

            if (resultSet.next()) {
                String eventName = resultSet.getString("eventName");
                String description = resultSet.getString("description");
                String eventDate = resultSet.getString("eventDate");
                String eventTime = resultSet.getString("eventTime");
                String status = resultSet.getString("status");

                secondPreparedStatement.setInt(1, eventId);
                ResultSet secondResultSet = secondPreparedStatement.executeQuery();

                System.out.printf("%-10s %-10s %-10s %-15s %-10s %-20s %-20s %-10s%n", "BOOKINGID", "EVENTID", "USERID", "SEATSBOOKED", "SEATSLEFT", "EVENT NAME", "DESCRIPTION", "ORGANISERID");
                System.out.println("-------------------------------------------------------------------------------------------------------------------------------");

                while (secondResultSet.next()) {
                    int bookingId = secondResultSet.getInt("bookingId");
                    int userId = secondResultSet.getInt("userId");
                    int seatsBooked = secondResultSet.getInt("seatsBooked");
                    int seatsLeft = secondResultSet.getInt("seatsLeft");

                    System.out.printf("%-10d %-10d %-10d %-15d %-10d %-20s %-20s %-10d%n",
                            bookingId,
                            eventId,
                            userId,
                            seatsBooked,
                            seatsLeft,
                            eventName,
                            description,
                            organiserId);
                }
            } else {
                System.out.println("EVENT doesn't exist or you are not the organiser.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
