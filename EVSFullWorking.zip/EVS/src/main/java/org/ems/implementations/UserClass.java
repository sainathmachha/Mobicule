package org.ems.implementations;

import org.ems.interfaces.Organiser;
import org.ems.interfaces.User;

import java.sql.*;
import java.util.Random;
import java.util.Scanner;

public class UserClass implements User {
    String query = "";
    Connection connection;
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet resultSet;
    Scanner sc = new Scanner(System.in);
    private String eventName;
    private String description;
    private int organizerId;
    private Date eventDate;
    private Time eventTime;
    private String eventVenue;
    private int capacity;
    private String status, bookingStatus;
    private int eventId, userId, seatsBooked;
    private String firstQuery;
    private String secondQuery;
    private PreparedStatement secondPreparedStatement;
    private String bookingId;

    @Override
    public void forgotPassword(Connection connection, int uid){
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ FORGOT PASSWORD ++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        String generatedOTP = generateOTP();
        System.out.println(generatedOTP);
        System.out.println();
        System.out.println("ENTER OTP YOU RECEIVED : ");
        String enteredOTP = sc.nextLine().trim();
        if(generatedOTP.equals(enteredOTP)) {
            String query = "SELECT PASSWORD FROM USERI1436 WHERE USERID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, uid);
                ResultSet resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    System.out.println();
                    System.out.print("____________________________________________\n");
                    System.out.printf("| %-18s %-15s       |%n","YOUR PASSWORD IS : ",resultSet.getString(1));
                    System.out.print("|___________________________________________|");
                    System.out.println();
                }
            } catch (SQLException e) {
                e.getMessage();
            }
        }
        else{
            System.out.println("! INVALID OTP");
        }
    }

    public String generateOTP(){
        String otp = "";

        for(int i=0;i<6;i++){
            int val = new Random().nextInt(9);
            otp = otp.concat(String.valueOf(val));
        }
        return otp;
    }

    @Override
    public boolean userVerifyEventId(Connection connection, int eventId) {
        if (connection == null) {
            System.out.println("Connection is null");
            return false;
        }

        String query = "SELECT COUNT(*) FROM EVENTSI1436 WHERE eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }

    @Override
    public boolean verifyUserExists(Connection connection, int userId) {
        if (connection == null) {
            System.out.println("Connection is null");
            return false;
        }

        String query = "SELECT COUNT(*) FROM USERI1436 WHERE userId = ? AND role = 'USER'";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }

    @Override
    public int getCapacity(Connection connection, int eventId, int capacity) {
        if (connection == null) {
            System.out.println("Connection is null");
            return 0;
        }

        String query = "SELECT capacity FROM EVENTSI1436 WHERE eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return 0;
    }

    @Override
    public boolean checkSeatCapacity(Connection connection, int eventId, int capacity) {
        if (connection == null) {
            System.out.println("Connection is null");
            return false;
        }

        String query = "SELECT capacity FROM EVENTSI1436 WHERE eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && capacity <= resultSet.getInt(1)) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }

    @Override
    public void bookEvent(Connection connection, int uid) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++ BOOK EVENT +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        Organiser organizer = new OrganiserClass();
        organizer.viewEventDetails(connection);

        System.out.println();

        String query = "INSERT INTO BOOKINGSI1436(eventId, userId, seatsBooked, bookingStatus, seatsLeft) VALUES (?, ?, ?, ?, ?);";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            // Validating Event Id
            int eventId;
            while (true) {
                System.out.print("Enter EVENT ID: \n-->");
                String eventIdInput = sc.nextLine().trim();
                if (eventIdInput.matches("^[0-9]+$")) {
                    eventId = Integer.parseInt(eventIdInput);
                    if (userVerifyEventId(connection, eventId)) {
                        break;
                    }
                    System.out.println("ENTER A VALID EVENT ID: \n-->");
                } else {
                    System.out.println("! Invalid Event ID type");
                }
            }
            preparedStatement.setInt(1, eventId);

            // Validating User Id
            int userId = uid;
            preparedStatement.setInt(2, userId);

            // Seats Booked
            int seatsBooked;
            while (true) {
                System.out.print("Enter SEATS YOU WANT TO BOOK: \n-->");
                String seatsBookedInput = sc.nextLine().trim();
                if (seatsBookedInput.matches("^[0-9]+$")) {
                    seatsBooked = Integer.parseInt(seatsBookedInput);
                    if (checkSeatCapacity(connection, eventId, seatsBooked)) {
                        break;
                    }
                    System.out.println("CAPACITY EXCEEDED: \n-->");
                } else {
                    System.out.println("! Invalid Type");
                }
            }
            preparedStatement.setInt(3, seatsBooked);

            preparedStatement.setString(4, "BOOKED");
            System.out.println();

            preparedStatement.setInt(5, getCapacity(connection, eventId, seatsBooked) - seatsBooked);

            int i = preparedStatement.executeUpdate();

            if (i >= 1) {
                System.out.println("____________________________");
                System.out.println("| Event BOOKED Successfully |");
                System.out.println("|___________________________|");
                System.out.println();

                updateSeatsLeft(connection, eventId, seatsBooked);
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To BOOK Event    |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateSeatsLeft(Connection connection, int eventId, int seatsBooked) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++ UPDATE SEATS LEFT +++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "UPDATE EVENTSI1436 SET capacity = capacity - ? WHERE eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, seatsBooked);
            preparedStatement.setInt(2, eventId);
            System.out.println();

            int success = preparedStatement.executeUpdate();

            if (success >= 1) {
                System.out.println("_____________________________");
                System.out.println("| SEATS Updated Successfully |");
                System.out.println("|____________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Update SEATS  |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewEvents(Connection connection) {
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ LIST OF EVENTS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "SELECT eventId, eventName, description, status FROM EVENTSI1436;";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            // Print the header
            System.out.printf("%-5s %-20s %-40s %-15s%n",
                    "EVENTID",
                    "EVENTNAME",
                    "DESCRIPTION",
                    "STATUS");

            System.out.println("-----------------------------------------------------------------------------------------------");

            // Iterate through the result set and print the data
            while (resultSet.next()) {
                System.out.printf("%-5s %-20s %-40s %-15s",
                        resultSet.getInt("eventId"),     // eventId
                        resultSet.getString("eventName"),// eventName
                        resultSet.getString("description"), // description
                        resultSet.getString("status"));   // status
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewBookedEvents(Connection connection, int uid) {
        System.out.println();
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ MY BOOKED EVENTS ++++++++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String firstQuery = "SELECT eventName, description, eventDate, eventTime, status FROM EVENTSI1436 WHERE eventId = ?;";
        String secondQuery = "SELECT eventId, seatsBooked, bookingStatus, seatsLeft, bookingId FROM BOOKINGSI1436 WHERE userId = ? AND bookingStatus = 'BOOKED'";

        try (PreparedStatement secondPreparedStatement = connection.prepareStatement(secondQuery)) {
            int userId = uid;
            secondPreparedStatement.setInt(1, userId);
            try (ResultSet secondResultSet = secondPreparedStatement.executeQuery()) {
                while (secondResultSet.next()) {
                    int eventId = secondResultSet.getInt("eventId");
                    int seatsBooked = secondResultSet.getInt("seatsBooked");
                    String bookingStatus = secondResultSet.getString("bookingStatus");
                    int seatsLeft = secondResultSet.getInt("seatsLeft");
                    int bookingId = secondResultSet.getInt("bookingId");

                    try (PreparedStatement firstPreparedStatement = connection.prepareStatement(firstQuery)) {
                        firstPreparedStatement.setInt(1, eventId);
                        System.out.println();

                        try (ResultSet firstResultSet = firstPreparedStatement.executeQuery()) {
                            System.out.printf("%-10s %-7s %-20s %-30s %-12s %-12s %-10s %-6s%n", "BOOKINGID", "EVENTID", "EVENT NAME", "DESCRIPTION", "DATE", "TIME", "SEATS BOOKED", "STATUS");
                            System.out.println("--------------------------------------------------------------------------------------------------------------------");

                            while (firstResultSet.next()) {
                                System.out.printf("%-10s %-7s %-20s %-30s %-12s %-12s %-10s %-6s",
                                        bookingId,
                                        eventId,
                                        firstResultSet.getString("eventName"),
                                        firstResultSet.getString("description"),
                                        firstResultSet.getString("eventDate"),
                                        firstResultSet.getString("eventTime"),
                                        seatsBooked,
                                        bookingStatus
                                );
                                System.out.println();
                            }
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void cancelBooking(Connection connection, int uid) {
        viewBookedEvents(connection, uid);

        System.out.println();
        System.out.println("+++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++ CANCEL BOOKING +++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++");
        System.out.println();

        String cancelBookingQuery = "UPDATE BOOKINGSI1436 SET bookingStatus = 'CANCELLED' WHERE userId = ? AND bookingId = ?";
        String updateSeatsQuery = "UPDATE EVENTSI1436 SET capacity = capacity + ? WHERE eventId = ?";

        try (PreparedStatement cancelBookingStmt = connection.prepareStatement(cancelBookingQuery);
             PreparedStatement updateSeatsStmt = connection.prepareStatement(updateSeatsQuery)) {

            int bookingId;
            int eventId;
            int seatsBooked;

            while (true) {
                System.out.print("Enter BOOKING ID: \n-->");
                String bookingIdInput = sc.nextLine().trim();
                if (bookingIdInput.matches("^[0-9]+$")) {
                    bookingId = Integer.parseInt(bookingIdInput);
                    break;
                } else {
                    System.out.println("! Invalid Booking ID");
                }
            }
            cancelBookingStmt.setInt(1, uid);
            cancelBookingStmt.setInt(2, bookingId);

            // Find the event ID and seats booked for the booking ID
            String findEventAndSeatsQuery = "SELECT eventId, seatsBooked FROM BOOKINGSI1436 WHERE bookingId = ?";
            try (PreparedStatement findEventAndSeatsStmt = connection.prepareStatement(findEventAndSeatsQuery)) {
                findEventAndSeatsStmt.setInt(1, bookingId);
                try (ResultSet rs = findEventAndSeatsStmt.executeQuery()) {
                    if (rs.next()) {
                        eventId = rs.getInt("eventId");
                        seatsBooked = rs.getInt("seatsBooked");
                    } else {
                        System.out.println("______________________");
                        System.out.println("| Booking not found  |");
                        System.out.println("|____________________|");
                        return;
                    }
                }
            }

            int cancelSuccess = cancelBookingStmt.executeUpdate();
            if (cancelSuccess >= 1) {
                updateSeatsStmt.setInt(1, seatsBooked);
                updateSeatsStmt.setInt(2, eventId);

                int updateSuccess = updateSeatsStmt.executeUpdate();
                if (updateSuccess >= 1) {
                    System.out.println("____________________");
                    System.out.println("| BOOKING CANCELLED |");
                    System.out.println("|___________________|");

                    OrganiserClass organiserClass = new OrganiserClass();
                    int orgId = organiserClass.getOrgId(connection, eventId);
                    organiserClass.createNotification(connection,uid,"BOOKING CANCELLED");

                    System.out.println("Seats updated successfully.");
                } else {
                    System.out.println("________________________");
                    System.out.println("| Failed to update seats |");
                    System.out.println("|_______________________|");
                }
            } else {
                System.out.println("______________________");
                System.out.println("| ! Failed To CANCEL  |");
                System.out.println("|_____________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void provideFeedback(Connection connection, int uid) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ PROVIDE FEEDBACK ++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "INSERT INTO FEEDBACKS(eventId, userId, rating, comments) VALUES (?, ?, ?, ?);";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            // Validating Event Id
            int eventId;
            while (true) {
                System.out.print("Enter EVENT ID: \n-->");
                String eventIdInput = sc.nextLine().trim();
                if (eventIdInput.matches("^[0-9]+$")) {
                    eventId = Integer.parseInt(eventIdInput);
                    if (userVerifyEventId(connection, eventId)) {
                        break;
                    }
                    System.out.println("ENTER A VALID EVENT ID: \n-->");
                } else {
                    System.out.println("! Invalid Event ID type");
                }
            }
            preparedStatement.setInt(1, eventId);

            // Validating User Id
            int userId = uid;
            preparedStatement.setInt(2, userId);

            // Rating
            int rating;
            while (true) {
                System.out.print("Enter RATING (1-5): \n-->");
                String ratingInput = sc.nextLine().trim();
                if (ratingInput.matches("^[1-5]$")) {
                    rating = Integer.parseInt(ratingInput);
                    break;
                } else {
                    System.out.println("! Invalid Rating");
                }
            }
            preparedStatement.setInt(3, rating);

            // Comments
            System.out.print("Enter COMMENTS: \n-->");
            String comments = sc.nextLine().trim();
            preparedStatement.setString(4, comments);

            int success = preparedStatement.executeUpdate();
            if (success >= 1) {
                System.out.println("__________________________________");
                System.out.println("| Feedback Submitted Successfully |");
                System.out.println("|_________________________________|");
            } else {
                System.out.println("_______________________________");
                System.out.println("| ! Failed To Submit Feedback  |");
                System.out.println("|______________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewNotifications(Connection connection, int uid) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ VIEW NOTIFICATIONS ++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "SELECT notificationId, message FROM NOTIFICATIONS WHERE userId = ?;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            // Validating User Id
            int userId = uid;
            preparedStatement.setInt(1, userId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                System.out.printf("%-5s %-50s%n", "ID", "MESSAGE");
                System.out.println("--------------------------------------------------------------------------------------");

                while (resultSet.next()) {
                    System.out.printf("%-5s %-50s%n",
                            resultSet.getInt("notificationId"),
                            resultSet.getString("message"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewEventDetails(Connection connection) {
        Organiser organiser = new OrganiserClass();
        organiser.viewEventDetails(connection);
    }

    @Override
    public void checkBookingStatus(Connection connection) {
        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++ CHECK BOOKING STATUS ++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "SELECT bookingStatus FROM BOOKINGSI1436 WHERE bookingId = ?;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            while(true) {
                System.out.print("Enter your BOOKING ID: ");
                bookingId = sc.nextLine();
                if(bookingId.matches("^[0-9]+$$")){
                    break;
                }
                System.out.println("! INVALID TYPE");
            }
            preparedStatement.setInt(1, Integer.parseInt(bookingId));
            System.out.println();

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    System.out.println("BOOKING STATUS IS: " + resultSet.getString("bookingStatus"));
                } else {
                    System.out.println("Booking ID not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Event table = eventId, eventName, description, organizerId, date_time, venue, capacity, status
}
