package org.ems;

public class JavaClass {

    /*
    *
    //Organiser
    addEvent()
        listEvents()
            viewEventDetails()
                updateEvent()
                    deleteEvent()
                        sendNotification()
                            viewBookingsForEvent()
                                viewFeedbackForEvent()
                                    generateEventReport()


    //Attendees
    viewEvents()
        bookEvent()
            viewBookedEvents()
                cancelBooking()
                    provideFeedback()
                        viewNotifications()
                            viewEventDetails()
                                checkBookingStatus()


//User table = userId, name, email, password, role
//Event table = eventId, eventName, description, organizerId, date_time, venue, capacity, status
//Booking table = bookingId, eventId, userId, seatsBooked, bookingStatus

    */
}

/*

//Admin
viewAllUsers()
viewAllEvents()
manageRoles()
deleteUser()
                *
                        *
*/


/*
-- Create the USERI1436 table
CREATE TABLE TRAINING_DB.dbo.USERI1436 (
    userid INT IDENTITY(1,1) PRIMARY KEY, -- Primary key
    name NVARCHAR(30) NOT NULL, -- User's name
    email NVARCHAR(30) NOT NULL UNIQUE, -- Unique email
    password NVARCHAR(30) NOT NULL, -- Password
    password_hash NVARCHAR(255) NULL, -- Password hash (optional)
    [role] VARCHAR(10) DEFAULT 'USER' NOT NULL -- User role with default 'USER'
);

-- Create the EVENTSI1436 table
CREATE TABLE TRAINING_DB.dbo.EVENTSI1436 (
    eventId INT IDENTITY(0,1) PRIMARY KEY, -- Primary key
    eventName VARCHAR(100) NOT NULL, -- Event name
    description VARCHAR(100) NULL, -- Description (optional)
    organizerId INT NOT NULL, -- Foreign key to USERI1436
    [date] DATE NOT NULL, -- Event date
    [time] TIME(0) NOT NULL, -- Event time
    venue VARCHAR(100) NOT NULL, -- Event venue
    capacity INT NOT NULL CHECK (capacity > 0), -- Capacity must be greater than 0
    status VARCHAR(100) DEFAULT 'CLOSED', -- Status with default 'CLOSED'
    CONSTRAINT FK_Organizer FOREIGN KEY (organizerId) REFERENCES TRAINING_DB.dbo.USERI1436(userid) -- Foreign key
);

-- Create the BOOKINGSI1436 table
CREATE TABLE TRAINING_DB.dbo.BOOKINGSI1436 (
    bookingId INT IDENTITY(1,1) PRIMARY KEY, -- Primary key
    eventId INT NOT NULL, -- Foreign key to EVENTSI1436
    userId INT NOT NULL, -- Foreign key to USERI1436
    seatsBooked INT NOT NULL CHECK (seatsBooked > 0), -- Seats must be greater than 0
    bookingStatus VARCHAR(100) DEFAULT 'NOT BOOKED', -- Status with default 'NOT BOOKED'
    CONSTRAINT FK_BookingEvent FOREIGN KEY (eventId) REFERENCES TRAINING_DB.dbo.EVENTSI1436(eventId), -- Foreign key
    CONSTRAINT FK_BookingUser FOREIGN KEY (userId) REFERENCES TRAINING_DB.dbo.USERI1436(userid) -- Foreign key
);


CREATE TABLE FEEDBACKS (
    feedbackId INT AUTO_INCREMENT PRIMARY KEY,
    eventId INT NOT NULL,
    userId INT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5), -- Assuming rating is between 1 and 5
    comments TEXT,
    FOREIGN KEY (eventId) REFERENCES EVENTSI1436(eventId),
    FOREIGN KEY (userId) REFERENCES USERI1436(userId)
);


CREATE TABLE NOTIFICATIONS (
    notificationId INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL,
    message TEXT NOT NULL,
    eventDate DATE,
    FOREIGN KEY (userId) REFERENCES USERI1436(userId)
);

 */
