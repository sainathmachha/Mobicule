package org.ems.interfaces;

import java.sql.Connection;
import java.sql.Date;

public interface Organiser {

    void addEvent(Connection connection, int userId);
    void listMyEvents(Connection connection, int userId);
    void viewEventDetails(Connection connection);
    void createNotification(Connection connection, int organiserId, String message);
    void createNotification(Connection connection);
    void updateEvent(Connection connection, int userId);
    void deleteEvent(Connection connection, int userId);
    void viewBookingsForEvent(Connection connection, int uid);
    void viewFeedbackForEvents(Connection connection, int organiserId);
}
