package org.ems.interfaces;

import java.sql.Connection;

public interface User {

    void updateSeatsLeft(Connection connection, int eventId, int seatsBooked);

    void viewEvents(Connection connection);

    void forgotPassword(Connection connection, int uid);

    boolean userVerifyEventId(Connection connection, int eventId);

    boolean verifyUserExists(Connection connection, int userId);

    int getCapacity(Connection connection, int eventId, int capacity);

    boolean checkSeatCapacity(Connection connection, int eventId, int capacity);

    void bookEvent(Connection connection, int uid);

    void viewBookedEvents(Connection connection, int uid);

    void cancelBooking(Connection connection, int uid);

    void provideFeedback(Connection connection, int uid);

    void viewNotifications(Connection connection, int uid);

    void viewEventDetails(Connection connection);

    void checkBookingStatus(Connection connection);
}
