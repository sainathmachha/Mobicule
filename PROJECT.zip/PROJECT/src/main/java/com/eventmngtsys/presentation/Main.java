package com.eventmngtsys.presentation;

import com.eventmngtsys.JDBCConnection.TestConnection;
import com.eventmngtsys.service.AdminService;
import com.eventmngtsys.service.AttendeeService;
import com.eventmngtsys.service.OrganiserService;
import com.eventmngtsys.service.impl.AdminServiceImpl;
import com.eventmngtsys.service.impl.AttendeeServiceImpl;
import com.eventmngtsys.service.impl.OrganiserServiceImpl;

import java.sql.Connection;
import java.util.Scanner;

public class Main {

    public static Connection connection = TestConnection.test();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AdminService adminService = new AdminServiceImpl();
        AttendeeService attendeeService = new AttendeeServiceImpl();
        OrganiserService organiserService = new OrganiserServiceImpl();

        try {
            while (true) {
                System.out.println("Enter your role (ADMIN, ORGANISER, USER) or type 'exit' to quit:");
                char[] role = scanner.next().toCharArray();
                if (String.valueOf(role).equals("EXIT")) {
                    break;
                }

                switch (String.valueOf(role)) {
                    case "ADMIN":
                        handleAdmin(adminService);
                        break;
                    case "ORGANISER":
                        handleOrganiser(organiserService);
                        break;
                    case "USER":
                        handleUser(attendeeService);
                        break;
                    default:
                        System.out.println("Invalid role. Please enter again.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void handleAdmin(AdminService adminService) {
        System.out.println("ADMIN Actions:");
        System.out.println("1. Add User");
        System.out.println("2. View All Users");
        System.out.println("3. Delete User");
        System.out.println("4. Manage Roles");
        System.out.println("5. View All Events");
        System.out.println("Select an action:");

        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        switch (Integer.valueOf(choice)) {
            case 1:
                adminService.addUser();
                break;
            case 2:
                adminService.viewAllUsers();
                break;
            case 3:
                adminService.deleteUser();
                break;
            case 4:
                adminService.manageRoles();
                break;
            case 5:
                adminService.viewAllEvents();
                break;
            default:
                System.out.println("Invalid choice.");
                break;
        }
    }

    private static void handleOrganiser(OrganiserService organiserService) {
        System.out.println("ORGANISER Actions:");
        System.out.println("1. Add Event");
        System.out.println("2. List My Events");
        System.out.println("3. View Event Details");
        System.out.println("4. Update Event");
        System.out.println("5. Delete Event");
        System.out.println("6. View Bookings for Event");
        System.out.println("7. View Feedback for Events");
        System.out.println("Select an action:");

        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                organiserService.addEvent();
                break;
            case 2:
                organiserService.listMyEvents();
                break;
            case 3:
                organiserService.viewEventDetails();
                break;
            case 4:
                organiserService.updateEvent();
                break;
            case 5:
                organiserService.deleteEvent();
                break;
            case 6:
                organiserService.viewBookingsForEvent();
                break;
            case 7:
                organiserService.viewFeedBackForEvents();
                break;
            default:
                System.out.println("Invalid choice.");
                break;
        }
    }

    private static void handleUser(AttendeeService attendeeService) {
        System.out.println("USER Actions:");
        System.out.println("1. Book Event");
        System.out.println("2. View Booked Events");
        System.out.println("3. Cancel Booking");
        System.out.println("4. Provide Feedback");
        System.out.println("5. View Event Details");
        System.out.println("Select an action:");

        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                attendeeService.bookEvent();
                break;
            case 2:
                attendeeService.viewBookedEvents();
                break;
            case 3:
                attendeeService.cancelBooking();
                break;
            case 4:
                attendeeService.provideFeedback();
                break;
            case 5:
                attendeeService.viewEventDetails();
                break;
            default:
                System.out.println("Invalid choice.");
                break;
        }
    }
}