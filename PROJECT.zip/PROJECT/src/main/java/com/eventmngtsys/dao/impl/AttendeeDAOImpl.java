package com.eventmngtsys.dao.impl;

import com.eventmngtsys.dao.AttendeeDAO;
import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Feedback;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AttendeeDAOImpl implements AttendeeDAO {

    Connection connection;
    private int eventId;
    private int seatsBooked;

    public AttendeeDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void createBooking(Booking booking) {
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++ BOOK EVENT +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        if (!userExists(booking.getUserId())) {
            System.out.println("____________________________");
            System.out.println("| ! User Does Not Exist     |");
            System.out.println("|___________________________|");
            return;
        }

        String query = "INSERT INTO BOOKINGSI1436(eventId, userId, seatsBooked, bookingStatus) VALUES (?, ?, ?, ?);";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, booking.getEventId());
            preparedStatement.setInt(2, booking.getUserId());
            preparedStatement.setInt(3, booking.getSeatsBooked());
            preparedStatement.setString(4, "PAYMENT PENDING");
            int i = preparedStatement.executeUpdate();

            if (i >= 1) {
                System.out.println("____________________________");
                System.out.println("| Event BOOKED Successfully |");
                System.out.println("|___________________________|");
                System.out.println();
                updateSeatsLeft(booking.getEventId(), booking.getSeatsBooked());
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To BOOK Event    |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateSeatsLeft(int eventId, int seatsBooked) {
        if (connection == null) {
            System.out.println("Connection is null.");
            return;
        }

        System.out.println();
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++ UPDATE SEATS LEFT +++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "UPDATE EVENTSI1436 SET capacity = capacity - ? WHERE eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, seatsBooked);
            preparedStatement.setInt(2, eventId);
            System.out.println();

            int success = preparedStatement.executeUpdate();

            if (success >= 1) {
                System.out.println("_____________________________");
                System.out.println("| SEATS Updated Successfully |");
                System.out.println("|____________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Update SEATS  |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean userExists(int userId) {
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE userId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void viewBookedEvents(int userId) {
        System.out.println();
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ MY BOOKED EVENTS ++++++++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String firstQuery = "SELECT eventName, description, eventDate, eventTime, status FROM EVENTSI1436 WHERE eventId = ?;";
        String secondQuery = "SELECT eventId, seatsBooked, bookingStatus, bookingId FROM BOOKINGSI1436 WHERE userId = ?";

        try (PreparedStatement secondPreparedStatement = connection.prepareStatement(secondQuery)) {
            secondPreparedStatement.setInt(1, userId);
            try (ResultSet secondResultSet = secondPreparedStatement.executeQuery()) {
                while (secondResultSet.next()) {
                    int eventId = secondResultSet.getInt("eventId");
                    int seatsBooked = secondResultSet.getInt("seatsBooked");
                    String bookingStatus = secondResultSet.getString("bookingStatus");
                    int bookingId = secondResultSet.getInt("bookingId");

                    try (PreparedStatement firstPreparedStatement = connection.prepareStatement(firstQuery)) {
                        firstPreparedStatement.setInt(1, eventId);
                        System.out.println();

                        try (ResultSet firstResultSet = firstPreparedStatement.executeQuery()) {
                            System.out.printf("%-10s %-7s %-25s %-40s %-12s %-15s %-15s %-8s s%n", "BOOKINGID", "EVENTID", "EVENT NAME", "DESCRIPTION", "DATE", "TIME", "SEATS BOOKED", "STATUS");
                            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

                            while (firstResultSet.next()) {
                                System.out.printf("%-10s %-7s %-25s %-40s %-12s %-15s %-15s %-8s",
                                        bookingId,
                                        eventId,
                                        firstResultSet.getString("eventName"),
                                        firstResultSet.getString("description"),
                                        firstResultSet.getString("eventDate"),
                                        firstResultSet.getString("eventTime"),
                                        seatsBooked,
                                        bookingStatus
                                );
                                System.out.println();
                            }
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void cancelBookedEvent(int bookingId, int userId) {
        String cancelBookingQuery = "UPDATE BOOKINGSI1436 SET bookingStatus = 'CANCELLED', seatsBooked = 0 WHERE userId = ? AND bookingId = ?";
        String updateSeatsQuery = "UPDATE EVENTSI1436 SET capacity = capacity + ? WHERE eventId = ?";

        int eventId = 0;
        int seatsBooked = 0;

        try (PreparedStatement findEventAndSeatsStmt = connection.prepareStatement("SELECT eventId, seatsBooked FROM BOOKINGSI1436 WHERE bookingId = ?")) {
            findEventAndSeatsStmt.setInt(1, bookingId);
            try (ResultSet rs = findEventAndSeatsStmt.executeQuery()) {
                if (rs.next()) {
                    eventId = rs.getInt("eventId");
                    seatsBooked = rs.getInt("seatsBooked");
                } else {
                    System.out.println("______________________");
                    System.out.println("| Booking not found  |");
                    System.out.println("|____________________|");
                    return;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        if (seatsBooked <= 0) {
            System.out.println("______________________");
            System.out.println("| Invalid seatsBooked |");
            System.out.println("|_____________________|");
            return;
        }

        try (PreparedStatement cancelBookingStmt = connection.prepareStatement(cancelBookingQuery);
             PreparedStatement updateSeatsStmt = connection.prepareStatement(updateSeatsQuery)) {

            cancelBookingStmt.setInt(1, userId);
            cancelBookingStmt.setInt(2, bookingId);

            int cancelSuccess = cancelBookingStmt.executeUpdate();
            if (cancelSuccess >= 1) {
                updateSeatsStmt.setInt(1, seatsBooked);
                updateSeatsStmt.setInt(2, eventId);

                int updateSuccess = updateSeatsStmt.executeUpdate();
                if (updateSuccess >= 1) {
                    System.out.println("____________________");
                    System.out.println("| BOOKING CANCELLED |");
                    System.out.println("|___________________|");
                    System.out.println("Seats updated successfully.");
                } else {
                    System.out.println("_________________________");
                    System.out.println("| Failed to update seats |");
                    System.out.println("|________________________|");
                }
            } else {
                System.out.println("______________________");
                System.out.println("| ! Failed To CANCEL  |");
                System.out.println("|_____________________|");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean createFeedback(Feedback feedback) {
        String query = "INSERT INTO FEEDBACKSI1436(eventId, userId, rating, comments) VALUES (?, ?, ?, ?);";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            if(userVerifyEventId(feedback.getEventId())) {
                preparedStatement.setInt(1, feedback.getEventId());
            }else{
                System.out.println("EVENT ID DOESN't Exist");
            }
            preparedStatement.setInt(2, feedback.getUserId());
            preparedStatement.setInt(3, feedback.getRating());
            preparedStatement.setString(4, feedback.getComments());
            int success = preparedStatement.executeUpdate();
            if(success >= 1){
                System.out.println("Feedback Submitted");
                return true;
            }else{
                System.out.println("Failed to submit");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean userVerifyEventId(int eventId) {
        String query = "SELECT COUNT(*) FROM EVENTSI1436 WHERE eventId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) > 0) {
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
