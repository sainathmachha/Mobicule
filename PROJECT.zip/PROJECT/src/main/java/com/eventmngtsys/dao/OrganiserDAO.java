package com.eventmngtsys.dao;

import com.eventmngtsys.entity.Event;
import com.eventmngtsys.dao.AdminDAO;

public interface OrganiserDAO {

    void createEventInDB(Event event);
    void listAllMyEvents(int userId);
    boolean checkIfAnOrgOrNot(int orgId);
    void updateEvent(Event event);
    Event getCurrentValues(int eventId);
    void deleteEventFromDB(int eventId);
    void viewBookingsForMyEvents(int eventId, int orgId);
    void viewFeedBackForEvents(int orgId);
}
