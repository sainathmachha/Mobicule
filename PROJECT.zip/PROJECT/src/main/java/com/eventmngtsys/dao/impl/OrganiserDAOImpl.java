package com.eventmngtsys.dao.impl;

import com.eventmngtsys.controller.OrganiserController;
import com.eventmngtsys.dao.OrganiserDAO;
import com.eventmngtsys.entity.Event;

import java.sql.*;
import java.util.Scanner;

public class OrganiserDAOImpl implements OrganiserDAO {

    Connection connection = null;

    public OrganiserDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void createEventInDB(Event event) {
        System.out.println("+++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++ CREATE EVENT ++++++++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        String query = "INSERT INTO EVENTSI1436(eventName, description, organiserId, eventDate, eventTime, venue, capacity, status, price) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, event.getEventName());
            preparedStatement.setString(2, event.getDescription());
            preparedStatement.setInt(3, event.getOrganiserId());
            preparedStatement.setDate(4, event.getEventDate());
            preparedStatement.setTime(5, event.getEventTime());
            preparedStatement.setString(6, event.getVenue());
            preparedStatement.setInt(7, event.getCapacity());
            preparedStatement.setString(8, event.getStatus());
            preparedStatement.setLong(9, event.getPrice());

            int i = preparedStatement.executeUpdate();
            if (i >= 1) {
                System.out.println("____________________________");
                System.out.println("| Event Added Successfully  |");
                System.out.println("|___________________________|");
                System.out.println();
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Add Event     |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void listAllMyEvents(int orgId) {
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ LIST OF MY EVENTS ++++++++++++");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        String query = "SELECT eventId, eventName, description, capacity, status, price FROM EVENTSI1436 WHERE organiserId = ? ;";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            if (!checkIfAnOrgOrNot(orgId)) {
                System.out.println("---------------------------------");
                System.out.println("|   !USER IS NOT AN ORGANISER   |");
                System.out.println("---------------------------------");
                return;
            }
            preparedStatement.setInt(1, orgId);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println();
            // Print the header
            System.out.printf("%-10s %-20s %-40s %-10s %-15s %-20s%n",
                    "EVENTID",
                    "EVENTNAME",
                    "DESCRIPTION",
                    "CAPACITY",
                    "STATUS",
                    "PRICE");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.println();
            // Iterate through the result set and print the data
            while (resultSet.next()) {
                System.out.printf("%-10s %-20s %-40s %-10s %-15s %-20s%n",
                        resultSet.getInt(1), // eventId
                        resultSet.getString(2), // eventName
                        resultSet.getString(3), // description
                        resultSet.getInt(4), // capacity
                        resultSet.getString(5), // status
                        resultSet.getLong(6));//PRICE
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean checkIfAnOrgOrNot(int orgId) {
        String query = "SELECT COUNT(*) FROM USERI1436 WHERE role = 'ORGANISER' AND userId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, orgId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return false;
    }

    @Override
    public void updateEvent(Event event) {
        int newEventId = event.getEventId(), newOrganiserId = event.getOrganiserId(), newCapacity = event.getCapacity();
        long newPrice = event.getPrice();
        String newEventName = event.getEventName(),newDescription = event.getDescription(),newVenue = event.getVenue(),newStatus = event.getStatus();
        Date newEventDate = event.getEventDate();
        Time newEventTime = event.getEventTime();

        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ UPDATE EVENT ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        Event current = getCurrentValues(event.getEventId());

        if (newEventName.isEmpty()) newEventName = current.getEventName();
        if (newDescription.isEmpty()) newDescription = current.getDescription();
        int newOrganizerId = String.valueOf(newOrganiserId).isEmpty() ? current.getOrganiserId(): newOrganiserId;
        Date newDate = String.valueOf(newEventDate).isEmpty() ? current.getEventDate() : newEventDate;
        Time newTime = String.valueOf(newEventTime).isEmpty() ? current.getEventTime() : newEventTime;
        if (newVenue.isEmpty()) newVenue = current.getVenue();
        int newCapacityInput = String.valueOf(newCapacity).isEmpty() ? current.getCapacity() : newCapacity;
        if (newStatus.isEmpty()) newStatus = current.getStatus();
        if (newPrice == 0) newPrice = current.getPrice();

        try {
            String updateQuery = "UPDATE EVENTSI1436 SET eventName = ?, description = ?, organiserId = ?, eventDate = ?, eventTime = ?, venue = ?, capacity = ?, status = ? price = ? WHERE eventId = ?";
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setString(1, newEventName);
            updateStatement.setString(2, newDescription);
            updateStatement.setInt(3, newOrganizerId);
            updateStatement.setDate(4, newDate);
            updateStatement.setTime(5, newTime);
            updateStatement.setString(6, newVenue);
            updateStatement.setInt(7, newCapacity);
            updateStatement.setString(8, newStatus);
            updateStatement.setLong(9,newPrice);
            updateStatement.setInt(10, event.getEventId());

            int rowsAffected = updateStatement.executeUpdate();
            if (rowsAffected > 0) {
                    System.out.println("______________________________");
                    System.out.println("| Event UPDATED Successfully  |");
                    System.out.println("|_____________________________|");
                    System.out.println();
                } else {
                    System.out.println("________________________________________");
                    System.out.println("| No event found with the specified ID  |");
                    System.out.println("|_______________________________________|");
                    System.out.println();
                }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("-------------------------------------------------");
            System.out.println("|   An error occurred while updating the event.  |");
            System.out.println("-------------------------------------------------");
        }
    }

    @Override
    public Event getCurrentValues(int eventId) {
        String currentEventName = "", currentDescription = "",currentVenue = "", currentStatus = "";
        int currentOrganizerId = 0,currentCapacity = 0;
        Date currentDate = null;
        Time currentTime = null;
        long currentPrice = 0;

        String selectQuery = "SELECT eventName, description, organiserId, eventDate, eventTime, venue, capacity, status, price FROM EVENTSI1436 WHERE eventId = ?";
        try(PreparedStatement selectStatement = connection.prepareStatement(selectQuery);
        ResultSet rs = selectStatement.executeQuery();)
        {
            selectStatement.setInt(1, eventId);
            while (rs.next()) {
                currentEventName = rs.getString("eventName");
                currentDescription = rs.getString("description");
                currentOrganizerId = rs.getInt("organiserId");
                currentDate = rs.getDate("eventDate");
                currentTime = rs.getTime("eventTime");
                currentVenue = rs.getString("venue");
                currentCapacity = rs.getInt("capacity");
                currentStatus = rs.getString("status");
                currentPrice = rs.getLong("price");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return new Event(currentOrganizerId,currentCapacity,currentPrice,currentEventName,currentDescription,currentVenue,currentStatus,currentDate,currentTime);
    }

    @Override
    public void deleteEventFromDB(int eventId){
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ DELETE EVENT ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        String deleteBookingsQuery = "DELETE FROM BOOKINGSI1436 WHERE eventId = ?";
        String deleteEventQuery = "DELETE FROM EVENTSI1436 WHERE eventId = ?";

        try (PreparedStatement deleteBookingsStmt = connection.prepareStatement(deleteBookingsQuery);
             PreparedStatement deleteEventStmt = connection.prepareStatement(deleteEventQuery)) {

            deleteBookingsStmt.setInt(1, eventId);
            deleteBookingsStmt.executeUpdate();

            deleteEventStmt.setInt(1, eventId);

            int success = deleteEventStmt.executeUpdate();
            if (success >= 1) {
                System.out.println("_____________________________");
                System.out.println("| Event Deleted Successfully |");
                System.out.println("|____________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Delete Event  |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewBookingsForMyEvents(int eventId, int orgId) {
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ MY EVENTS ++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String firstQuery = "SELECT eventName, description, organiserId, eventDate, eventTime, status FROM EVENTSI1436 WHERE eventId = ? AND organiserId = ?";
        String secondQuery = "SELECT bookingId, eventId, userId, seatsBooked, bookingStatus, seatsLeft FROM BOOKINGSI1436 WHERE bookingStatus = 'BOOKED' AND eventId = ?";

        try (PreparedStatement firstPreparedStatement = connection.prepareStatement(firstQuery);
             PreparedStatement secondPreparedStatement = connection.prepareStatement(secondQuery)) {

            firstPreparedStatement.setInt(1, eventId);
            firstPreparedStatement.setInt(2, orgId);

            ResultSet resultSet = firstPreparedStatement.executeQuery();

            if (resultSet.next()) {
                String eventName = resultSet.getString("eventName");
                String description = resultSet.getString("description");
                String eventDate = resultSet.getString("eventDate");
                String eventTime = resultSet.getString("eventTime");
                String status = resultSet.getString("status");

                secondPreparedStatement.setInt(1, eventId);
                ResultSet secondResultSet = secondPreparedStatement.executeQuery();

                System.out.printf("%-10s %-10s %-10s %-15s %-10s %-25s %-35s %-10s%n", "BOOKINGID", "EVENTID", "USERID", "SEATSBOOKED", "SEATSLEFT", "EVENT NAME", "DESCRIPTION", "ORGANISERID");
                System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------");

                while (secondResultSet.next()) {
                    int bookingId = secondResultSet.getInt("bookingId");
                    int userId = secondResultSet.getInt("userId");
                    int seatsBooked = secondResultSet.getInt("seatsBooked");
                    int seatsLeft = secondResultSet.getInt("seatsLeft");

                    System.out.printf("%-10d %-10d %-10d %-15d %-10d %-25s %-35s %-10d%n",
                            bookingId,
                            eventId,
                            userId,
                            seatsBooked,
                            seatsLeft,
                            eventName,
                            description,
                            orgId);
                }
            } else {
                System.out.println("-------------------------------------------------------");
                System.out.println("|  EVENT doesn't exist or you are not the organiser.  |");
                System.out.println("-------------------------------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewFeedBackForEvents(int orgId) {
            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("++++++++++ VIEW EVENT FEEDBACK +++++++++++");
            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
            System.out.println();

            String query = "SELECT f.eventId, f.userId, f.rating, f.comments FROM FEEDBACKSI1436 f " + "JOIN EVENTSI1436 e ON f.eventId = e.eventId " + "WHERE e.organiserId = ?;";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, orgId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    System.out.printf("%-10s %-10s %-7s %-50s%n", "EVENTID", "USERID", "RATING", "COMMENTS");
                    System.out.println("----------------------------------------------------------------------");

                    while (resultSet.next()) {
                        System.out.printf("%-10d %-10d %-7d %-50s%n",
                                resultSet.getInt("eventId"),
                                resultSet.getInt("userId"),
                                resultSet.getInt("rating"),
                                resultSet.getString("comments"));
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
    }
}
