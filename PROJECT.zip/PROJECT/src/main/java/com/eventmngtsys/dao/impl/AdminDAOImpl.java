package com.eventmngtsys.dao.impl;

import com.eventmngtsys.dao.AdminDAO;
import com.eventmngtsys.entity.User;

import java.sql.*;
import java.util.Base64;

import static com.eventmngtsys.presentation.Main.connection;

public class AdminDAOImpl implements AdminDAO {
    Connection connection = null;

    public AdminDAOImpl(Connection connection){
        this.connection = connection;
    }

    @Override
    public void addUserInDB(User user) {
        String query = "INSERT INTO USERI1436(NAME, EMAIL, MOBILENUMBER,PASSWORD, ROLE) VALUES (?, ?, ?, ?,?);";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, user.getName());
            preparedStatement.setString(2, user.getEmail());
            preparedStatement.setString(3, user.getMobileNumber());
            preparedStatement.setString(4, user.getPassword());
            preparedStatement.setString(5, user.getRole());

            // Result Set
            int i = preparedStatement.executeUpdate();
            if (i >= 1) {
                System.out.println("____________________________");
                System.out.println("| User Added Successfully   |");
                System.out.println("|___________________________|");
                System.out.println();
                System.out.printf(" %-20s %-25s %-30s %-10s ", "FULLNAME", "EMAIL", "MOBILE NUMBER", "ROLE");
                System.out.println();
                System.out.printf(" %-20s %-25s %-30s %-10s ", user.getName(), user.getEmail(), user.getMobileNumber(), user.getRole());
                System.out.println();
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Add User      |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewAllUsers() {
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ USER DETAILS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        String query = "SELECT USERID, NAME, EMAIL, ROLE FROM USERI1436;";
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            System.out.println("_______________________________________________________________________________");
            System.out.printf("| %-8s | %-17s | %-30s | %-10s |%n", "USERID", "USERNAME", "EMAIL", "ROLE");
            System.out.println("-------------------------------------------------------------------------------");

            while (resultSet.next()) {
                System.out.printf("| %-8d | %-17s | %-30s | %-10s |%n",
                        resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getString(4));
            }
            System.out.println("______________________________________________________________________________");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteUserFromDB(int userId) {
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ DELETE USER +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        String deleteBookingsQuery = "DELETE FROM BOOKINGSI1436 WHERE userId = ?";
        String deleteUserQuery = "DELETE FROM USERI1436 WHERE userId = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(deleteBookingsQuery);
            preparedStatement.setInt(1, userId);

            // Delete related bookings
            int bookingsDeleted = preparedStatement.executeUpdate();
            if (bookingsDeleted >= 1) {
                System.out.println();
                System.out.println("____________________________________________");
                System.out.println("|  Related bookings deleted successfully.   |");
                System.out.println("|___________________________________________|");
                System.out.println();
            }

            // Delete user
            preparedStatement = connection.prepareStatement(deleteUserQuery);
            preparedStatement.setInt(1, userId);
            int userDeleted = preparedStatement.executeUpdate();
            if (userDeleted >= 1) {
                System.out.println("____________________________");
                System.out.println("| User Deleted Successfully |");
                System.out.println("|___________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Delete User   |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void manageRoles(User user) {
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ UPDATE ROLES ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        String query = "UPDATE USERI1436 SET ROLE = ? WHERE USERID = ?;";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, user.getRole());
            preparedStatement.setInt(2, user.getUserId());

            int success = preparedStatement.executeUpdate();
            if (success >= 1) {
                System.out.println("____________________________");
                System.out.println("| Role Updated Successfully |");
                System.out.println("|___________________________|");
            } else {
                System.out.println("____________________________");
                System.out.println("| ! Failed To Update Role   |");
                System.out.println("|___________________________|");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void viewAllEventFromDB() {
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++ VIEW EVENT DETAILS ++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println();

        String query = "SELECT eventId, eventName, description, organiserId, eventdate, eventTime, venue, capacity, status, price FROM EVENTSI1436;";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            // Print the header
            System.out.printf("%-10s %-20s %-40s %-15s %-12s %-12s %-35s %-10s %-10s %-10s%n",
                    "EVENTID",
                    "EVENTNAME",
                    "DESCRIPTION",
                    "ORGANISERID",
                    "DATE",
                    "TIME",
                    "VENUE",
                    "CAPACITY",
                    "STATUS",
                    "PRICE");
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            // Iterate through the result set and print the data
            while (resultSet.next()) {
                System.out.printf("%-10d %-20s %-40s %-15d %-12s %-12s %-35s %-10d %-10s %-10s%n",
                        resultSet.getInt(1), // eventId
                        resultSet.getString(2), // eventName
                        resultSet.getString(3), // description
                        resultSet.getInt(4), // organizerId
                        resultSet.getDate(5), // eventDate
                        resultSet.getTime(6), // eventTime
                        resultSet.getString(7), // venue
                        resultSet.getInt(8), // capacity
                        resultSet.getString(9),//Status
                        resultSet.getLong(10));//price
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
