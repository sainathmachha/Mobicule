package com.eventmngtsys.dao;

import com.eventmngtsys.entity.Booking;
import com.eventmngtsys.entity.Feedback;

import java.sql.Connection;

public interface AttendeeDAO {

    void createBooking(Booking booking);

    void updateSeatsLeft(int eventId, int seatsBooked);

    boolean userExists(int userId);

    void viewBookedEvents(int userId);

    void cancelBookedEvent(int bookingId, int userId);

    boolean createFeedback(Feedback feedback);

    boolean userVerifyEventId(int eventId);
}
