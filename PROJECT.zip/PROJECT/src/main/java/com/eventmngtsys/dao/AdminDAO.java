package com.eventmngtsys.dao;

import com.eventmngtsys.entity.User;

public interface AdminDAO {

    void addUserInDB(User user);
    void viewAllUsers();
    void deleteUserFromDB(int userId);
    void manageRoles(User user);
    void viewAllEventFromDB();
}
