package com.eventmngtsys.controller;

import com.eventmngtsys.entity.Feedback;

import java.util.Scanner;

public class FeedbackController {

    int userId;
    int eventId;
    int rating;
    String comments;
    public Feedback getFeedbackDetails(){

        try(Scanner sc = new Scanner(System.in)){
            // Validating Event Id
            while (true) {
                System.out.print("Enter EVENT ID: \n-->");
                String eventIdInput = sc.nextLine().trim();
                if (eventIdInput.matches("^[0-9]+$")) {
                    eventId = Integer.parseInt(eventIdInput);
                    break;
                }
                System.out.println("ENTER A VALID EVENT ID: \n-->");
            }

            System.out.println("----------------------------------------------------------");

            // Validating Event Id
            while (true) {
                System.out.print("Enter USER ID: \n-->");
                String userIdInput = sc.nextLine().trim();
                if (userIdInput.matches("^[0-9]+$")) {
                    userId = Integer.parseInt(userIdInput);
                    break;
                }
                System.out.println("ENTER A VALID USER ID: \n-->");
            }

            System.out.println("----------------------------------------------------------");

            // Rating


            while (true) {
                System.out.print("Enter RATING (1-5): \n-->");
                String ratingInput = sc.nextLine().trim();
                if (ratingInput.matches("^[1-5]$")) {
                    rating = Integer.parseInt(ratingInput);
                    break;
                } else {
                    System.out.println("---------------------");
                    System.out.println("|  !INVALID RATING  |");
                    System.out.println("---------------------");
                }
            }

            System.out.println("----------------------------------------------------------");

            // Comments
            System.out.print("Enter COMMENTS: \n-->");
            comments = sc.nextLine().trim();
        }catch (Exception e){
            e.printStackTrace();
        }
        return new Feedback(eventId,userId,rating,comments);
    }

}
