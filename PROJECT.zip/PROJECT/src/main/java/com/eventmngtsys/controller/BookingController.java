package com.eventmngtsys.controller;

import com.eventmngtsys.entity.Booking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import static com.eventmngtsys.presentation.Main.connection;

public class BookingController {

    public Booking getBookingDetails() {
        int eventId = 0, userId = 0, seatsBooked = 0;
        String eventIdInput, userIdInput, seatsBookedInput;

        try (Scanner sc = new Scanner(System.in)) {
            // Validating Event Id
            while (true) {
                System.out.print("Enter EVENT ID: \n-->");
                eventIdInput = sc.nextLine().trim();
                if (eventIdInput.matches("^[0-9]+$")) {
                    eventId = Integer.parseInt(eventIdInput);
                    if (userVerifyEventId(eventId)) {
                        break;
                    } else {
                        System.out.println("Event ID does not exist. Please enter a valid EVENT ID.");
                    }
                } else {
                    System.out.println("ENTER A VALID EVENT ID: \n-->");
                }
            }
            System.out.println("----------------------------------------------------------");

            // Validating User Id
            while (true) {
                System.out.print("Enter USER ID: \n-->");
                userIdInput = sc.nextLine().trim();
                if (userIdInput.matches("^[0-9]+$")) {
                    userId = Integer.parseInt(userIdInput);
                    break;
                } else {
                    System.out.println("! Invalid User ID type");
                }
            }
            System.out.println("----------------------------------------------------------");

            // Seats Booked
            while (true) {
                System.out.print("Enter SEATS YOU WANT TO BOOK: \n-->");
                seatsBookedInput = sc.nextLine().trim();
                if (seatsBookedInput.matches("^[0-9]+$")) {
                    seatsBooked = Integer.parseInt(seatsBookedInput);
                    if (checkSeatCapacity(eventId, seatsBooked)) {
                        break;
                    } else {
                        System.out.println("CAPACITY EXCEEDED: \n-->");
                    }
                } else {
                    System.out.println("ENTER A VALID NUMBER OF SEATS: \n-->");
                }
            }
            System.out.println("----------------------------------------------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new Booking(eventId, userId, seatsBooked);
    }

    public boolean userVerifyEventId(int eventId) {
        String query = "SELECT COUNT(*) FROM EVENTSI1436 WHERE eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) == 1) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }


    public boolean checkSeatCapacity(int eventId, int capacity) {
        if (connection == null) {
            System.out.println("Connection is null");
            return false;
        }

        String query = "SELECT capacity FROM EVENTSI1436 WHERE eventId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next() && capacity <= resultSet.getInt(1)) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }

    public int getBookingId() {
        System.out.println("ENTER BOOKING ID: ");
        return new Scanner(System.in).nextInt();
    }
}
