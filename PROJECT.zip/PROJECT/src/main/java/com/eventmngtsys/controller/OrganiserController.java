package com.eventmngtsys.controller;

import com.eventmngtsys.entity.Event;

import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;

public class OrganiserController {

    int organiserId, capacity;
    long price;
    String eventName, description, venue, status;
    Date eventDate;
    Time eventTime;
    int eventId;

    public Event getCreateEventDetails() {
        try (Scanner sc = new Scanner(System.in)) {
            // Validating Event Name
            while (true) {
                System.out.print("Enter Event Name: \n-->");
                eventName = sc.nextLine().trim();
                if (eventName.matches("^[A-Za-z\\s]+$")) {
                    break;
                } else {
                    System.out.println("---------------------------");
                    System.out.println("|   !INVALID EVENT NAME   |");
                    System.out.println("---------------------------");
                }
            }

            // Description
            System.out.print("Enter Description: \n-->");
            description = sc.nextLine().trim();

            // OrganiserId
            System.out.print("Enter Organiser ID: \n-->");
            organiserId = sc.nextInt();
            sc.nextLine();

            // Validating Date
            while (true) {
                System.out.print("Enter Date (YYYY-MM-DD): \n-->");
                String dateInput = sc.nextLine().trim();
                try {
                    eventDate = Date.valueOf(dateInput);
                    break;
                } catch (IllegalArgumentException e) {
                    System.out.println("---------------------");
                    System.out.println("|   !INVALID DATE   |");
                    System.out.println("---------------------");
                }
            }

            // Validating Time
            while (true) {
                System.out.print("Enter Time (HH:MM:SS): \n-->");
                String timeInput = sc.nextLine().trim();
                try {
                    eventTime = Time.valueOf(timeInput);
                    break;
                } catch (IllegalArgumentException e) {
                    System.out.println("---------------------");
                    System.out.println("|   !INVALID TIME   |");
                    System.out.println("---------------------");
                }
            }

            // Validating Venue
            while (true) {
                System.out.print("Enter Venue: \n-->");
                venue = sc.nextLine().trim();
                if (venue.matches("^[A-Za-z0-9\\-,.:'{}()\\s]+$")) {
                    break;
                } else {
                    System.out.println("---------------------------------");
                    System.out.println("|   !INVALID EVENT VENUE NAME   |");
                    System.out.println("---------------------------------");
                }
            }

            // Validating Capacity
            while (true) {
                System.out.print("Enter Capacity: \n-->");
                String capacityInput = sc.nextLine().trim();
                if (capacityInput.matches("^[0-9]+$")) {
                    capacity = Integer.parseInt(capacityInput);
                    break;
                } else {
                    System.out.println("-------------------------");
                    System.out.println("|   !INVALID CAPACITY   |");
                    System.out.println("-------------------------");
                }
            }

            // Validating Status
            while (true) {
                System.out.print("Enter Status (SCHEDULED, RESCHEDULED, ON HOLD, IN PROGRESS, COMPLETED, DELAYED, CANCELLED): \n-->");
                status = sc.nextLine().trim().toUpperCase();
                if (status.matches("^(SCHEDULED|RESCHEDULED|ON HOLD|IN PROGRESS|COMPLETED|DELAYED|CANCELLED)$")) {
                    break;
                } else {
                    System.out.println("! INVALID STATUS");
                }
            }

            // Validating Price
            while (true) {
                System.out.print("Enter Price: \n-->");
                String input = sc.nextLine().trim();
                if (input.matches("^[0-9]+$")) {
                    price = Long.parseLong(input);
                    break;
                } else {
                    System.out.println("-------------------------");
                    System.out.println("|   !INVALID PRICE   |");
                    System.out.println("-------------------------");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new Event(organiserId, capacity, price, eventName, description, venue, status, eventDate, eventTime);
    }

    public int getOrgId() {
        try (Scanner sc = new Scanner(System.in)) {
            while (true) {
                System.out.print("Enter Organiser ID: \n-->");
                String input = sc.nextLine().trim();
                try {
                    organiserId = Integer.parseInt(input);
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid integer for the Organiser ID.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return organiserId;
    }

    public Event getUpdateEventDetails(){

        try(Scanner sc = new Scanner(System.in);) {
            int eventID = getEventId();

            System.out.println("ENTER NEW EVENT NAME: ");
            String newEventName = sc.nextLine().trim();
            System.out.println();

            System.out.print("ENTER NEW DESCRIPTION: ");
            String newDescription = sc.nextLine().trim();
            System.out.println();

            System.out.print("ENTER NEW ORGANISER ID: ");
            String newOrganizerIdInput = sc.nextLine().trim();
            System.out.println();

            System.out.print("ENTER NEW DATE(YYYY-MM-DD): ");
            String newDateInput = sc.nextLine().trim();
            System.out.println();

            System.out.print("ENTER NEW TIME(HH:MM:SS): ");
            String newTimeInput = sc.nextLine().trim();
            System.out.println();

            System.out.print("ENTER NEW VENUE: ");
            String newVenue = sc.nextLine().trim();
            System.out.println();

            System.out.print("ENTER NEW CAPACITY: ");
            String newCapacity = sc.nextLine().trim();
            System.out.println();

            System.out.print("ENTER NEW STATUS: ");
            String newStatus = sc.nextLine();
            System.out.println();

            System.out.print("Enter new Price: ");
            long newPrice = Integer.parseInt(sc.nextLine());
            System.out.println();
        }catch (Exception e){
            e.printStackTrace();
        }
        return new Event(eventId,organiserId,capacity,price,eventName,description,venue,status,eventDate,eventTime);
    }

    public int getEventId(){
        int eventId = 0;
        try(Scanner sc = new Scanner(System.in);) {
            System.out.println("ENTER EVENT ID: ");
            eventId = Integer.valueOf(sc.nextLine().trim());
        }catch (Exception e){
            e.printStackTrace();
        }
        return eventId;
    }
}