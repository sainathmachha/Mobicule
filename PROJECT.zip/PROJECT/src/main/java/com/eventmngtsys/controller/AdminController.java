package com.eventmngtsys.controller;

import com.eventmngtsys.HashingPassword;
import com.eventmngtsys.entity.User;

import java.util.Scanner;

public class AdminController {
    private static Scanner sc = new Scanner(System.in);

    int userId;
    private String fullName;
    private String email, password, role;
    private String mobileNumber;

    public User getUserDetailsToAdd(){
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++ ADD USER +++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++");
        System.out.println();
        while (true) {
            System.out.print("Enter Full Name: ");
            fullName = sc.nextLine().trim();
            if (fullName.matches("^[A-Za-z]+\\s[A-Za-z]{4,30}$")) {
                break;
            }
            System.out.println("! FULL NAME IS NOT VALID");
        }

        // Validating Email
        while (true) {
            System.out.print("Enter Email: \n-->");
            email = sc.nextLine().trim();
            if (email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$")) {
                break;
            }
            System.out.println("PLEASE ENTER A VALID EMAIL!");
        }

        // Validating Password
        while (true) {
            System.out.print("Enter Password: \n-->");
            password = sc.nextLine().trim();
            if (password.matches("^[A-Za-z0-9.@#$%&]+$")) {
                break;
            }
            System.out.println("! PASSWORD ISN'T VALID");
        }

        // Validating Mobile Number
        while (true) {
            System.out.print("Enter Mobile Number(10-12 Digits Number): \n-->");
            mobileNumber = sc.nextLine().trim();
            if (mobileNumber.matches("^[0-9]{10,12}$")) {
                break;
            }
            System.out.println("! MOBILE NUMBER ISN'T VALID");
        }

        // Validating Role
        while (true) {
            System.out.print("Enter Role (USER, ORGANISER, ADMIN): \n-->");
            role = sc.nextLine().trim().toUpperCase();
            if (role.equals("USER") || role.equals("ORGANISER") || role.equals("ADMIN")) {
                break;
            }
            System.out.println("! INVALID ROLE");
        }
        return new User(fullName, email, HashingPassword.hashPassword(password), role, mobileNumber);
    }

    public int getUserId(){
        int userId;
        while (true) {
            System.out.print("Enter USER ID: \n-->");
            userId = sc.nextInt();
            sc.nextLine();
            if (String.valueOf(userId).matches("^[0-9]+$")) {
                break;
            }
            System.out.println("________________________");
            System.out.println("  !USERID ISN'T VALID   ");
            System.out.println("________________________");
        }
        return userId;
    }

    public User getManageRolesDetails(){
        while (true) {
            System.out.print("Enter ROLE You Want To Assign (ADMIN, ORGANISER, USER): ");
            role = sc.nextLine().trim().toUpperCase();
            if (role.equals("ADMIN") || role.equals("USER") || role.equals("ORGANISER")) {
                break;
            }
            System.out.println("! INVALID ROLE");
        }

        // Username
        userId = getUserId();

        return new User(userId, role);
    }

}
