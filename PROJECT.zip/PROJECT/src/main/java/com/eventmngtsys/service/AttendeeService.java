package com.eventmngtsys.service;

import java.sql.Connection;

public interface AttendeeService {

    void bookEvent();
    void viewBookedEvents();
    void cancelBooking();
    void provideFeedback();
    void viewEventDetails();
}
