package com.eventmngtsys.service.impl;

import com.eventmngtsys.controller.OrganiserController;
import com.eventmngtsys.dao.OrganiserDAO;
import com.eventmngtsys.dao.impl.OrganiserDAOImpl;
import com.eventmngtsys.service.OrganiserService;

import static com.eventmngtsys.presentation.Main.connection;

public class OrganiserServiceImpl implements OrganiserService {

    OrganiserDAO orgDAO = new OrganiserDAOImpl(connection);
    OrganiserController orgController = new OrganiserController();
    AdminServiceImpl adminServiceImpl = new AdminServiceImpl();

    @Override
    public void addEvent() {
        orgDAO.createEventInDB(orgController.getCreateEventDetails());
    }

    @Override
    public void listMyEvents() {
        orgDAO.listAllMyEvents(orgController.getOrgId());
    }

    @Override
    public void viewEventDetails() {
        adminServiceImpl.viewAllEvents();
    }

    @Override
    public void updateEvent() {
        orgDAO.updateEvent(orgController.getUpdateEventDetails());
    }

    @Override
    public void deleteEvent() {
        orgDAO.deleteEventFromDB(orgController.getEventId());
    }

    @Override
    public void viewBookingsForEvent() {
        orgDAO.viewBookingsForMyEvents(orgController.getEventId(), orgController.getEventId());
    }

    @Override
    public void viewFeedBackForEvents() {
        orgDAO.viewFeedBackForEvents(orgController.getOrgId());
    }

}
