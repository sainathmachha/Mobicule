package com.eventmngtsys.service.impl;

import com.eventmngtsys.controller.AdminController;
import com.eventmngtsys.controller.BookingController;
import com.eventmngtsys.controller.FeedbackController;
import com.eventmngtsys.dao.AttendeeDAO;
import com.eventmngtsys.dao.impl.AttendeeDAOImpl;
import com.eventmngtsys.service.AttendeeService;

import static com.eventmngtsys.presentation.Main.connection;

public class AttendeeServiceImpl implements AttendeeService {

    AttendeeDAO attendeeDAO = new AttendeeDAOImpl(connection);
    BookingController bookingController = new BookingController();

    @Override
    public void bookEvent() {
        attendeeDAO.createBooking(bookingController.getBookingDetails());
    }

    @Override
    public void viewBookedEvents() {
        attendeeDAO.viewBookedEvents(new AdminController().getUserId());
    }

    @Override
    public void cancelBooking() {
        attendeeDAO.cancelBookedEvent(new BookingController().getBookingId(),new AdminController().getUserId());
    }

    @Override
    public void provideFeedback() {
        attendeeDAO.createFeedback(new FeedbackController().getFeedbackDetails());
    }

    @Override
    public void viewEventDetails() {
        new OrganiserServiceImpl().viewEventDetails();
    }
}
