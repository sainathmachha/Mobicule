package com.eventmngtsys.service;

import java.sql.Connection;

public interface OrganiserService {

    void addEvent();
    void listMyEvents();
    void viewEventDetails();
    void updateEvent();
    void deleteEvent();
    void viewBookingsForEvent();
    void viewFeedBackForEvents();
}
