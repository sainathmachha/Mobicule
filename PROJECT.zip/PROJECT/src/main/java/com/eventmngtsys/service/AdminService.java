package com.eventmngtsys.service;

public interface AdminService{
        //User table
        void addUser();
        void viewAllUsers();
        void deleteUser();
        void manageRoles();
        //Events
        void viewAllEvents();
}
