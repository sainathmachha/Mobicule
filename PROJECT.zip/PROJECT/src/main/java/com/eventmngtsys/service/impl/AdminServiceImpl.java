package com.eventmngtsys.service.impl;

import com.eventmngtsys.controller.AdminController;
import com.eventmngtsys.dao.AdminDAO;
import com.eventmngtsys.dao.impl.AdminDAOImpl;
import com.eventmngtsys.service.AdminService;

import java.sql.Connection;
import java.sql.SQLException;

import static com.eventmngtsys.presentation.Main.connection;

public class AdminServiceImpl implements AdminService {

    AdminDAO adminDAO = new AdminDAOImpl(connection);
    AdminController adminController = new AdminController();

    @Override
    public void addUser() {
        adminDAO.addUserInDB(adminController.getUserDetailsToAdd());
    }

    @Override
    public void viewAllUsers() {
        adminDAO.viewAllUsers();
    }

    @Override
    public void deleteUser() {
        adminDAO.deleteUserFromDB(adminController.getUserId());
    }

    @Override
    public void manageRoles() {
        adminDAO.manageRoles(adminController.getManageRolesDetails());
    }

    @Override
    public void viewAllEvents() {
        adminDAO.viewAllEventFromDB();
    }
}
