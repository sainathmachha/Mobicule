package com.eventmngtsys.entity;

public class Booking {

    int bookingId, eventId,userId, seatsBooked;
    String bookingStatus;

    public Booking(int eventId, int userId, int seatsBooked) {
        this.eventId = eventId;
        this.userId = userId;
        this.seatsBooked = seatsBooked;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getSeatsBooked() {
        return seatsBooked;
    }

    public void setSeatsBooked(int seatsBooked) {
        this.seatsBooked = seatsBooked;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public Booking(int bookingId, int eventId, int userId, int seatsBooked, String bookingStatus) {
        this.bookingId = bookingId;
        this.eventId = eventId;
        this.userId = userId;
        this.seatsBooked = seatsBooked;
        this.bookingStatus = bookingStatus;
    }

    public Booking(int eventId, int userId, int seatsBooked, String bookingStatus) {
        this.eventId = eventId;
        this.userId = userId;
        this.seatsBooked = seatsBooked;
        this.bookingStatus = bookingStatus;
    }
}
