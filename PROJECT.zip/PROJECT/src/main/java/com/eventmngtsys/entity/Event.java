package com.eventmngtsys.entity;

import java.sql.Date;
import java.sql.Time;

public class Event {

    int eventId, organiserId, capacity;
    long price;
    String eventName,description,venue,status;
    Date eventDate;
    Time eventTime;

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getOrganiserId() {
        return organiserId;
    }

    public void setOrganiserId(int organiserId) {
        this.organiserId = organiserId;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getEventDate() {
        return eventDate;
    }

    public void setEventDate(Date eventDate) {
        this.eventDate = eventDate;
    }

    public Time getEventTime() {
        return eventTime;
    }

    public void setEventTime(Time eventTime) {
        this.eventTime = eventTime;
    }

    public Event(int eventId, int organiserId, int capacity, long price, String eventName, String description, String venue, String status, Date eventDate, Time eventTime) {
        this.eventId = eventId;
        this.organiserId = organiserId;
        this.capacity = capacity;
        this.price = price;
        this.eventName = eventName;
        this.description = description;
        this.venue = venue;
        this.status = status;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
    }

    public Event(int organiserId, int capacity, long price, String eventName, String description, String venue, String status, Date eventDate, Time eventTime) {
        this.organiserId = organiserId;
        this.capacity = capacity;
        this.price = price;
        this.eventName = eventName;
        this.description = description;
        this.venue = venue;
        this.status = status;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
    }
}
