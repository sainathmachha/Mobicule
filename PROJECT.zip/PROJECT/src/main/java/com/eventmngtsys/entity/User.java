package com.eventmngtsys.entity;

public class User {

    int userId;
    String fullName;
    String email;
    String password;
    String role;
    String mobileNumber;

    public User(int userId, String role) {
        this.userId = userId;
        this.role = role;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return fullName;
    }

    public void setName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public User(String fullName, String email, String password, String role, String mobileNumber) {
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.role = role;
        this.mobileNumber = mobileNumber;
    }

    public User(String fullName, String email, String role, String mobileNumber) {
        this.fullName = fullName;
        this.email = email;
        this.role = role;
        this.mobileNumber = mobileNumber;
    }
}
