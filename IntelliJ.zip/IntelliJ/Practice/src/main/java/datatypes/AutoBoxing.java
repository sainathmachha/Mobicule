package datatypes;

public class AutoBoxing {

    static int data = 10;
    static Integer integer = new Integer(data);

    public static void main(String[] args) {
        System.out.println(data);
        System.out.println(integer);
    }

}
