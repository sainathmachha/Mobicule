package accessModifiers.Default;

class DefaultClass{

    static int numbers = 21;

    public static void main(String[] args){
        System.out.println(numbers);
    }

}