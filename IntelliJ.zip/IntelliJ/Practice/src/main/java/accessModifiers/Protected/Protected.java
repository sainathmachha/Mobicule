package accessModifiers.Protected;

class Protected extends ProtectedClass{

    static int numbers = val;

    //static int defaultVal = DefaultClass.numbers;

    public static void main(String[] args){
        System.out.println(numbers);
    }

}
