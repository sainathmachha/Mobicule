package constructor;

public class CopyConstructor {

    int id;
    String name;

    public CopyConstructor(int i, String n){
        id = i;
        name = n;
    }

    public CopyConstructor(CopyConstructor c){
        id = c.id;
        name = c.name;
    }

    public static void main(String[] args) {
        CopyConstructor c1 = new CopyConstructor(32, "Sainath");
        System.out.println(c1);
        CopyConstructor c2 = new CopyConstructor(30, "Sainath");
        CopyConstructor c3 = new CopyConstructor(c2);
        System.out.println(c3);
    }

    @Override
    public String toString() {
        return "CopyConstructor{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

}
