package constructor;

public class ConstructorOverloading {

	int a;
	String name;
	int speed;

	public ConstructorOverloading() {
		System.out.println("No-args constructor");
	}

	public ConstructorOverloading(int a, String name) {
		this.a = a;
		this.name = name;
		System.out.println("Constructor with 2 arguments");
		System.out.println(a + " " + name);
	}

	public ConstructorOverloading(int a, String name, int speed) {
		this.a = a;
		this.name = name;
		this.speed = speed;
		System.out.println("Constructor with 3 arguments");
		System.out.println(a + " " + name + " " + speed + " km/hr");
	}

	public static void main(String[] args) {
		ConstructorOverloading co1 = new ConstructorOverloading();
		ConstructorOverloading co2 = new ConstructorOverloading(32, "Sainath");
		ConstructorOverloading co3 = new ConstructorOverloading(2024, "Supra",
				340);
	}
}
