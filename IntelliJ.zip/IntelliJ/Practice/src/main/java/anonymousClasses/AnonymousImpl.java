package anonymousClasses;

public class AnonymousImpl {
	// Animal animal = new Animal() {
	// @Override
	// public void Bark() {
	// System.out.println("Bow..Bow");
	// }
	// };
	//
	// public static void main(String[] args) {
	// AnonymousImpl ai = new AnonymousImpl();
	// ai.animal.Bark();
	// }

	// public static void main(String[] args) {
	// Animal animal = new Animal() {
	//
	// @Override
	// public void Bark() {
	// System.out.println("Meow Meow");
	// }
	// };
	//
	// animal.Bark();
	// }

	public static void main(String[] args) {
		Car myCar = new Car() {
			@Override
			void Dashboard(int speed, String brand) {
				System.out.println("Dashboard Code " + speed + " " + brand);
			}
		};

		myCar.Dashboard(300, "Porsche");
	}
}