package anonymousClasses;

class Car {
	int speed;
	String brand;

	void Dashboard(int speed, String brand) {
		this.speed = speed;
		this.brand = brand;
		System.out.println("The speed of the car is : " + speed
				+ " and Brand is :  " + brand);
	}
}
