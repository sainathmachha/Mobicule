package anonymousClasses;

public interface Animal {
	public void Bark();
}
