package anonymousClasses;

public interface AnonymousInterface {

	public void showName();
}