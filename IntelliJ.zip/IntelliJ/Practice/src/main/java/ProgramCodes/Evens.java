package ProgramCodes;

public class Evens {

    public static void main(String[] args) {
        //Even numbers
        for(int i = 0; i < 10; i+=2){
            System.out.println(i);
        }
    }
}
