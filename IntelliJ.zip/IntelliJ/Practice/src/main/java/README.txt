
1. Classes - Static Classes, Anonymous Classes, Default/Concrete Classes, Abstract Classes
2. Methods - Method Overloading, Method Overriding
3. Constructor - Default, Parameterized, Copy Constructor
4. Access Modifiers - Public(Accessible Anywhere), Private(Encapsulation, Prevent Overriding), Protected(Accessible in the classes in same package and in classes extending it in other package), Default(Only accessible within the classes in same package)
5. Data Types - byte, short, int, long, float, double, boolean, char
6. Type casting
7. Operators
8. If else
9. Switch
10.For Loop
11.While Loop
12.break
13.final
14.static
15.String and its methods
16.Arrays
17.Arrays Sorting
18.Getter and setter methods