package classes;

public class StaticClass {

	static int roll;
	static String name;

	static void ReturnRollName(int roll, String name) {
		StaticClass.roll = roll;
		StaticClass.name = name;

		System.out.println("this is a static method");
		System.out
				.println("Roll no : " + roll + " and " + " name is : " + name);
	}

	static class NestedClass {
		static {
			System.out.println("this is a static block inside a static class");
		}

		public void Show() {
			System.out.println("Non static method inside a static class");
		}
	}
}

class TestCode {
	public static void main(String... args) {
		StaticClass.ReturnRollName(31, "Sainath");

		StaticClass.NestedClass sn = new StaticClass.NestedClass();
		sn.Show();  
	}
}