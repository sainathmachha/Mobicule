package classes;

public class Pojo {

	private String num;

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public static void main(String[] args) {
		Pojo pj = new Pojo();
		pj.setNum("9021473750");
		System.out.println(pj.getNum());
	}

}