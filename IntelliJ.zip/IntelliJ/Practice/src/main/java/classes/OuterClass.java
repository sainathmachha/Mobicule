package classes;

//public class OuterClass {
//	public class InnerClass {
//		public void Display() {
//			System.out.println("This is a inner class");
//		}
//	}
//
//	public static void main(String[] args) {
//		OuterClass outer = new OuterClass();
//
//		OuterClass.InnerClass ic = outer.new InnerClass();
//		ic.Display();
//	}
//}

public class OuterClass {
	public static class InnerClass {
		public static void Display() {
			System.out.println("This is a inner class");
		}
	}

	public static void main(String[] args) {
		// OuterClass.InnerClass.Display();
		OuterClass.InnerClass ic = new OuterClass.InnerClass();
		ic.Display();
	}
}
