package classes;

public class NewClass {

	public static void main(String... args) {
		Car myCar = new Car("Supra", 320);
		System.out.println(myCar);
	}
}

class Car {
	String name;
	int speed;

	public Car(String name, int speed) {
		this.name = name;
		this.speed = speed;
	}

	@Override
	public String toString() {
		return "Car name : " + name + ", Speed : " + speed + " km/hr";
	}
}