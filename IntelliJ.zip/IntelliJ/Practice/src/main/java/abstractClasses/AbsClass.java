package abstractClasses;

import defaultClasses.DefaultClass;

abstract class AbsClass{
	
	int roll;
	public AbsClass(){
		DefaultClass dc = new DefaultClass();
		this.roll = dc.rollNo;
	}

	abstract void ShowName();
	
	public void ShowRollno(){
		System.out.println("Roll number is : "+roll);
	}
	
}