package abstractClasses;

public class AbsExtention extends AbsClass {

	String name = "sainath";

	public static void main(String[] args) {
		AbsExtention ae = new AbsExtention();
		ae.ShowName();
		ae.ShowRollno();
	}

	@Override
	public void ShowName() {
		System.out.println("Your name is : " + name);
	}
}