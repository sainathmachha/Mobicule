package rules;

public interface Interfaces { //either public or default

    int SAINATH = 32; //public static final by default and cannot be changed

    static int add(int a, int b) {//by default public, and it can be private only to use in any other parts of current interface
        return a + b;
    }

    private void method(){ //from java 9 onwards
        isPresent();
    }

    public default boolean isPresent(){ //by default public and cannot change it
        return true;
    }

    public abstract void sum(); //public abstract by default and no other access modifiers can be used
}