package rules;

import java.util.Arrays;
import java.util.Collections;

public class ArraysPractice
{
    static int[] arr3 = {1,2,3,4,5};
    static int[] arr4 = new int[]{2,4,1,6,7};
    int[] arr = new int[10];
    int arr1[] = new int[10];
    int [] arr2 = new int[10];

    public static void SortAsc(int[] arr){
        for(int i=0; i<arr.length-1; i++){
            if(arr[i] < arr[i+1]){
                int temp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = temp;
            }
        }
        System.out.println(Arrays.toString(arr));
    }

    public static void main(String[] args) {
        for(int arr : arr3){
            System.out.println(arr);
        }
        System.out.println("-----------------------");

        SortAsc(arr4);

        System.out.println("-----------------------");

        int[][] multi = new int[][]{{1,2,3}, {34,32,456}};
        for(int i = 0; i<multi.length; i++){
            for(int j = 0; j<multi[i].length; j++){
                System.out.print(multi[i][j] + ",");
            }
            System.out.println();
        }

        System.out.println("----------------------");

        for(int i = 0; i<arr3.length; i++){
            System.out.println(arr3[i]);
        }

        System.out.println("---------------------");

        for(int i = 0; i<arr3.length; i++){
            System.out.println(arr3[i]);
        }

        System.out.println("-----------------------");

        for(int i=arr3.length-1; i>=0; i--){
            System.out.println(arr3[i]);
        }

        System.out.println("-----------------------");

        int i=0;
        while(i<arr3.length){
            System.out.println(arr3[i]);
            i++;
        }

        System.out.println("-----------------------");

        arr3[2] = 32;

        Integer[] reverse = new Integer[]{2,1,24,45,86};

        Arrays.sort(arr4);
        System.out.println(Arrays.toString(arr4));

        System.out.println("-----------------------");

        Arrays.parallelSort(arr4);
        System.out.println(Arrays.toString(arr4));

        System.out.println("-----------------------");

        Arrays.sort(reverse, Collections.reverseOrder());
        System.out.println(Arrays.toString(reverse));
    }
}
