package rules.Loops;

public class SwitchCases {

    private static void printing(){
        System.out.println("Printed");

    }

    public static void main(String[] args) {
        float x = 1.2402930923F;

        switch((int) x){
            case 1:
                int y = 10;
                switch (y){
                    case 10:
                        System.out.println("Nested Switch");
                        break;
                }
                System.out.println("One");
                class Cases extends SwitchCases{
                    public void printing(){
                        System.out.println(x + " X value");
                    }
                }
                Cases cases = new Cases();
                cases.printing();
                SwitchCases.printing();
                printing();
            case 2:
                System.out.println("Two");
                break;
            case 3:
                System.out.println("Three");
                break;
            case 4:
                System.out.println("Four");
                break;
            case 5:
                System.out.println("Five");
                break;
            case 6:
                System.out.println("Six");
                break;
            case 7:
                return;
            default:
                System.out.println(x);
                break;
        }
    }
}
