package rules.Loops;

public class TryCatch {

    public static void main(String[] args) {
        new TryCatch().returnPresent();
    }

    /*
    1.In case of return statement: if no exception occurs and no finally is present the execution will stop here.

    -if exception occurs then it will first print's the exception then it will directly stop executing the lines below the statement that caused exception so it won't reach up to return.

    -but if a finally block is present then it will first it will catch the exception then prints everything present in finally then prints the statements outside the loops

    -When an exception occurs inside a try block, it immediately stops execution of the remaining code inside the try block, just like a break statement.
    -The control jumps directly to the corresponding catch block (if one exists) or the finally block, skipping all the lines after the exception.

    2. In case of no return statement

    */
    public void returnPresent(){
        try {
            int a = 30/0;
            System.out.println(a);
            return;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        finally {
            System.err.println("Error");
            System.err.println("Second Error");
            System.exit(1);
            System.out.println("Regardless of any exception or return statement finally will execute everytime.");
        }
        System.out.println("Outside Try");
    }
}
