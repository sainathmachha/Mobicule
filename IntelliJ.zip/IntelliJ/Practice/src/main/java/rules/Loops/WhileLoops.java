package rules.Loops;

import java.util.Arrays;

public class WhileLoops {

    final int a;
    {
        this.a = 10;
    }

    public static void main(String[] args) {

        int i = 5;

        while(i<10) {
            System.out.println("i is : " + i);
            i++;
        }

        /*
        infinite while loop
         */
//        while(true){
//            System.out.println("True");
//        }

        final int[] arr = {1,2,3,54,3};
        int[] second = arr;
        System.out.println(Arrays.toString(second));
        second[1] = 10;
        arr[1] = 10;

        //arr = second;
        second = new int[]{20, 32, 39, 18, 20};

        System.out.println(Arrays.toString(arr));
        System.out.println(Arrays.toString(second));
    }



}
