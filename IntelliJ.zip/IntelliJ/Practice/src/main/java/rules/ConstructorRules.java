package rules;

/*
Same name as the class.

No return type.

Automatically called when an object is created.

Can be overloaded (multiple constructors with different parameters).

Cannot be inherited, but can be called using super().

Default Constructor Is Provided Only If You Don’t Define Any Constructor

The super() Call Must Be the First Statement

Constructor can be private, public, protected or default
*/

public class ConstructorRules {

    //Default Constructor (Provided by java)
    //public ConstructorRules(){} //By default java provides the default constructor if not specified and when user starts defining the constructor java stops creating the default constructor.

    //No-Argument Constructor (Default Constructor but defined by user)
    public ConstructorRules(){
        this(32); //this can be used to call another constructor
    }

    //Parameterized Constructor
    public ConstructorRules(int a) {
        super();
        System.out.println(returns());
        System.out.println(a);
    }

    public static void main(String[] args) {
        ConstructorRules constructorRules = new ConstructorRules(40);
    }

    public boolean returns(){
        return true;
    }
}
