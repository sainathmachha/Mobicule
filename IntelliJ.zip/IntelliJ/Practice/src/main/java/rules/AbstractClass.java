package rules;

public abstract class AbstractClass { //can only be public or default(package-private) and can be private and protected only for classes which are inner classes

    static String n;
    String name = "Sainath"; //can be default, private, public, protected

    //can have a constructor
    public AbstractClass(String name){
        this.name = name;
    }

    public static void main(String[] args) {
        AbstractImpl ai = new AbstractImpl("Sai");
        System.out.println(ai);
    }

    public abstract void setName();//can be public, protected and default but can't be private


    @Override
    public String toString() {
        return "AbstractClass{" +
                "name='" + name + '\'' +
                '}';
    }
}

class AbstractImpl extends AbstractClass {

    public AbstractImpl(String name) {
        super(name);
    }

    @Override
    public void setName() {
        name = "Sai";
    }
}
