package rules.collections.Map;

import java.util.HashMap;
import java.util.Map;

public class MapDemo {

    static Map<Integer, String> maps = new HashMap<>();

    public static void main(String[] args) {
        maps.put(1,"Sainath");
        maps.put(32, "Sai");
        maps.put(18, "Machha");

        System.out.println(maps.keySet() + " : " + maps.values());
    }

}
