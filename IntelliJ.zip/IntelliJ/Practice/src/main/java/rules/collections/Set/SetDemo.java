package rules.collections.Set;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {

    static Set<Integer> set = new HashSet<>();

    public static void main(String[] args) {
        set.add(12);
        set.add(49);
        set.add(56);
        set.add(12);
        System.out.println(set);

        System.out.println(set.contains(12));
    }
}
