package rules.exceptionHandling;

import java.io.IOException;

public class TryDemo {

    public static void main(String[] args){
        try{
            System.out.println("Try block execution without any exception");
            try{
                String name = null;
                System.out.println("Try inside a try..");
                //int a = 20/0;
                //System.out.println(a);
                System.out.println(name.length());
                System.out.println("Try after a exception...");
            }
            catch (ArithmeticException ae){
                System.out.println("Error occurred inside nested try...  : " + ae.getMessage() +" : " + ae.getClass());
            }
            catch (NullPointerException ne){
                System.out.println(ne);
                ne.printStackTrace();
                System.out.println("Error occurred inside nested try... " + ne.getMessage()+" : " + ne.getClass());
            }
            catch (Exception e) {
                System.out.println("Error occurred inside nested try... " + e.getMessage() +" : " + e.getClass());
            }

            System.out.println("After completion of Nested Try...");
        }catch(Exception e){
            System.out.println("Error occurred outside nested try... " + e.getMessage() + " : " + e.getClass());
        }finally{
            System.out.println("Finally prints everytime unless System.exit(0);");
        }
    }

}
