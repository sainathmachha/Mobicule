package rules.exceptionHandling;

public class AgeNotValidException extends Exception{

    public AgeNotValidException(String message){
        super(message);
        System.err.println(message);
    }

}
