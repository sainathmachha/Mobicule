package rules.exceptionHandling;


/*
                Throwable
                    |
                    v
    Exception                   Error
->Checked
->Unchecked

1. Checked Exceptions(Compile-time and Checked by Java Compiler and are recoverable conditions) : Either the compiler does this or can declare Throws inside method signature.
--> IOException, SQLException, ParseException, ClassNotFoundException

2. Unchecked Exceptions(Run-time)   :
--> ArithmeticException, NullPointerException, ArrayIndexOutOfBoundsException, IllegalArgumentException, NumberFormatException

Error : Errors cannot be handled and are not caused by any coding mistakes they are the hardware failures or JVM Failures
--> OutOfMemoryError, StackOverflowError, NoClassDefFoundError

? Try Block must be followed by a Catch or Finally.
? Catch needs a try preceding it and a finally(Optional) after it.
? Finally will execute irrespective of a error or not.
? The "throw" keyword is used to throw an exception.
?

 */

import java.io.IOException;

public class Throwing{

    public static void main(String[] args){//throws Exception
        //handle either by a throws or try-catch
        //maybe();
//        try {
//            Maybe();
//        } catch (IOException e) {
//            System.out.println("Error has Occured : "+e.getMessage() + " : " + e.getClass());
//        }
    }

    public static void maybe() throws ArithmeticException, IOException {
        System.out.println("Error may occur.");
        throw new IOException();
    }

}
