package rules.Keywords;

public class SuperKeyword {

    public int roll;
    public String name;

    public SuperKeyword(){
        this.roll = 32;
        this.name = "Sainath";
        System.out.println("Inside superclass, values of roll : "+ roll +", name : "+ name);
    }

    public void display(){
        System.out.println("Displaying...");
    }

}
