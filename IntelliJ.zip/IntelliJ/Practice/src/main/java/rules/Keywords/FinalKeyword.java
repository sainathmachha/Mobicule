package rules.Keywords;

import java.util.Arrays;

//constructors cannot be final
//a class cannot be final and abstract at the same time


public class FinalKeyword {

    public static final int CONST = 10;

    static final int[] arr = new int[]{23, 32,211,534};

    public static void main(String[] args) {
        System.out.println(CONST);

        //CONST = 12; //you cannot change the final variable

        System.out.println(Arrays.toString(arr));

        arr[1] = 10;

        System.out.println(Arrays.toString(arr));

        for(int i=0;i<arr.length; i++){
            arr[i] = 0;
        }

        System.out.println(Arrays.toString(arr));

        //arr = new int[]{2,34,3,2}; //this is not possible because in case of final objects you can change the values of the object but cannot change the reference of the objects
    }

    public final void Print(){
        System.out.println("Final Method cannot be changed");
    }

    /*
    final classes cannot be extended or inherited
     */
//    static final class Child extends Parent{
//
//    }

    public final class Parent extends FinalKeyword{

//        @Override
//        public final void Print(){
//            System.out.println("Can be changed");
//        }
    }

}
