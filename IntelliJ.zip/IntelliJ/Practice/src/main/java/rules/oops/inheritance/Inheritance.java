package rules.oops.inheritance;

//Default methods need to be Overridden

interface Inherit{

    static void stat(){
        System.out.println("Static method in Interface...");
    }

    public void running();

    public void walking();

    default void jogging(){
        System.out.println("Jogging in Interface...");
    }
}

interface SecondInterface{
    void coding();
}

public class Inheritance {

    public static void main(String[] args) {
        System.out.println("Parent class ka..");
        new Inheritance().print();
    }

    public void print(){
        System.out.println("Printing from Parent...");
    }
}

class Child extends Inheritance implements Inherit, SecondInterface{

    public static void main(String[] args) {
        Child child = new Child();
        child.print();
        child.write();
    }

    public void write(){
        System.out.println("Writing from Child...");
    }

    @Override
    public void running() {
        System.out.println("Running from Interface...");
    }

    @Override
    public void walking() {
        System.out.println("Walking  from Implementation...");
    }

    @Override
    public void jogging() {
        Inherit.super.jogging();
    }

    @Override
    public void coding() {
        System.out.println("Coding in Second Interface...");
    }

    class SecondChild extends Child{

        public void read(){
            System.out.println("Reading from SecondChild...");
        }
    }
}