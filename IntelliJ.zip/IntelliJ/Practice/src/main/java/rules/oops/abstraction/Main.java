package rules.oops.abstraction;

public class Main extends AbstractClassDemo implements AbstractionDemo{
    public static void main(String[] args) {
        System.out.println("Creating objects in abstraction : ");
        AbstractionDemo abstractionDemo = new Main();
        abstractionDemo.hiddenImplementation();

        //Abstract classes provide partial abstraction
        AbstractClassDemo abstractClassDemo = new Main();
        abstractClassDemo.abstractMethod();
        abstractClassDemo.nonAbstractMethod();
    }

    @Override
    public void hiddenImplementation() {
        System.out.println("User can't see the implementation code in abstraction can only use the functionality...");
    }

    @Override
    void abstractMethod() {
        System.out.println("Abstract method implemented in Main/Subclass...");
    }
}
