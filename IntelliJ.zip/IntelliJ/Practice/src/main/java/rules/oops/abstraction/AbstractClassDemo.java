package rules.oops.abstraction;

public abstract class AbstractClassDemo {

    abstract void abstractMethod();

    void nonAbstractMethod(){
        System.out.println("Non abstract method...");
    }

}
