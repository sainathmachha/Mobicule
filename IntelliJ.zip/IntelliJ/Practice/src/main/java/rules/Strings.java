package rules;

import java.util.Arrays;

public class Strings {

    public static String s = "Sainath  ";

    public static String str = "Sainath";



    public static void main(String[] args) {
        String str1 = new String("Sainath");
        String str2 = new String("Sainath");

        System.out.println(str1 == str2);
        System.out.println(str1.equals(str2));

        System.out.println(s.indexOf('A'));

        System.out.println(s.length());

        System.out.println(s.getClass());

        System.out.println(s.toLowerCase());

        System.out.println(Arrays.toString(s.toCharArray()));

        System.out.println(s.charAt(2));

        System.out.println(s.trim());

        System.out.println(s.trim().compareToIgnoreCase("Sainath"));

        System.out.println(s.trim().concat(" Machha").toLowerCase());

        System.out.println(s.contains("I"));

        System.out.println(s.equals("SAINATH"));

        System.out.println(s.endsWith(" "));

        System.out.println(s.startsWith("S"));

        System.out.println(s.lastIndexOf('A'));

        System.out.println(s);

        System.out.println(s.trim() == str);
        System.out.println(s.trim().equals(str));

        System.out.println(str == str1);
        System.out.println(str.equals(str1));

        System.out.println(s.subSequence(0, 4));
        System.out.println(s.substring(0,4));
        System.out.println(s.substring(0));

        System.out.println(s.strip());

        System.out.println(s.compareTo(str2));

        System.out.println(s.codePointAt(s.length()-1));

        System.out.println(s.contentEquals("Sainath  "));

        System.out.println(s.strip());

        System.out.println(s.stripLeading());

        System.out.println(s.stripTrailing());

        System.out.println(s.replace("a", "I"));

        System.out.println(s.replaceAll("a", "E"));

        System.out.println(Arrays.toString(s.split("i", 2)));

        System.out.println(String.format("Name: %s, Age: %d ", "Sainath", 22));

        System.out.println(String.valueOf(32));

        System.out.println(s.join(",", "Sai", "nath", "machha"));

        System.out.println(s.matches("Sainath  "));

        //StringBuffer(Synchronized)
        StringBuffer sb = new StringBuffer();
        System.out.println(sb.append("Sainath"));
        System.out.println(sb.append(" Machha"));
        System.out.println(sb.append(" 32"));
        System.out.println(sb.capacity());
        System.out.println(sb.reverse());
        System.out.println(sb.delete(0, 5));

        //StringBuilder sb = new StringBuilder();
        StringBuilder stringBuilder = new StringBuilder();
        System.out.println(stringBuilder.capacity());
    }
}
