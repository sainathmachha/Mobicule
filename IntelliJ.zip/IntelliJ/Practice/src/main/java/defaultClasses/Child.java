package defaultClasses;

public class Child extends DefaultClass{

    int temp;

    public Child(){
        //super(); //it must be the first line when declared in a constructor
        this.temp = super.rollNo; //you must assign a variable when using the super class's fields
        System.out.println(temp);
        //super(); it throws compilation error
    }

    public static void main(String[] args) {
        Child child = new Child();
        System.out.println(new Child().temp);
    }
}
