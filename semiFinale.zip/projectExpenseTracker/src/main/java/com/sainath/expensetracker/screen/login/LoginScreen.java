package com.sainath.expensetracker.screen.login;

import com.google.common.base.Verify;
import com.sainath.expensetracker.entity.User;
import com.sainath.expensetracker.screen.verifyotp.VerifyOtp;
import io.jmix.core.DataManager;
import io.jmix.core.MessageTools;
import io.jmix.core.Messages;
import io.jmix.securityui.authentication.AuthDetails;
import io.jmix.securityui.authentication.LoginScreenSupport;
import io.jmix.ui.*;
import io.jmix.ui.component.*;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.TextField;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@UiController("LoginScreen")
@UiDescriptor("login-screen.xml")
@Route(path = "login", root = true)
public class LoginScreen extends Screen {

    @Autowired
    private TextField<String> usernameField;

    @Autowired
    private PasswordField passwordField;

    @Autowired
    private CheckBox rememberMeCheckBox;

    @Autowired
    private ComboBox<Locale> localesField;

    @Autowired
    private Notifications notifications;

    @Autowired
    private Messages messages;

    @Autowired
    private MessageTools messageTools;

    @Autowired
    private LoginScreenSupport loginScreenSupport;

    @Autowired
    private JmixApp app;

    @Value("${ui.login.defaultUsername:}")
    private String defaultUsername;

    @Value("${ui.login.defaultPassword:}")
    private String defaultPassword;

    private final Logger log = LoggerFactory.getLogger(LoginScreen.class);
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private AuthenticationManagerBuilder authenticationManagerBuilder;
    @Autowired
    private Button generateOtp;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Subscribe
    private void onInit(InitEvent event) {
        usernameField.focus();
        initLocalesField();
        initDefaultCredentials();
    }

    private void initLocalesField() {
        localesField.setOptionsMap(messageTools.getAvailableLocalesMap());
        localesField.setValue(app.getLocale());
        localesField.addValueChangeListener(this::onLocalesFieldValueChangeEvent);

    }

    private void onLocalesFieldValueChangeEvent(HasValue.ValueChangeEvent<Locale> event) {
        //noinspection ConstantConditions
        app.setLocale(event.getValue());
        UiControllerUtils.getScreenContext(this).getScreens()
                .create(this.getClass(), OpenMode.ROOT)
                .show();
    }

    private void initDefaultCredentials() {
        if (StringUtils.isNotBlank(defaultUsername)) {
            usernameField.setValue(defaultUsername);
        } else {
            usernameField.setValue("");
        }

        if (StringUtils.isNotBlank(defaultPassword)) {
            passwordField.setValue(defaultPassword);
        } else {
            passwordField.setValue("");
        }
    }

//    @Subscribe("loginButton")
//    public void beforeShow(StandardEditor.BeforeCommitChangesEvent event){
//        notifications.create()
//                .withCaption("Hey")
//                .show();
//    }

    @Subscribe("loginButton")
    private void onSubmitActionPerformed(Button.ClickEvent event) {
        if(login()){
            generateOtp.setVisible(true);
            onGenerateOtpButton(event);
        }
    }

//    public boolean login(){
//        String username = usernameField.getValue();
//        String password = passwordField.getValue();
//
//        User user = dataManager.load(User.class)
//                .query("select u from User u WHERE u.username = :name AND u.password = :password")
//                .parameter("name", username)
//                .parameter("password",passwordEncoder.encode(password))
//                .one();
//
//        if(user!=null) {
//            return true;
//        }else{
//            return false;
//        }
//    }

    public boolean login() {
        boolean result = false;
        String username = usernameField.getValue();
        String password = passwordField.getValue();

        if (StringUtils.isEmpty(username) || StringUtils.isEmpty(password)) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption(messages.getMessage(getClass(), "emptyUsernameOrPassword"))
                    .show();
        }

        try {
            loginScreenSupport.authenticate(
                    AuthDetails.of(username, password)
                            .withLocale(localesField.getValue())
                            .withRememberMe(rememberMeCheckBox.isChecked()), this);
            result = true;
//            dialogs.createInputDialog(this).withActions(new InputDialogAction(new Action().));
        } catch (BadCredentialsException | DisabledException | LockedException e) {
            log.warn("Login failed for user '{}': {}", username, e.toString());
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption(messages.getMessage(getClass(), "loginFailed"))
                    .withDescription(messages.getMessage(getClass(), "badCredentials"))
                    .show();
        }
        return result;
    }

    @Subscribe("generateOtp")
    public void onGenerateOtpButton(Button.ClickEvent event) {
        screenBuilders.screen(this)
                .withOpenMode(OpenMode.DIALOG)
                .withScreenClass(VerifyOtp.class)
                .build()
                .show();
    }

}
