package com.sainath.expensetracker.screen.main;

import com.sainath.expensetracker.entity.Expense;
import com.sainath.expensetracker.entity.User;
import io.jmix.core.DataManager;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.ui.ScreenTools;
import io.jmix.ui.component.*;
import io.jmix.ui.component.mainwindow.Drawer;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiControllerUtils;
import io.jmix.ui.screen.UiDescriptor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.Query;
import java.util.List;

@UiController("MainScreen")
@UiDescriptor("main-screen.xml")
@Route(path = "main", root = true)
public class MainScreen extends Screen implements Window.HasWorkArea {

    @Autowired
    private ScreenTools screenTools;

    @Autowired
    private AppWorkArea workArea;
    @Autowired
    private Drawer drawer;
    @Autowired
    private Button collapseDrawerButton;
    @Autowired
    private CollectionLoader<Expense> expensesDl;

    @Override
    public AppWorkArea getWorkArea() {
        return workArea;
    }

    @Subscribe("collapseDrawerButton")
    private void onCollapseDrawerButtonClick(Button.ClickEvent event) {
        drawer.toggle();
        if (drawer.isCollapsed()) {
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_RIGHT);
        } else {
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_LEFT);
        }
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        screenTools.openDefaultScreen(
                UiControllerUtils.getScreenContext(this).getScreens());

        screenTools.handleRedirect();
    }

//    @Subscribe
//    public void onInit(InitEvent event){
//        User user = (User) currentAuthentication.getUser();
//    }

    @Subscribe("tabSheet")
    public void onTabSheetSelectedTabChange(final TabSheet.SelectedTabChangeEvent event) {
//        User user = (User) currentAuthentication.getUser();
        switch(event.getSelectedTab().getName()){
            case "Travel":
                expensesDl.setParameter("category", event.getSelectedTab().getName());
//                expensesDl.setParameter("userId", user.getId());
                expensesDl.load();
            case "Bills":
                expensesDl.setParameter("category", event.getSelectedTab().getName());
//                expensesDl.setParameter("userId", user.getId());
                expensesDl.load();
            case "Food":
                expensesDl.setParameter("category", event.getSelectedTab().getName());
//                expensesDl.setParameter("userId", user.getId());
                expensesDl.load();
            case "Shopping":
                expensesDl.setParameter("category", event.getSelectedTab().getName());
//                expensesDl.setParameter("userId", user.getId());
                expensesDl.load();
        }
    }

    


}
