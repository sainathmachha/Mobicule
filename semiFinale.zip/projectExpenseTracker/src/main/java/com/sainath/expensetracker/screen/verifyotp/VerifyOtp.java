package com.sainath.expensetracker.screen.verifyotp;

import io.jmix.core.Resources;
import io.jmix.email.*;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.TextField;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.util.Random;

@UiController("VerifyOtp")
@UiDescriptor("verify-otp.xml")
@Route(path = "login", root = true)
public class VerifyOtp extends Screen {

    @Autowired
    private Emailer emailer;

    @Autowired
    protected Resources resources;

    @Autowired
    private TextField<Object> alphaOtp;
    @Autowired
    private TextField<Object> numOtp;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Dialogs dialogs;

    public static final String otp = generateRandomNumOtp();

    @Subscribe
    public void onInit(InitEvent event) throws IOException {
//        try {
//            generateRandomAlphaOtp();
//            if(sendByEmail()){
//                notifications.create()
//                        .withCaption("Otp Sent Successfully")
//                        .withDescription("Check you gmail..")
//                        .withPosition(Notifications.Position.MIDDLE_CENTER)
//                        .withType(Notifications.NotificationType.TRAY)
//                        .show();
//            }
//        }catch (IOException | EmailException e){
//            notifications.create()
//                    .withCaption("Error sending email")
//                    .show();
//        }
    }

    private void sendByEmail() throws IOException, EmailException {
////        byte[] bytes = IOUtils.toByteArray(resourceAsStream);
////        EmailAttachment emailAtt = new EmailAttachment(bytes,
////                "logo.png", "logoId");
////        NewsItem newsItem = getEditedEntity();
//        EmailInfo emailInfo = EmailInfoBuilder.create()
//                .setAddresses("sainathmachha1143@gmail.com")
//                .setSubject("OTP Verification from Expense Tracker")
//                .setFrom(null)
//                .setBody("Your OTP for Expense Tracker is: "+otp)
//                .build();
//        try {
//            emailer.sendEmail(emailInfo);
//            return true;
//        }catch (Exception e){
//            return false;
//        }
    }


    @Subscribe("verifyBtn")
    public void onVerifyBtnClick(final Button.ClickEvent event) {
        if(numOtp.getValue().equals(otp)){
            notifications.create()
                    .withCaption("Successfully Verified")
                    .show();
            closeWithDefaultAction();
        }else{
            notifications.create()
                    .withCaption("Invalid Otp")
                    .show();
        }
    }


    public static String generateRandomNumOtp(){
        StringBuilder otp = new StringBuilder();
        Random random = new Random();
        for(int i=1; i<=4; i++){
            otp.append(random.nextInt(9));
        }
        return String.valueOf(otp);
    }


    public void generateRandomAlphaOtp() {

        String str = "abcdefghijklmnopqrstuvwxyzABCD"
                + "EFGHIJKLMNOPQRSTUVWXYZ";
        int n = str.length();
        String OTP = "";
        for (int i = 1; i <= 4; i++) {
            Random random = new Random();
            int a = random.nextInt(9);
            OTP += String.valueOf(str.charAt(a));
        }
        alphaOtp.setValue(String.valueOf(OTP));
    }
//
//        StringBuilder otp = new StringBuilder();
//        Random random = new Random();
//        for(char i=1; i<10; i++){
//            otp.append(random.nextInt());
//        }


//    static String generateOTP(int len)
//    {
//        // All possible characters of my OTP
//        String str = "abcdefghijklmnopqrstuvwxyzABCD"
//                +"EFGHIJKLMNOPQRSTUVWXYZ0123456789";
//        int n = str.length();
//
//        // String to hold my OTP
//        String OTP="";
//
//        for (int i = 1; i <= len; i++)
//            OTP += (str.charAt((int) ((Math.random()*10) % n)));
//
//        return(OTP);
//    }

}