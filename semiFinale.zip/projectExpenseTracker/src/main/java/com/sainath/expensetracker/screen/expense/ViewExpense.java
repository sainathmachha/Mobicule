package com.sainath.expensetracker.screen.expense;

import com.sainath.expensetracker.entity.Expense;
import com.sainath.expensetracker.entity.User;
import com.sainath.expensetracker.security.DatabaseUserRepository;
import io.jmix.core.DataManager;
import io.jmix.core.JmixModuleDescriptor;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.core.session.SessionData;
import io.jmix.securityui.authentication.AuthDetails;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.*;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.xml.layout.loader.GroupTableLoader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.security.access.event.AuthorizedEvent;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import javax.persistence.PostPersist;
import javax.persistence.Query;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@UiController("View.expense")
@UiDescriptor("view-expense.xml")
@LookupComponent("expensesTable")
public class ViewExpense extends StandardLookup<Expense> {

    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private CollectionLoader<Expense> expensesDl;
    @Autowired
    private Notifications notifications;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CurrentAuthentication currentAuthentication;

    @Subscribe
    public void onInit(InitEvent event) {
        User user = (User) currentAuthentication.getUser();
        UUID userId = user.getId();
        expensesDl.setParameter("userId", userId);
        expensesDl.load();
    }

    @Subscribe("createBtn")
    public void onCreateBtnClick(Button.ClickEvent event) {

        Screen editorScreen = screenBuilders.editor(Expense.class, this)
                .withScreenClass(EditExpense.class)
                .withOpenMode(OpenMode.DIALOG)
                .build();

        editorScreen.addAfterCloseListener(afterCloseEvent -> {
            if (afterCloseEvent.closedWith(StandardOutcome.COMMIT)) {
                expensesDl.load();

                notifications.create()
                        .withCaption("Success")
                        .withDescription("Your expense has been stored.")
                        .withType(Notifications.NotificationType.TRAY)
                        .withPosition(Notifications.Position.BOTTOM_CENTER)
                        .show();
            }
        });
        editorScreen.show();
    }

    @Install(to = "expensesTable.edit", subject = "columnGenerator")
    private Component expensesTableEditColumnGenerator(final Expense expense) {
        Button editBtn = uiComponents.create(Button.NAME);
        editBtn.setCaption("EDIT");
        editBtn.setStyleName("friendly");
        editBtn.setAlignment(Component.Alignment.MIDDLE_CENTER);

        editBtn.addClickListener(clickEvent -> {
            Screen editorScreen = screenBuilders.editor(Expense.class, this)
                    .withScreenClass(EditExpense.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .editEntity(expense)
                    .build();

            editorScreen.addAfterCloseListener(afterCloseEvent -> {
                if (afterCloseEvent.closedWith(StandardOutcome.COMMIT)) {
                    expensesDl.load();

                    notifications.create()
                            .withCaption("Success")
                            .withDescription("Your expense has been updated.")
                            .withType(Notifications.NotificationType.TRAY)
                            .withPosition(Notifications.Position.BOTTOM_CENTER)
                            .show();
                }
            });

            editorScreen.show();
        });

        return editBtn;
    }

    @Install(to = "expensesTable.delete", subject = "columnGenerator")
    private Component expensesTableDeleteColumnGenerator(final Expense expense) {
        Button deleteBtn = uiComponents.create(Button.NAME);
        deleteBtn.setCaption("REMOVE");
        deleteBtn.setStyleName("danger");
        deleteBtn.setAlignment(Component.Alignment.MIDDLE_CENTER);

        deleteBtn.addClickListener(event -> {
            dialogs.createOptionDialog()
                    .withCaption("Confirm Deletion")
                    .withMessage("Are you sure you want to delete this expense?")
                    .withActions(
                            new DialogAction(DialogAction.Type.YES)
                                    .withHandler(event1 -> {
                                        dataManager.remove(expense);
                                        expensesDl.load();
                                        notifications.create()
                                                .withCaption("Deleted")
                                                .withDescription("Expense removed successfully.")
                                                .withType(Notifications.NotificationType.TRAY)
                                                .show();
                                    }),
                            new DialogAction(DialogAction.Type.CANCEL)
                    ).show();
        });

        return deleteBtn;
    }

}
