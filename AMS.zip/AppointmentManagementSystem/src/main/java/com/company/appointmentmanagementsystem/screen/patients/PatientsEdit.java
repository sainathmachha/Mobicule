package com.company.appointmentmanagementsystem.screen.patients;

import com.company.appointmentmanagementsystem.entity.Doctor;
import com.company.appointmentmanagementsystem.entity.Patients;
import io.jmix.core.DataManager;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.*;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.Date;

@UiController("Patients.edit")
@UiDescriptor("patients-edit.xml")
@EditedEntityContainer("patientsDc")
public class PatientsEdit extends StandardEditor<Patients> {

    @Autowired
    private EntityComboBox<Doctor> doctorDetails;
    @Autowired
    private TextField<String> doctorsNameField;
    @Autowired
    private TextField<String> doctorSpecializationField;
    @Autowired
    private Notifications notifications;

    private static Doctor doctor;

    @Subscribe("commitAndCloseBtn")
    public void onCommitAndCloseBtnClick(Button.ClickEvent event) {
        Patients patient = getEditedEntity(); // ✅ Get the existing patient entity

        if (patient.getDoctorDetails() == null) {
            notifications.create()
                    .withCaption("Please select a doctor before proceeding!")
                    .withType(Notifications.NotificationType.WARNING)
                    .show();
            return;
        }

        patient.setDoctorsName(patient.getDoctorDetails().getName());
        patient.setDoctorSpecialization(patient.getDoctorDetails().getSpecialization());

        doctorsNameField.setValue(doctorDetails.getValue().getName());
        doctorSpecializationField.setValue(doctorDetails.getValue().getSpecialization());

        notifications.create()
                .withCaption("Appointment Created Successfully!")
                .withDescription("Waiting for doctor's approval.")
                .withType(Notifications.NotificationType.TRAY)
                .withPosition(Notifications.Position.MIDDLE_CENTER)
                .show();

        commitChanges();

        //closeWithCommit(); // ✅ Correctly commits changes & closes the screen
    }

    @Subscribe("doctorDetails")
    public void onDoctorDetailsValueChange(HasValue.ValueChangeEvent<Doctor> event) {
        Doctor selectedDoctor = event.getValue();

        if (selectedDoctor != null) {
            getEditedEntity().setDoctorDetails(selectedDoctor);

            doctorsNameField.setValue(selectedDoctor.getName());
            doctorSpecializationField.setValue(selectedDoctor.getSpecialization());
        } else {
            doctorsNameField.setValue("");
            doctorSpecializationField.setValue("");
        }
    }
}