package com.company.appointmentmanagementsystem.screen.doctor;

import com.company.appointmentmanagementsystem.entity.Doctor;
import com.company.appointmentmanagementsystem.entity.Patients;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.VBoxLayout;
import io.jmix.ui.component.Component;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@UiController("Doctor.browse")
@UiDescriptor("doctor-browse.xml")
@LookupComponent("doctorsTable")
public class DoctorBrowse extends StandardLookup<Doctor> {

    @Autowired
    private GroupTable<Doctor> doctorsTable;
    @Autowired
    private UiComponents uiComponents;

    @Subscribe
    public void onInit(InitEvent event) {
        doctorsTable.addGeneratedColumn("appointments", doctor -> {
            List<Patients> appointments = doctor.getAppointments();

            if (appointments != null && !appointments.isEmpty()) {
                VBoxLayout vBox = uiComponents.create(VBoxLayout.class);

                for (Patients appointment : appointments) {
                    Label<String> label = uiComponents.create(Label.TYPE_STRING);
                    label.setValue("Name: " + appointment.getFullName() +",\n"+
                            "Contact: " + appointment.getContact() +",\n"+
                            "Reason: " + appointment.getReasonForVisit() +",\n"+
                            "Date: " + appointment.getDateOfAppointment()+"\n\n");
                    vBox.add(label);
                }
                return vBox;
            }

            Label<String> noAppointmentsLabel = uiComponents.create(Label.TYPE_STRING);
            noAppointmentsLabel.setValue("No Appointments");
            return noAppointmentsLabel;
        });
    }
}
