package com.company.appointmentmanagementsystem.screen.patients;

import com.company.appointmentmanagementsystem.entity.Patients;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("Patients.browse")
@UiDescriptor("patients-browse.xml")
@LookupComponent("patientsesTable")
public class PatientsBrowse extends StandardLookup<Patients> {

    @Autowired
    private CollectionLoader<Patients> patientsesDl;

    @Subscribe
    public void onValueChange(InitEvent event){
        patientsesDl.load();
    }
}