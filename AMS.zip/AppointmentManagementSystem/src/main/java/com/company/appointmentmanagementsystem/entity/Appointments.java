package com.company.appointmentmanagementsystem.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.NumberFormat;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@JmixEntity
@Table(name = "APPOINTMENTS", indexes = {
        @Index(name = "IDX_APPOINTMENTS_PATIENT", columnList = "PATIENT_ID"),
        @Index(name = "IDX_APPOINTMENTS_DOCTOR", columnList = "DOCTOR_ID")
})
@Entity
public class Appointments {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "PATIENT_ID")
    @OneToOne(fetch = FetchType.LAZY)
    private Patients patient;

    @Column(name = "CONTACT")
    private Long contact;

    @JoinColumn(name = "DOCTOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Doctor doctor;

    @Column(name = "DATE_TIME")
    private LocalDateTime dateTime;

    @Column(name = "STATUS")
    private Boolean status;

    public Boolean getStatus() {
        return status;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Long getContact() {
        return contact;
    }

    public void setContact(Long contact) {
        this.contact = contact;
    }

    public Patients getPatient() {
        return patient;
    }

    public void setPatient(Patients patient) {
        this.patient = patient;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}