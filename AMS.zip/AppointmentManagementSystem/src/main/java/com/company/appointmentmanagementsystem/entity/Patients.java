package com.company.appointmentmanagementsystem.entity;

import io.jmix.core.entity.annotation.CaseConversion;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PATIENTS", indexes = {
        @Index(name = "IDX_PATIENTS_DOCTOR_DETAILS", columnList = "DOCTOR_DETAILS_ID")
})
@Entity
public class Patients {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @InstanceName
    @Column(name = "FULL_NAME", nullable = false)
    @NotNull
    private String fullName;

    @Column(name = "CONTACT")
    private String contact;

    @Column(name = "DOB")
    private Date dateOfBirth;

    @Column(name = "REASON_FOR_VISIT")
    private String reasonForVisit;

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getReasonForVisit() {
        return reasonForVisit;
    }

    public void setReasonForVisit(String reasonForVisit) {
        this.reasonForVisit = reasonForVisit;
    }

    @JoinColumn(name = "DOCTOR_DETAILS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Doctor doctorDetails;

    @OneToOne(fetch = FetchType.LAZY, mappedBy = "patient")
    private Appointments appointments;

    @Column(name = "DATE_OF_APPOINTMENT")
    private Date dateOfAppointment;

    @Column(name = "STATUS")
    private Boolean status = false;

    @Column(name = "DOCTOR_SPECIALIZATION")
    private String doctorSpecialization;

    @CaseConversion
    @Column(name = "DOCTORS_NAME")
    private String doctorsName;

    public String getDoctorsName() {
        return doctorsName;
    }

    public void setDoctorsName(String doctorsName) {
        this.doctorsName = doctorsName;
    }

    public Date getDateOfAppointment() {
        return dateOfAppointment;
    }

    public void setDateOfAppointment(Date dateOfAppointment) {
        this.dateOfAppointment = dateOfAppointment;
    }

    public Boolean isStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getDoctorSpecialization() {
        return doctorSpecialization;
    }

    public void setDoctorSpecialization(String doctorSpecialization) {
        this.doctorSpecialization = doctorSpecialization;
    }

    public Boolean getStatus() {
        return status;
    }

    public Appointments getAppointments() {
        return appointments;
    }

    public void setAppointments(Appointments appointments) {
        this.appointments = appointments;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Doctor getDoctorDetails() {
        return doctorDetails;
    }

    public void setDoctorDetails(Doctor doctorDetails) {
        this.doctorDetails = doctorDetails;
    }
}