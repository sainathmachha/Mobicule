package com.company.appointmentmanagementsystem.screen.doctor;

import com.company.appointmentmanagementsystem.entity.Doctor;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("Doctor.edit")
@UiDescriptor("doctor-edit.xml")
@EditedEntityContainer("doctorDc")
public class DoctorEdit extends StandardEditor<Doctor> {
}